declare const router: import("express-serve-static-core").Router;
export interface UploadedImage {
    id: string;
    name: string;
    base64: string;
    mimeType: string;
    size: number;
}
export interface ImageAnalysisRequest {
    images: UploadedImage[];
    prompt: string;
    context?: string;
    detailedAnalysis?: boolean;
}
export interface ImageAnalysisResponse {
    success: boolean;
    result?: string;
    error?: string;
    imagesProcessed: number;
    analysisTime: number;
}
export default router;
//# sourceMappingURL=images.d.ts.map