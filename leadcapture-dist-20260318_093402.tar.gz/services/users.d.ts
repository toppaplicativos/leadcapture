import { AuthPayload } from "../types";
export interface DBUser {
    id: string;
    name: string;
    email: string;
    password_hash: string;
    phone?: string;
    role: "admin" | "manager" | "operator";
    avatar_url?: string;
    is_active: boolean;
    last_login_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export interface UserCreateDTO {
    email: string;
    password: string;
    name: string;
    phone?: string;
    role?: "admin" | "manager" | "operator";
}
export interface UserLoginDTO {
    email: string;
    password: string;
}
type SafeUser = Omit<DBUser, "password_hash">;
export declare class UsersService {
    signToken(user: Pick<DBUser, "id" | "email" | "role">): string;
    create(dto: UserCreateDTO): Promise<SafeUser>;
    login(dto: UserLoginDTO): Promise<{
        token: string;
        user: SafeUser;
    }>;
    getById(id: string): Promise<SafeUser | null>;
    getAll(): Promise<SafeUser[]>;
    updateUser(id: string, data: Partial<UserCreateDTO>): Promise<SafeUser | null>;
    deactivate(id: string): Promise<boolean>;
    static verifyToken(token: string): AuthPayload;
}
export {};
//# sourceMappingURL=users.d.ts.map