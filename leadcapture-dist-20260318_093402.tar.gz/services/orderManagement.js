"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderManagementService = void 0;
exports.renderTemplate = renderTemplate;
exports.formatMoney = formatMoney;
exports.formatDate = formatDate;
const crypto_1 = require("crypto");
const database_1 = require("../config/database");
const logger_1 = require("../utils/logger");
const STATUS_FLOW = {
    novo: ["aguardando_pagamento", "pago", "cancelado"],
    aguardando_pagamento: ["pago", "cancelado"],
    pago: ["em_preparacao", "cancelado"],
    em_preparacao: ["em_entrega", "cancelado"],
    em_entrega: ["entregue", "cancelado"],
    entregue: [],
    cancelado: [],
};
const STATUS_LABELS = {
    novo: "Novo",
    aguardando_pagamento: "Aguardando Pagamento",
    pago: "Pago",
    em_preparacao: "Em Preparação",
    em_entrega: "Em Entrega",
    entregue: "Entregue",
    cancelado: "Cancelado",
};
// ─── Template Engine ────────────────────────────────────────────────────────
function renderTemplate(template, variables) {
    return template.replace(/\{\{(\w+(?:\.\w+)*)\}\}/g, (_match, path) => {
        const keys = path.split(".");
        let value = variables;
        for (const key of keys) {
            if (value == null || typeof value !== "object")
                return "";
            value = value[key];
        }
        if (value === null || value === undefined)
            return "";
        return String(value);
    });
}
function formatMoney(value) {
    const amount = Number(value);
    if (!Number.isFinite(amount))
        return "R$ 0,00";
    return `R$ ${amount.toFixed(2).replace(".", ",")}`;
}
function formatDate(value) {
    const d = value instanceof Date ? value : new Date(value);
    if (isNaN(d.getTime()))
        return "";
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
// ─── Service Class ──────────────────────────────────────────────────────────
class OrderManagementService {
    constructor() {
        this.schemaReady = false;
    }
    async ensureSchema() {
        if (this.schemaReady)
            return;
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS oms_notification_templates (
        id VARCHAR(36) PRIMARY KEY,
        user_id VARCHAR(36) NOT NULL,
        brand_id VARCHAR(36) NULL,
        event VARCHAR(80) NOT NULL,
        target VARCHAR(20) NOT NULL,
        channel VARCHAR(20) NOT NULL DEFAULT 'whatsapp',
        subject VARCHAR(255) NULL,
        body_template TEXT NOT NULL,
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE (user_id, brand_id, event, target, channel)
      )
    `);
        await (0, database_1.query)(`
      CREATE INDEX IF NOT EXISTS idx_oms_templates_user ON oms_notification_templates (user_id, brand_id)
    `);
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS oms_order_responsibles (
        id VARCHAR(36) PRIMARY KEY,
        order_id VARCHAR(36) NOT NULL,
        user_id VARCHAR(36) NOT NULL,
        brand_id VARCHAR(36) NULL,
        responsible_user_id VARCHAR(36) NOT NULL,
        responsible_name VARCHAR(180) NOT NULL,
        role VARCHAR(30) NOT NULL DEFAULT 'seller',
        assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        unassigned_at TIMESTAMP NULL,
        is_active BOOLEAN NOT NULL DEFAULT TRUE
      )
    `);
        await (0, database_1.query)(`
      CREATE INDEX IF NOT EXISTS idx_oms_responsibles_order ON oms_order_responsibles (order_id)
    `);
        await (0, database_1.query)(`
      CREATE INDEX IF NOT EXISTS idx_oms_responsibles_user ON oms_order_responsibles (user_id, brand_id)
    `);
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS oms_automation_log (
        id VARCHAR(36) PRIMARY KEY,
        order_id VARCHAR(36) NOT NULL,
        user_id VARCHAR(36) NOT NULL,
        brand_id VARCHAR(36) NULL,
        event VARCHAR(80) NOT NULL,
        target VARCHAR(20) NOT NULL,
        channel VARCHAR(20) NOT NULL,
        rendered_message TEXT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'sent',
        error_message TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
        await (0, database_1.query)(`
      CREATE INDEX IF NOT EXISTS idx_oms_automation_order ON oms_automation_log (order_id)
    `);
        await (0, database_1.query)(`
      CREATE INDEX IF NOT EXISTS idx_oms_automation_user ON oms_automation_log (user_id, brand_id, created_at)
    `);
        this.schemaReady = true;
    }
    // ─── Status Flow ──────────────────────────────────────────────────────────
    canTransition(from, to) {
        return STATUS_FLOW[from]?.includes(to) ?? false;
    }
    getAllowedTransitions(current) {
        return STATUS_FLOW[current] || [];
    }
    getStatusLabel(status) {
        return STATUS_LABELS[status] || status;
    }
    getStatusFlow() {
        const result = {};
        for (const [status, nextStatuses] of Object.entries(STATUS_FLOW)) {
            result[status] = {
                label: STATUS_LABELS[status] || status,
                next: nextStatuses,
            };
        }
        return result;
    }
    // ─── Template CRUD ────────────────────────────────────────────────────────
    async listTemplates(userId, brandId) {
        await this.ensureSchema();
        const rows = await (0, database_1.query)(`SELECT * FROM oms_notification_templates
       WHERE user_id = ? AND (brand_id = ? OR brand_id IS NULL)
       ORDER BY event, target, channel`, [userId, brandId || null]);
        return rows || [];
    }
    async getTemplate(userId, templateId) {
        await this.ensureSchema();
        return (0, database_1.queryOne)(`SELECT * FROM oms_notification_templates WHERE id = ? AND user_id = ? LIMIT 1`, [templateId, userId]);
    }
    async upsertTemplate(input) {
        await this.ensureSchema();
        const id = (0, crypto_1.randomUUID)();
        const channel = String(input.channel || "whatsapp").trim();
        const isActive = input.isActive !== false;
        await (0, database_1.query)(`INSERT INTO oms_notification_templates
       (id, user_id, brand_id, event, target, channel, subject, body_template, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT (user_id, brand_id, event, target, channel)
       DO UPDATE SET
         subject = EXCLUDED.subject,
         body_template = EXCLUDED.body_template,
         is_active = EXCLUDED.is_active,
         updated_at = CURRENT_TIMESTAMP`, [id, input.userId, input.brandId || null, input.event, input.target, channel, input.subject || null, input.bodyTemplate, isActive]);
        const row = await (0, database_1.queryOne)(`SELECT * FROM oms_notification_templates
       WHERE user_id = ? AND (brand_id = ? OR brand_id IS NULL) AND event = ? AND target = ? AND channel = ?
       LIMIT 1`, [input.userId, input.brandId || null, input.event, input.target, channel]);
        return row;
    }
    async deleteTemplate(userId, templateId) {
        await this.ensureSchema();
        const affected = await (0, database_1.update)(`DELETE FROM oms_notification_templates WHERE id = ? AND user_id = ?`, [templateId, userId]);
        return affected > 0;
    }
    async seedDefaultTemplates(userId, brandId) {
        await this.ensureSchema();
        const defaults = this.getDefaultTemplates();
        let count = 0;
        for (const tpl of defaults) {
            const existing = await (0, database_1.queryOne)(`SELECT id FROM oms_notification_templates
         WHERE user_id = ? AND (brand_id = ? OR brand_id IS NULL) AND event = ? AND target = ? AND channel = ?
         LIMIT 1`, [userId, brandId || null, tpl.event, tpl.target, tpl.channel]);
            if (existing)
                continue;
            await (0, database_1.query)(`INSERT INTO oms_notification_templates
         (id, user_id, brand_id, event, target, channel, subject, body_template, is_active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE)`, [(0, crypto_1.randomUUID)(), userId, brandId || null, tpl.event, tpl.target, tpl.channel, tpl.subject || null, tpl.body]);
            count += 1;
        }
        return count;
    }
    getDefaultTemplates() {
        return [
            // ── Client notifications ──
            {
                event: "order.created",
                target: "client",
                channel: "whatsapp",
                body: "Olá {{customer_name}}! 🎉\nSeu pedido *#{{order_number}}* foi recebido com sucesso.\n\n📦 *Total:* {{total_formatted}}\n💳 *Pagamento:* {{payment_method}}\n\nAcompanhe o status do seu pedido. Obrigado pela preferência!",
            },
            {
                event: "order.paid",
                target: "client",
                channel: "whatsapp",
                body: "✅ Pagamento confirmado!\nPedido *#{{order_number}}* - {{total_formatted}}\n\nEstamos preparando seu pedido. Você será notificado quando sair para entrega.",
            },
            {
                event: "order.preparing",
                target: "client",
                channel: "whatsapp",
                body: "👨‍🍳 Seu pedido *#{{order_number}}* está sendo preparado!\nPrevisão de entrega: {{estimated_delivery}}",
            },
            {
                event: "order.shipped",
                target: "client",
                channel: "whatsapp",
                body: "🚚 Seu pedido *#{{order_number}}* saiu para entrega!\n\n📍 Entregador: {{courier_name}}\n📞 Contato: {{courier_phone}}\n🔗 Rastreio: {{tracking_url}}\n\n🔑 Código de confirmação: *{{delivery_token}}*",
            },
            {
                event: "order.delivered",
                target: "client",
                channel: "whatsapp",
                body: "🎉 Pedido *#{{order_number}}* entregue com sucesso!\nObrigado por comprar conosco, {{customer_name}}! ⭐\n\nSua opinião é importante para nós.",
            },
            {
                event: "order.cancelled",
                target: "client",
                channel: "whatsapp",
                body: "❌ Pedido *#{{order_number}}* foi cancelado.\nMotivo: {{cancel_reason}}\n\nCaso tenha dúvidas, entre em contato conosco.",
            },
            // ── Seller notifications ──
            {
                event: "order.created",
                target: "seller",
                channel: "whatsapp",
                body: "🔔 *Novo Pedido #{{order_number}}*\n\n👤 {{customer_name}}\n📱 {{customer_phone}}\n💰 {{total_formatted}}\n📦 {{items_summary}}\n\n⏰ {{created_at}}",
            },
            {
                event: "order.paid",
                target: "seller",
                channel: "whatsapp",
                body: "💰 *Pagamento Confirmado*\nPedido #{{order_number}} - {{customer_name}}\nValor: {{total_formatted}}\n\n✅ Inicie a preparação do pedido.",
            },
            {
                event: "order.cancelled",
                target: "seller",
                channel: "whatsapp",
                body: "❌ *Pedido Cancelado*\n#{{order_number}} - {{customer_name}}\nMotivo: {{cancel_reason}}\nValor: {{total_formatted}}",
            },
            // ── Expedition notifications ──
            {
                event: "order.shipped",
                target: "expedition",
                channel: "whatsapp",
                body: "📦 *Nova Entrega Atribuída*\nPedido #{{order_number}}\n\n👤 Cliente: {{customer_name}}\n📱 Telefone: {{customer_phone}}\n📍 Endereço: {{delivery_address}}\n💰 Total: {{total_formatted}}\n\n📋 Itens:\n{{items_summary}}\n\n🔑 Token: *{{delivery_token}}*",
            },
            {
                event: "delivery.completed",
                target: "expedition",
                channel: "whatsapp",
                body: "✅ Entrega confirmada!\nPedido #{{order_number}} entregue com sucesso.\nConfirmado por: {{confirmed_by}} ({{confirmed_via}})",
            },
        ];
    }
    // ─── Render & Send Notifications ──────────────────────────────────────────
    async processOrderEvent(input) {
        await this.ensureSchema();
        const templates = await (0, database_1.query)(`SELECT * FROM oms_notification_templates
       WHERE user_id = ? AND (brand_id = ? OR brand_id IS NULL) AND event = ? AND is_active = TRUE`, [input.userId, input.brandId || null, input.event]);
        if (!templates || templates.length === 0)
            return [];
        const enriched = {
            ...input.variables,
            total_formatted: formatMoney(input.variables.total ?? input.variables.valor_total ?? 0),
            created_at: formatDate(input.variables.created_at || new Date().toISOString()),
        };
        const results = [];
        for (const tpl of templates) {
            const rendered = renderTemplate(tpl.body_template, enriched);
            const status = "sent";
            await (0, database_1.query)(`INSERT INTO oms_automation_log (id, order_id, user_id, brand_id, event, target, channel, rendered_message, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [(0, crypto_1.randomUUID)(), input.orderId, input.userId, input.brandId || null, input.event, tpl.target, tpl.channel, rendered, status]);
            results.push({ target: tpl.target, channel: tpl.channel, rendered, status });
            logger_1.logger.info({
                module: "oms",
                event: input.event,
                order_id: input.orderId,
                target: tpl.target,
                channel: tpl.channel,
            }, "OMS notification processed");
        }
        return results;
    }
    async previewTemplate(bodyTemplate, sampleVariables) {
        const defaults = {
            customer_name: "João Silva",
            customer_phone: "(11) 99999-0000",
            customer_email: "joao@email.com",
            order_number: "SF250616001",
            total: 129.9,
            total_formatted: "R$ 129,90",
            payment_method: "PIX",
            items_summary: "2x Produto A, 1x Produto B",
            delivery_address: "Rua Exemplo, 123 - Centro, São Paulo/SP",
            courier_name: "Carlos Entregador",
            courier_phone: "(11) 98888-0000",
            tracking_url: "https://maps.google.com/...",
            delivery_token: "DEL-SF001-XK9M2",
            estimated_delivery: "40 minutos",
            cancel_reason: "Solicitação do cliente",
            confirmed_by: "Cliente",
            confirmed_via: "token",
            created_at: formatDate(new Date()),
            responsible_name: "Maria Operadora",
        };
        return renderTemplate(bodyTemplate, { ...defaults, ...(sampleVariables || {}) });
    }
    // ─── Responsible Assignment ───────────────────────────────────────────────
    async assignResponsible(input) {
        await this.ensureSchema();
        // Deactivate previous same-role assignment
        await (0, database_1.update)(`UPDATE oms_order_responsibles
       SET is_active = FALSE, unassigned_at = CURRENT_TIMESTAMP
       WHERE order_id = ? AND user_id = ? AND role = ? AND is_active = TRUE`, [input.orderId, input.userId, input.role]);
        const id = (0, crypto_1.randomUUID)();
        await (0, database_1.query)(`INSERT INTO oms_order_responsibles
       (id, order_id, user_id, brand_id, responsible_user_id, responsible_name, role, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, TRUE)`, [id, input.orderId, input.userId, input.brandId || null, input.responsibleUserId, input.responsibleName, input.role]);
        return (await (0, database_1.queryOne)(`SELECT * FROM oms_order_responsibles WHERE id = ? LIMIT 1`, [id]));
    }
    async getOrderResponsibles(orderId) {
        await this.ensureSchema();
        return (0, database_1.query)(`SELECT * FROM oms_order_responsibles WHERE order_id = ? AND is_active = TRUE ORDER BY assigned_at DESC`, [orderId]);
    }
    async unassignResponsible(orderId, userId, role) {
        await this.ensureSchema();
        const affected = await (0, database_1.update)(`UPDATE oms_order_responsibles
       SET is_active = FALSE, unassigned_at = CURRENT_TIMESTAMP
       WHERE order_id = ? AND user_id = ? AND role = ? AND is_active = TRUE`, [orderId, userId, role]);
        return affected > 0;
    }
    // ─── Problem Detection ────────────────────────────────────────────────────
    async detectProblems(userId, brandId) {
        await this.ensureSchema();
        const brandClause = brandId ? "o.brand_id = ?" : "o.brand_id IS NULL";
        const params = brandId ? [userId, brandId] : [userId];
        const stalePayments = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM commerce_orders o
       LEFT JOIN order_management_meta m ON m.order_id = o.id
       WHERE o.user_id = ? AND ${brandClause}
         AND COALESCE(m.business_status, 'aguardando_pagamento') = 'aguardando_pagamento'
         AND o.created_at < (CURRENT_TIMESTAMP - INTERVAL '24 hours')`, params).catch(() => ({ total: 0 }));
        const stalledPreparation = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM commerce_orders o
       LEFT JOIN order_management_meta m ON m.order_id = o.id
       WHERE o.user_id = ? AND ${brandClause}
         AND COALESCE(m.business_status, 'novo') = 'em_preparacao'
         AND o.updated_at < (CURRENT_TIMESTAMP - INTERVAL '8 hours')`, params).catch(() => ({ total: 0 }));
        const lateDeliveries = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM commerce_orders o
       LEFT JOIN order_management_meta m ON m.order_id = o.id
       WHERE o.user_id = ? AND ${brandClause}
         AND COALESCE(m.business_status, 'novo') = 'em_entrega'
         AND o.updated_at < (CURRENT_TIMESTAMP - INTERVAL '4 hours')`, params).catch(() => ({ total: 0 }));
        const unassignedOrders = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM commerce_orders o
       LEFT JOIN order_management_meta m ON m.order_id = o.id
       LEFT JOIN oms_order_responsibles r ON r.order_id = o.id AND r.is_active = TRUE
       WHERE o.user_id = ? AND ${brandClause}
         AND COALESCE(m.business_status, 'novo') NOT IN ('entregue', 'cancelado')
         AND r.id IS NULL`, params).catch(() => ({ total: 0 }));
        const sp = Number(stalePayments?.total || 0);
        const sr = Number(stalledPreparation?.total || 0);
        const ld = Number(lateDeliveries?.total || 0);
        const ua = Number(unassignedOrders?.total || 0);
        const details = [];
        if (sp > 0)
            details.push({ type: "stale_payment", count: sp, description: `${sp} pedidos aguardando pagamento há mais de 24h` });
        if (sr > 0)
            details.push({ type: "stalled_preparation", count: sr, description: `${sr} pedidos parados em preparação há mais de 8h` });
        if (ld > 0)
            details.push({ type: "late_delivery", count: ld, description: `${ld} entregas em andamento há mais de 4h` });
        if (ua > 0)
            details.push({ type: "unassigned", count: ua, description: `${ua} pedidos ativos sem responsável atribuído` });
        return {
            stale_payments: sp,
            stalled_preparation: sr,
            late_deliveries: ld,
            unassigned_orders: ua,
            total_problems: sp + sr + ld + ua,
            details,
        };
    }
    // ─── Advanced Analytics ───────────────────────────────────────────────────
    async getAdvancedAnalytics(userId, brandId, period) {
        await this.ensureSchema();
        const brandClause = brandId ? "o.brand_id = ?" : "o.brand_id IS NULL";
        const params = brandId ? [userId, brandId] : [userId];
        const periodWhere = [];
        if (period?.start) {
            periodWhere.push("o.created_at >= ?");
            params.push(period.start);
        }
        if (period?.end) {
            periodWhere.push("o.created_at <= ?");
            params.push(period.end);
        }
        const periodClause = periodWhere.length > 0 ? ` AND ${periodWhere.join(" AND ")}` : "";
        // Summary totals
        const summary = await (0, database_1.queryOne)(`SELECT
        COUNT(*) AS total_orders,
        SUM(CASE WHEN DATE(o.created_at) = CURRENT_DATE THEN 1 ELSE 0 END) AS orders_today,
        SUM(o.valor_total) AS total_revenue,
        SUM(CASE WHEN DATE(o.created_at) = CURRENT_DATE THEN o.valor_total ELSE 0 END) AS revenue_today,
        AVG(NULLIF(o.valor_total, 0)) AS avg_ticket,
        SUM(CASE WHEN COALESCE(m.business_status, 'novo') = 'cancelado' THEN 1 ELSE 0 END) AS cancelled_count,
        SUM(CASE WHEN COALESCE(m.business_status, 'novo') = 'entregue' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN COALESCE(m.business_status, 'novo') NOT IN ('entregue', 'cancelado') THEN 1 ELSE 0 END) AS active_count
      FROM commerce_orders o
      LEFT JOIN order_management_meta m ON m.order_id = o.id
      WHERE o.user_id = ? AND ${brandClause}${periodClause}`, params);
        // Status breakdown
        const statusParams = brandId ? [userId, brandId] : [userId];
        const statusBreakdown = await (0, database_1.query)(`SELECT
        COALESCE(m.business_status, 'novo') AS status,
        COUNT(*) AS count,
        SUM(o.valor_total) AS revenue
      FROM commerce_orders o
      LEFT JOIN order_management_meta m ON m.order_id = o.id
      WHERE o.user_id = ? AND ${brandClause}
      GROUP BY COALESCE(m.business_status, 'novo')
      ORDER BY count DESC`, statusParams);
        // Channel breakdown
        const channelBreakdown = await (0, database_1.query)(`SELECT
        COALESCE(m.channel, 'Site') AS channel,
        COUNT(*) AS count,
        SUM(o.valor_total) AS revenue
      FROM commerce_orders o
      LEFT JOIN order_management_meta m ON m.order_id = o.id
      WHERE o.user_id = ? AND ${brandClause}
      GROUP BY COALESCE(m.channel, 'Site')
      ORDER BY count DESC`, statusParams);
        // Daily revenue (last 30 days)
        const dailyRevenue = await (0, database_1.query)(`SELECT
        DATE(o.created_at) AS date,
        COUNT(*) AS orders,
        SUM(o.valor_total) AS revenue
      FROM commerce_orders o
      WHERE o.user_id = ? AND ${brandClause}
        AND o.created_at >= (CURRENT_DATE - INTERVAL '30 days')
      GROUP BY DATE(o.created_at)
      ORDER BY date DESC`, statusParams);
        // Top customers
        const topCustomers = await (0, database_1.query)(`SELECT
        o.customer_name,
        o.customer_phone,
        COUNT(*) AS total_orders,
        SUM(o.valor_total) AS total_spent,
        AVG(o.valor_total) AS avg_ticket
      FROM commerce_orders o
      WHERE o.user_id = ? AND ${brandClause}
        AND COALESCE(o.customer_phone, '') <> ''
      GROUP BY o.customer_name, o.customer_phone
      ORDER BY total_spent DESC
      LIMIT 10`, statusParams);
        // Automation log stats
        const automationStats = await (0, database_1.query)(`SELECT
        event, target, channel,
        COUNT(*) AS total_sent,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS total_failed
      FROM oms_automation_log
      WHERE user_id = ? AND (brand_id = ? OR brand_id IS NULL)
      GROUP BY event, target, channel
      ORDER BY total_sent DESC`, [userId, brandId || null]).catch(() => []);
        // Responsible workload
        const responsibleWorkload = await (0, database_1.query)(`SELECT
        r.responsible_name,
        r.role,
        COUNT(DISTINCT r.order_id) AS active_orders
      FROM oms_order_responsibles r
      WHERE r.user_id = ? AND (r.brand_id = ? OR r.brand_id IS NULL) AND r.is_active = TRUE
      GROUP BY r.responsible_name, r.role
      ORDER BY active_orders DESC`, [userId, brandId || null]).catch(() => []);
        const totalOrders = Number(summary?.total_orders || 0);
        const deliveredCount = Number(summary?.delivered_count || 0);
        const cancelledCount = Number(summary?.cancelled_count || 0);
        return {
            summary: {
                total_orders: totalOrders,
                orders_today: Number(summary?.orders_today || 0),
                total_revenue: Number(summary?.total_revenue || 0),
                revenue_today: Number(summary?.revenue_today || 0),
                avg_ticket: Number(summary?.avg_ticket || 0),
                cancelled_count: cancelledCount,
                delivered_count: deliveredCount,
                active_count: Number(summary?.active_count || 0),
                delivery_rate: totalOrders > 0 ? Number(((deliveredCount / totalOrders) * 100).toFixed(1)) : 0,
                cancellation_rate: totalOrders > 0 ? Number(((cancelledCount / totalOrders) * 100).toFixed(1)) : 0,
            },
            status_breakdown: (statusBreakdown || []).map((row) => ({
                status: row.status,
                label: STATUS_LABELS[row.status] || row.status,
                count: Number(row.count || 0),
                revenue: Number(row.revenue || 0),
            })),
            channel_breakdown: channelBreakdown || [],
            daily_revenue: (dailyRevenue || []).map((row) => ({
                date: row.date,
                orders: Number(row.orders || 0),
                revenue: Number(row.revenue || 0),
            })),
            top_customers: (topCustomers || []).map((row) => ({
                name: row.customer_name,
                phone: row.customer_phone,
                total_orders: Number(row.total_orders || 0),
                total_spent: Number(row.total_spent || 0),
                avg_ticket: Number(row.avg_ticket || 0),
            })),
            automation_stats: automationStats || [],
            responsible_workload: responsibleWorkload || [],
        };
    }
    // ─── Notification Log ─────────────────────────────────────────────────────
    async getAutomationLog(userId, brandId, filters) {
        await this.ensureSchema();
        const where = ["user_id = ?", "(brand_id = ? OR brand_id IS NULL)"];
        const params = [userId, brandId || null];
        if (filters?.orderId) {
            where.push("order_id = ?");
            params.push(filters.orderId);
        }
        if (filters?.event) {
            where.push("event = ?");
            params.push(filters.event);
        }
        if (filters?.target) {
            where.push("target = ?");
            params.push(filters.target);
        }
        const limit = Math.max(1, Math.min(200, Number(filters?.limit || 50)));
        const offset = Math.max(0, Number(filters?.offset || 0));
        const logs = await (0, database_1.query)(`SELECT * FROM oms_automation_log
       WHERE ${where.join(" AND ")}
       ORDER BY created_at DESC
       LIMIT ${limit} OFFSET ${offset}`, params);
        const countRow = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total FROM oms_automation_log WHERE ${where.join(" AND ")}`, params);
        return {
            logs: logs || [],
            total: Number(countRow?.total || 0),
        };
    }
    // ─── Build Order Variables for Templates ──────────────────────────────────
    buildOrderVariables(order, extras) {
        const items = Array.isArray(order.items) ? order.items : [];
        const itemsSummary = items.map((i) => `${i.quantidade || i.quantity || 1}x ${i.nome || i.name || "Produto"}`).join(", ");
        return {
            order_id: order.id || order.order_id || "",
            order_number: order.order_number || order.id?.slice(0, 8) || "",
            customer_name: order.customer_name || "",
            customer_phone: order.customer_phone || "",
            customer_email: order.customer_email || "",
            total: Number(order.valor_total || order.total || 0),
            total_formatted: formatMoney(order.valor_total || order.total || 0),
            payment_method: order.forma_pagamento || order.payment_method || "",
            delivery_address: order.delivery_address || "",
            courier_name: order.courier_name || "",
            courier_phone: order.courier_phone || "",
            tracking_url: order.tracking_url || order.courier_route_url || "",
            delivery_token: order.delivery_token || "",
            estimated_delivery: order.estimated_delivery || "40 minutos",
            cancel_reason: order.cancel_reason || order.reason || "Não informado",
            confirmed_by: order.confirmed_by || order.delivery_confirmed_by || "",
            confirmed_via: order.confirmed_via || order.delivery_confirmed_via || "",
            items_summary: itemsSummary,
            created_at: order.created_at || new Date().toISOString(),
            status: order.business_status || order.status || "novo",
            status_label: STATUS_LABELS[(order.business_status || order.status || "novo")] || "",
            ...(extras || {}),
        };
    }
}
exports.OrderManagementService = OrderManagementService;
//# sourceMappingURL=orderManagement.js.map