export interface LeadMemoryProfile {
    nome?: string;
    cidade?: string;
    segmento?: string;
    empresa?: string;
}
export type IntentStage = "descoberta" | "interesse" | "consideracao" | "decisao" | "pos_venda" | "inativo";
export type Sentiment = "positivo" | "neutro" | "negativo" | "desconhecido";
export interface LeadContextMemory {
    profile: LeadMemoryProfile;
    conversation_summary: string;
    intent_stage: IntentStage;
    pain_points: string[];
    objections: string[];
    preferences: Record<string, string>;
    topics_discussed: string[];
    sentiment: Sentiment;
    last_topic: string;
    last_interaction_at: string;
    memory_version: number;
}
export declare class MemoryEngineService {
    private genAI;
    private model;
    constructor();
    private _columnsChecked;
    private ensureColumns;
    getMemory(clientId: string): Promise<LeadContextMemory | null>;
    getMemoryByPhone(userId: string, phone: string, brandId?: string | null): Promise<{
        clientId: string;
        memory: LeadContextMemory;
    } | null>;
    updateMemoryFromMessage(userId: string, phone: string, newMessage: string, direction: "inbound" | "outbound", brandId?: string | null): Promise<void>;
    saveMemory(clientId: string, memory: Partial<LeadContextMemory>): Promise<void>;
    resetMemory(clientId: string): Promise<void>;
    buildPromptContext(memory: LeadContextMemory): string;
    private buildUpdatePrompt;
}
export declare const memoryEngine: MemoryEngineService;
//# sourceMappingURL=memoryEngine.d.ts.map