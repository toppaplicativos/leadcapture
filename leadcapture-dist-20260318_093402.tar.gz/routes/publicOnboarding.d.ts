declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=publicOnboarding.d.ts.map