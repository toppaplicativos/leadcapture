/**
 * ROTAS DE WEBHOOKS - Recebimento de Eventos do WhatsApp
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=webhooks.d.ts.map