type StoreStatus = "draft" | "active" | "archived";
type OrderStatus = "novo" | "confirmando_pagamento" | "aprovado" | "em_preparacao" | "saiu_para_entrega" | "entregue" | "cancelado";
type DeliveryStatus = "aguardando_confirmacao" | "confirmado" | "expirado" | "cancelado";
type DeliveryConfirmVia = "qr" | "token" | "admin";
type OrderRow = {
    id: string;
    order_number: string;
    store_id: string;
    status: OrderStatus;
    currency: string;
    subtotal: number | string;
    shipping: number | string;
    discount: number | string;
    total: number | string;
    payment_method: string | null;
    customer_name: string;
    customer_phone: string;
    customer_email: string | null;
    customer_address_json: string | null;
    items_json: string | null;
    delivery_token: string | null;
    delivery_status: DeliveryStatus | null;
    delivery_qr_data_url: string | null;
    courier_name: string | null;
    courier_phone: string | null;
    courier_route_url: string | null;
    delivered_at: string | null;
    delivery_confirmed_by: string | null;
    delivery_confirmed_via: DeliveryConfirmVia | null;
    notes: string | null;
    source: "site" | "whatsapp" | "admin";
    created_at: string;
    updated_at: string;
};
export declare class StorefrontService {
    private schemaReady;
    private schemaPromise;
    private productsService;
    private inventoryService;
    private columnExists;
    private ensureColumn;
    private mapStore;
    private mapTemplate;
    private parseObjectJson;
    private toIsoNow;
    private synchronizeStoreBrandIdentity;
    private synchronizeStoreProductsFromCatalog;
    synchronizeBrandStructure(userId: string, brandId?: string | null, options?: {
        syncProducts?: boolean;
    }): Promise<{
        id: string;
        owner_user_id: string;
        brand_id: string | null;
        slug: string;
        name: string;
        status: StoreStatus;
        template_id: string;
        brand: {};
        theme: {};
        settings: Record<string, any>;
        primary_domain: string | null;
        created_at: string;
        updated_at: string;
    } | null>;
    ensureSchema(): Promise<void>;
    private seedTemplates;
    private buildOwnedBrandScope;
    private getOwnedStoreRow;
    private resolveBrandSeed;
    private makeUniqueStoreSlug;
    private ensureSingleStoreForBrand;
    listTemplates(): Promise<{
        template_id: string;
        name: string;
        description: string;
        sections: string[];
        style: Record<string, any>;
    }[]>;
    listStores(userId: string, brandId?: string | null): Promise<{
        id: string;
        owner_user_id: string;
        brand_id: string | null;
        slug: string;
        name: string;
        status: StoreStatus;
        template_id: string;
        brand: {};
        theme: {};
        settings: Record<string, any>;
        primary_domain: string | null;
        created_at: string;
        updated_at: string;
    }[]>;
    getStoreById(userId: string, storeId: string, brandId?: string | null): Promise<{
        id: string;
        owner_user_id: string;
        brand_id: string | null;
        slug: string;
        name: string;
        status: StoreStatus;
        template_id: string;
        brand: {};
        theme: {};
        settings: Record<string, any>;
        primary_domain: string | null;
        created_at: string;
        updated_at: string;
    } | null>;
    createStore(userId: string, payload: Partial<{
        name: string;
        slug: string;
        status: StoreStatus;
        template_id: string;
        brand: Record<string, any>;
        theme: Record<string, any>;
        settings: Record<string, any>;
        custom_domain: string;
    }>, brandId?: string | null): Promise<{
        id: string;
        owner_user_id: string;
        brand_id: string | null;
        slug: string;
        name: string;
        status: StoreStatus;
        template_id: string;
        brand: {};
        theme: {};
        settings: Record<string, any>;
        primary_domain: string | null;
        created_at: string;
        updated_at: string;
    }>;
    updateStore(userId: string, storeId: string, payload: Partial<{
        name: string;
        slug: string;
        status: StoreStatus;
        template_id: string;
        brand: Record<string, any>;
        theme: Record<string, any>;
        settings: Record<string, any>;
    }>, brandId?: string | null): Promise<{
        id: string;
        owner_user_id: string;
        brand_id: string | null;
        slug: string;
        name: string;
        status: StoreStatus;
        template_id: string;
        brand: {};
        theme: {};
        settings: Record<string, any>;
        primary_domain: string | null;
        created_at: string;
        updated_at: string;
    } | null>;
    upsertDomain(userId: string, storeId: string, domainInput: string, makePrimary?: boolean, brandId?: string | null): Promise<any>;
    listDomains(userId: string, storeId: string, brandId?: string | null): Promise<any>;
    setPrimaryDomain(userId: string, storeId: string, domainInput: string, brandId?: string | null): Promise<any>;
    deleteDomain(userId: string, storeId: string, domainInput: string, brandId?: string | null): Promise<boolean>;
    getDomainInstructions(userId: string, storeId: string, domainInput: string, publicHostInput?: string | null, brandId?: string | null): Promise<{
        domain: string;
        verification: {
            type: string;
            host: string;
            value: string;
        };
        connection: {
            type: string;
            host: string;
            target: string | null;
            note: string;
        };
        expected_origin: string | null;
        verification_token: string;
    }>;
    verifyDomainOwnership(userId: string, storeId: string, domainInput: string, publicHostInput?: string | null, brandId?: string | null): Promise<{
        domain: string;
        verified: boolean;
        verification_status: string;
        checks: {
            txt_verified: boolean;
            cname_verified: boolean;
            a_resolved: boolean;
            txt_records: string[];
            cname_records: string[];
            a_records: string[];
        };
        instructions: {
            domain: string;
            verification: {
                type: string;
                host: string;
                value: string;
            };
            connection: {
                type: string;
                host: string;
                target: string | null;
                note: string;
            };
            expected_origin: string | null;
            verification_token: string;
        };
    }>;
    upsertProduct(userId: string, storeId: string, payload: Record<string, any>, brandId?: string | null): Promise<any>;
    listProducts(userId: string, storeId: string, brandId?: string | null): Promise<any>;
    upsertPage(userId: string, storeId: string, payload: Record<string, any>, brandId?: string | null): Promise<any>;
    listPages(userId: string, storeId: string, brandId?: string | null): Promise<any>;
    private extractStoreSettings;
    private getStoreByIdRaw;
    private getOrderRow;
    private appendOrderTimeline;
    private buildDeliveryAddress;
    private buildGoogleMapsRoute;
    private resolveConfirmBaseUrl;
    private buildConfirmUrl;
    private generateDeliveryToken;
    private createNotification;
    private queueCustomerMessage;
    private queuePostSale;
    private transitionOrderStatus;
    listOrders(userId: string, storeId: string, options?: {
        status?: string;
        limit?: number;
        offset?: number;
    }, brandId?: string | null): Promise<OrderRow[]>;
    listOrderTimeline(userId: string, storeId: string, orderId: string, brandId?: string | null): Promise<any>;
    getOrderFlowAutomation(userId: string, storeId: string, brandId?: string | null): Promise<{
        order_flow: any;
        logistics: any;
        notifications: any;
    }>;
    updateOrderFlowAutomation(userId: string, storeId: string, payload: Partial<{
        active: boolean;
        logistics: Record<string, any>;
        notifications: Record<string, any>;
    }>, brandId?: string | null): Promise<{
        order_flow: any;
        logistics: any;
        notifications: any;
    }>;
    dispatchPostSaleQueue(userId: string, storeId: string, limit?: number, brandId?: string | null): Promise<{
        total: number;
        sent: number;
        failed: number;
    }>;
    confirmOrderPayment(userId: string, storeId: string, orderId: string, actorName?: string, brandId?: string | null): Promise<OrderRow>;
    startOrderPreparation(userId: string, storeId: string, orderId: string, actorName?: string, brandId?: string | null): Promise<OrderRow>;
    sendOrderOutForDelivery(userId: string, storeId: string, orderId: string, payload?: {
        courier_name?: string;
        courier_phone?: string;
        eta_minutes?: number;
    }, brandId?: string | null): Promise<{
        order: OrderRow;
        delivery: {
            token: string;
            confirm_url: string;
            qr_data_url: string;
            route_url: string | null;
            eta_minutes: number;
            courier_name: string | null;
            courier_phone: string | null;
        };
    }>;
    private completeDelivery;
    confirmOrderDeliveryByAdmin(userId: string, storeId: string, orderId: string, actorName?: string, brandId?: string | null): Promise<OrderRow>;
    confirmOrderDeliveryByToken(tokenInput: string, via?: DeliveryConfirmVia, actorName?: string): Promise<{
        order: OrderRow;
        already_confirmed: boolean;
    }>;
    updateOrderStatus(userId: string, storeId: string, orderId: string, status: OrderStatus, brandId?: string | null): Promise<OrderRow | null>;
    listOrderNotifications(userId: string, storeId: string, orderId: string, brandId?: string | null): Promise<any>;
    resolvePublicStore(input: {
        slug?: string;
        host?: string | null;
    }): Promise<{
        store: {
            id: string;
            owner_user_id: string;
            brand_id: string | null;
            slug: string;
            name: string;
            status: StoreStatus;
            template_id: string;
            brand: {};
            theme: {};
            settings: Record<string, any>;
            primary_domain: string | null;
            created_at: string;
            updated_at: string;
        };
        template: {
            template_id: string;
            name: string;
            description: string;
            sections: string[];
            style: Record<string, any>;
        } | null;
        products: any;
        pages: any;
        domains: string[];
    } | null>;
    getPublicProduct(storeSlug: string, productSlug: string): Promise<any>;
    getPublicPage(storeSlug: string, pageSlug: string): Promise<any>;
    /** Find existing customer by phone (preferred) or email, or create a new record */
    private findOrCreateCustomer;
    createPublicOrder(storeSlug: string, payload: {
        items: Array<{
            product_id: string;
            quantity: number;
        }>;
        customer: {
            name: string;
            phone: string;
            email?: string;
            address?: Record<string, any>;
        };
        payment_method?: string;
        notes?: string;
    }): Promise<{
        order: OrderRow;
        notifications: any;
        store: {
            id: string;
            slug: string;
            name: string;
        };
    }>;
    exportStoreAdminBundle(userId: string, storeId: string, brandId?: string | null): Promise<{
        store: {
            id: string;
            owner_user_id: string;
            brand_id: string | null;
            slug: string;
            name: string;
            status: StoreStatus;
            template_id: string;
            brand: {};
            theme: {};
            settings: Record<string, any>;
            primary_domain: string | null;
            created_at: string;
            updated_at: string;
        };
        template: {
            template_id: string;
            name: string;
            description: string;
            sections: string[];
            style: Record<string, any>;
        } | null;
        domains: any;
        products: any;
        pages: any;
    } | null>;
    markDomainVerified(storeId: string, domainInput: string): Promise<boolean>;
    transactionalHealthCheck(): Promise<boolean>;
    private generateOrderNumber;
    private createOrderNotifications;
    private ensureDefaultPagesForStore;
}
export {};
//# sourceMappingURL=storefront.d.ts.map