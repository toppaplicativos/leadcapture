"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompaniesService = void 0;
const uuid_1 = require("uuid");
const database_1 = require("../config/database");
class CompaniesService {
    constructor() {
        this.brandColumnChecked = false;
        this.hasBrandColumn = false;
    }
    async ensureBrandColumn() {
        if (this.brandColumnChecked)
            return;
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.execute("SHOW COLUMNS FROM companies LIKE 'brand_id'");
        if (!rows.length) {
            await pool.execute("ALTER TABLE companies ADD COLUMN brand_id VARCHAR(36) NULL");
        }
        this.hasBrandColumn = true;
        this.brandColumnChecked = true;
    }
    async create(userId, data, brandId) {
        await this.ensureBrandColumn();
        const pool = (0, database_1.getPool)();
        const id = (0, uuid_1.v4)();
        const normalizedBrandId = String(brandId || "").trim() || null;
        if (this.hasBrandColumn) {
            await pool.execute(`INSERT INTO companies (id, user_id, brand_id, name, cnpj, phone, email, address, city, state, zip_code, logo_url, website, industry, description)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [id, userId, normalizedBrandId, data.name, data.cnpj || null, data.phone || null, data.email || null,
                data.address || null, data.city || null, data.state || null, data.zip_code || null,
                data.logo_url || null, data.website || null, data.industry || null, data.description || null]);
        }
        else {
            await pool.execute(`INSERT INTO companies (id, user_id, name, cnpj, phone, email, address, city, state, zip_code, logo_url, website, industry, description)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [id, userId, data.name, data.cnpj || null, data.phone || null, data.email || null,
                data.address || null, data.city || null, data.state || null, data.zip_code || null,
                data.logo_url || null, data.website || null, data.industry || null, data.description || null]);
        }
        return this.getById(id, userId, brandId);
    }
    async getById(id, userId, brandId) {
        await this.ensureBrandColumn();
        const pool = (0, database_1.getPool)();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = this.hasBrandColumn
            ? normalizedBrandId
                ? " AND brand_id = ?"
                : " AND brand_id IS NULL"
            : "";
        const params = this.hasBrandColumn
            ? normalizedBrandId
                ? [id, userId, normalizedBrandId]
                : [id, userId]
            : [id, userId];
        const [rows] = await pool.execute(`SELECT * FROM companies WHERE id = ? AND user_id = ?${brandClause} AND is_active = TRUE`, params);
        return rows[0] || null;
    }
    async getAll(userId, brandId) {
        await this.ensureBrandColumn();
        const pool = (0, database_1.getPool)();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = this.hasBrandColumn
            ? normalizedBrandId
                ? " AND brand_id = ?"
                : " AND brand_id IS NULL"
            : "";
        const params = this.hasBrandColumn
            ? normalizedBrandId
                ? [userId, normalizedBrandId]
                : [userId]
            : [userId];
        const [rows] = await pool.execute(`SELECT * FROM companies WHERE user_id = ?${brandClause} AND is_active = TRUE ORDER BY created_at DESC`, params);
        return rows;
    }
    async update(id, userId, data, brandId) {
        await this.ensureBrandColumn();
        const pool = (0, database_1.getPool)();
        const fields = [];
        const values = [];
        for (const [key, value] of Object.entries(data)) {
            if (value !== undefined) {
                fields.push(`${key} = ?`);
                values.push(value);
            }
        }
        if (fields.length === 0)
            return this.getById(id, userId, brandId);
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = this.hasBrandColumn
            ? normalizedBrandId
                ? " AND brand_id = ?"
                : " AND brand_id IS NULL"
            : "";
        if (this.hasBrandColumn && normalizedBrandId) {
            values.push(id, userId, normalizedBrandId);
        }
        else {
            values.push(id, userId);
        }
        await pool.execute(`UPDATE companies SET ${fields.join(", ")} WHERE id = ? AND user_id = ?${brandClause}`, values);
        return this.getById(id, userId, brandId);
    }
    async delete(id, userId, brandId) {
        await this.ensureBrandColumn();
        const pool = (0, database_1.getPool)();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = this.hasBrandColumn
            ? normalizedBrandId
                ? " AND brand_id = ?"
                : " AND brand_id IS NULL"
            : "";
        const params = this.hasBrandColumn
            ? normalizedBrandId
                ? [id, userId, normalizedBrandId]
                : [id, userId]
            : [id, userId];
        const [result] = await pool.execute(`UPDATE companies SET is_active = FALSE WHERE id = ? AND user_id = ?${brandClause}`, params);
        return result.affectedRows > 0;
    }
}
exports.CompaniesService = CompaniesService;
//# sourceMappingURL=companies.js.map