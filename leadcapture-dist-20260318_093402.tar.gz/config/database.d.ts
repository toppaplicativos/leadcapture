type CompatResult = {
    affectedRows: number;
    insertId: number;
    rowCount: number;
    command: string;
};
type CompatQueryTuple<T = any> = [T, CompatResult];
type CompatClient = {
    query<T = any>(sql: string, params?: any[]): Promise<CompatQueryTuple<T>>;
    execute<T = any>(sql: string, params?: any[]): Promise<CompatQueryTuple<T>>;
    release(): void;
};
type CompatPool = {
    query<T = any>(sql: string, params?: any[]): Promise<CompatQueryTuple<T>>;
    execute<T = any>(sql: string, params?: any[]): Promise<CompatQueryTuple<T>>;
    getConnection(): Promise<CompatClient>;
    end(): Promise<void>;
};
export declare function getPool(): CompatPool;
export declare function query<T = any>(sql: string, params?: any[]): Promise<T>;
export declare function queryOne<T = any>(sql: string, params?: any[]): Promise<T | null>;
export declare function insert(sql: string, params?: any[]): Promise<number>;
export declare function update(sql: string, params?: any[]): Promise<number>;
export declare function testConnection(): Promise<boolean>;
export {};
//# sourceMappingURL=database.d.ts.map