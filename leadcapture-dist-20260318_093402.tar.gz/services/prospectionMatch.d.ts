export interface ProductForMatch {
    id: string;
    name: string;
    description?: string | null;
    category?: string | null;
    price?: number;
}
export interface MatchScoreResult {
    product_id: string;
    score: number;
    grade: "A" | "B" | "C" | "D";
    demand_intent: string;
    supply_profile: string;
    reasoning: string;
    is_relevant: boolean;
}
export interface BulkMatchResult {
    query: string;
    results: MatchScoreResult[];
    total: number;
    relevant_count: number;
}
export declare class ProspectionMatchService {
    private genAI;
    private model;
    constructor();
    scoreMatch(query: string, product: ProductForMatch): Promise<MatchScoreResult>;
    scoreBulk(query: string, products: ProductForMatch[]): Promise<BulkMatchResult>;
    quickTextScore(query: string, product: ProductForMatch): number;
    private buildSinglePrompt;
    private buildBulkPrompt;
    private fallbackScore;
}
//# sourceMappingURL=prospectionMatch.d.ts.map