interface AIMessageOptions {
    tone?: "formal" | "casual" | "friendly" | "professional";
    maxLength?: number;
    language?: string;
    includeEmojis?: boolean;
    context?: string;
    agentName?: string;
    objective?: string;
    communicationRules?: string;
    trainingNotes?: string;
    preferredTerms?: string[];
    forbiddenTerms?: string[];
}
interface AIAnalysisResult {
    sentiment: "positive" | "negative" | "neutral";
    intent: string;
    suggestedResponse: string;
    keywords: string[];
}
export declare class AIService {
    private genAI;
    private model;
    constructor();
    generateCustomMessage(prompt: string, options?: AIMessageOptions): Promise<string>;
    analyzeMessage(message: string): Promise<AIAnalysisResult>;
    improveMessage(originalMessage: string, instructions?: string): Promise<string>;
    generateBulkVariations(baseMessage: string, count?: number): Promise<string[]>;
    generateFromTemplate(templateName: string, variables: Record<string, string>): Promise<string>;
}
export {};
//# sourceMappingURL=ai.d.ts.map