import { KnowledgeBase, KnowledgeBaseCreateDTO } from "../types";
export declare class KnowledgeBaseService {
    private columnsCache;
    private tableColumnsCache;
    private getColumns;
    private hasColumn;
    private isNumericType;
    private tableExists;
    private getTableColumns;
    private resolveCompaniesOwnerColumn;
    private findOrCreateCompanyId;
    private resolveCompanyIdForInsert;
    private resolveOwnerColumn;
    private resolveActiveColumn;
    private parseEnumValues;
    private normalizeCategory;
    private normalizeTags;
    create(userId: string, dto: KnowledgeBaseCreateDTO): Promise<KnowledgeBase>;
    getById(id: string | number, userId: string): Promise<KnowledgeBase | null>;
    getAll(filters?: {
        category?: string;
        search?: string;
        active?: boolean;
        company_id?: string;
        user_id?: string;
    }): Promise<KnowledgeBase[]>;
    update(id: string | number, userId: string, data: Partial<KnowledgeBaseCreateDTO>): Promise<KnowledgeBase | null>;
    delete(id: string | number, userId: string): Promise<boolean>;
    searchForContext(searchQuery: string, userId: string, companyId?: string): Promise<string>;
}
//# sourceMappingURL=knowledgeBase.d.ts.map