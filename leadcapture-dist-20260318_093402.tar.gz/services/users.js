"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const uuid_1 = require("uuid");
const database_1 = require("../config/database");
const config_1 = require("../config");
const logger_1 = require("../utils/logger");
class UsersService {
    signToken(user) {
        const payload = {
            userId: user.id,
            email: user.email,
            role: user.role,
        };
        return jsonwebtoken_1.default.sign(payload, config_1.config.jwtSecret, {
            expiresIn: config_1.config.jwtExpiresIn,
        });
    }
    async create(dto) {
        const normalizedEmail = String(dto.email || "").trim().toLowerCase();
        const normalizedName = String(dto.name || "").trim();
        const normalizedPhone = String(dto.phone || "").trim() || undefined;
        const normalizedPassword = String(dto.password || "");
        const existing = await (0, database_1.queryOne)("SELECT id FROM users WHERE LOWER(email) = LOWER(?)", [normalizedEmail]);
        if (existing) {
            throw new Error("Email already registered");
        }
        const id = (0, uuid_1.v4)();
        const password_hash = await bcryptjs_1.default.hash(normalizedPassword, 12);
        await (0, database_1.query)(`INSERT INTO users (id, email, password_hash, name, phone, role, is_active)
       VALUES (?, ?, ?, ?, ?, ?, true)`, [id, normalizedEmail, password_hash, normalizedName, normalizedPhone || null, dto.role || "operator"]);
        logger_1.logger.info(`User created: ${normalizedEmail} (ID: ${id})`);
        const user = await this.getById(id);
        return user;
    }
    async login(dto) {
        const normalizedEmail = String(dto.email || "").trim().toLowerCase();
        const normalizedPassword = String(dto.password || "").trim();
        const user = await (0, database_1.queryOne)("SELECT * FROM users WHERE LOWER(email) = LOWER(?) AND is_active = true", [normalizedEmail]);
        if (!user) {
            throw new Error("Invalid credentials");
        }
        const valid = await bcryptjs_1.default.compare(normalizedPassword, user.password_hash);
        if (!valid) {
            throw new Error("Invalid credentials");
        }
        await (0, database_1.query)("UPDATE users SET last_login_at = NOW() WHERE id = ?", [user.id]);
        const token = this.signToken(user);
        const { password_hash, ...safeUser } = user;
        logger_1.logger.info(`User logged in: ${normalizedEmail}`);
        return { token, user: safeUser };
    }
    async getById(id) {
        const user = await (0, database_1.queryOne)("SELECT * FROM users WHERE id = ?", [id]);
        if (!user)
            return null;
        const { password_hash, ...safeUser } = user;
        return safeUser;
    }
    async getAll() {
        const users = await (0, database_1.query)("SELECT * FROM users ORDER BY created_at DESC");
        return users.map(({ password_hash, ...u }) => u);
    }
    async updateUser(id, data) {
        const fields = [];
        const values = [];
        if (data.name) {
            fields.push("name = ?");
            values.push(data.name);
        }
        if (data.email) {
            fields.push("email = ?");
            values.push(data.email);
        }
        if (data.phone) {
            fields.push("phone = ?");
            values.push(data.phone);
        }
        if (data.role) {
            fields.push("role = ?");
            values.push(data.role);
        }
        if (data.password) {
            const hash = await bcryptjs_1.default.hash(data.password, 12);
            fields.push("password_hash = ?");
            values.push(hash);
        }
        if (fields.length === 0)
            return this.getById(id);
        values.push(id);
        await (0, database_1.query)(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`, values);
        logger_1.logger.info(`User updated: ID ${id}`);
        return this.getById(id);
    }
    async deactivate(id) {
        const rows = await (0, database_1.query)("UPDATE users SET is_active = false WHERE id = ?", [id]);
        return rows.affectedRows > 0;
    }
    static verifyToken(token) {
        return jsonwebtoken_1.default.verify(token, config_1.config.jwtSecret);
    }
}
exports.UsersService = UsersService;
//# sourceMappingURL=users.js.map