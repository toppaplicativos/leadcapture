import { GooglePlaceV2 } from "../types";
type SearchProviderPreference = "rapid_first" | "official_first" | "rapid_only" | "official_only";
type SearchFieldProfile = "full" | "radar";
export declare class GooglePlacesService {
    private buildTextQuery;
    private getPlacesFieldMask;
    private sanitizeMaxResults;
    private needsDetails;
    private mergePlace;
    private resolveProviderChain;
    private searchTextRapidApiPage;
    private searchTextGoogleOfficialPage;
    /**
     * Search for businesses using the new RapidAPI Google Places V2
     * Primary endpoint for lead capture
     */
    searchText(params: {
        query: string;
        location?: string;
        latitude?: number;
        longitude?: number;
        radius?: number;
        maxResults?: number;
        languageCode?: string;
        providerPreference?: SearchProviderPreference;
        includeDetails?: boolean;
        fieldProfile?: SearchFieldProfile;
    }): Promise<GooglePlaceV2[]>;
    /**
     * Get detailed info for a single place by ID
     */
    getPlaceDetails(placeId: string): Promise<GooglePlaceV2 | null>;
    /**
     * Search and return results formatted for the legacy Lead interface
     * (backward compatible with existing UI)
     */
    searchForLeads(params: {
        query: string;
        location: string;
        radius?: number;
        maxResults?: number;
    }): Promise<any[]>;
}
export {};
//# sourceMappingURL=googlePlaces.d.ts.map