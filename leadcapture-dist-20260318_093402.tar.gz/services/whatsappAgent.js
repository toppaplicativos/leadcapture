"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhatsAppAgentService = void 0;
const database_1 = require("../config/database");
const ai_1 = require("./ai");
const aiAgentProfile_1 = require("./aiAgentProfile");
const knowledgeBase_1 = require("./knowledgeBase");
const products_1 = require("./products");
const logger_1 = require("../utils/logger");
class WhatsAppAgentService {
    constructor() {
        this.aiService = new ai_1.AIService();
        this.aiAgentProfileService = new aiAgentProfile_1.AIAgentProfileService();
        this.knowledgeBaseService = new knowledgeBase_1.KnowledgeBaseService();
        this.productsService = new products_1.ProductsService();
        this.productsUserScopeReady = null;
    }
    normalizeBrandId(value) {
        const normalized = String(value || "").trim();
        return normalized || null;
    }
    async ensureProductsUserScope() {
        if (this.productsUserScopeReady !== null)
            return this.productsUserScopeReady;
        const row = await (0, database_1.queryOne)("SHOW COLUMNS FROM products LIKE 'user_id'");
        this.productsUserScopeReady = Boolean(row);
        return this.productsUserScopeReady;
    }
    buildCatalogContext(products) {
        const lines = products
            .slice(0, 12)
            .map((product, index) => {
            const name = String(product?.name || "").trim();
            const category = String(product?.category || "").trim();
            const description = String(product?.description || "").trim().replace(/\s+/g, " ").slice(0, 160);
            const price = Number(product?.price || 0);
            const promoPrice = Number(product?.promoPrice || 0);
            const features = Array.isArray(product?.features)
                ? product.features.map((item) => String(item || "").trim()).filter(Boolean).slice(0, 3)
                : [];
            const priceLabel = promoPrice > 0
                ? `R$ ${promoPrice.toFixed(2)} promocional (de R$ ${price.toFixed(2)})`
                : price > 0
                    ? `R$ ${price.toFixed(2)}`
                    : "preço sob consulta";
            return [
                `${index + 1}. ${name}`,
                category ? `categoria: ${category}` : "",
                priceLabel,
                description ? `descrição: ${description}` : "",
                features.length ? `destaques: ${features.join(", ")}` : "",
            ]
                .filter(Boolean)
                .join(" | ");
        })
            .filter(Boolean);
        if (!lines.length)
            return "";
        return [
            "CATALOGO OFICIAL DA BRAND:",
            ...lines,
            "REGRA CRÍTICA: cite apenas produtos, categorias e preços presentes nesta lista. Se o item pedido não estiver aqui, diga que vai confirmar internamente antes de prometer qualquer coisa.",
        ].join("\n");
    }
    async getCatalogContext(userId, brandId) {
        try {
            const normalizedBrandId = this.normalizeBrandId(brandId);
            const hasUserScope = await this.ensureProductsUserScope();
            const products = hasUserScope
                ? await this.productsService.getActiveProducts(userId, normalizedBrandId)
                : await this.productsService.getActiveProducts(undefined, normalizedBrandId);
            return this.buildCatalogContext(products);
        }
        catch (error) {
            logger_1.logger.warn(`Failed to build WhatsApp catalog context: ${error?.message || error}`);
            return "";
        }
    }
    buildWhatsAppOperatingBlock(profile) {
        const rules = [
            "CANAL: WhatsApp.",
            "Responda como consultor comercial humano e ágil, sem parecer robótico.",
            "Escreva em blocos curtos, com leitura fácil no celular.",
            "Faça no máximo 1 pergunta objetiva por mensagem quando precisar avançar a conversa.",
            "Se houver intenção de compra, priorize qualificação, próximo passo e clareza comercial.",
            "Não use markdown, listas longas ou texto excessivo.",
            "Não invente prazo, estoque, preço, promoção, política ou garantia.",
            "Se faltar informação, admita isso e diga que vai confirmar.",
            "Quando fizer sentido, proponha continuação natural da conversa no próprio WhatsApp.",
        ];
        if (profile.objective?.trim()) {
            rules.push(`META DE NEGÓCIO: ${profile.objective.trim()}`);
        }
        return rules.join("\n");
    }
    async generateReply(input) {
        const userId = String(input.userId || "").trim();
        if (!userId) {
            throw new Error("userId is required");
        }
        const brandId = this.normalizeBrandId(input.brandId);
        const incomingMessage = String(input.incomingMessage || "").trim();
        if (!incomingMessage) {
            throw new Error("incomingMessage is required");
        }
        const historyLines = Array.isArray(input.conversationHistory)
            ? input.conversationHistory.map((line) => String(line || "").trim()).filter(Boolean)
            : [];
        const recentHistory = historyLines.slice(-Math.max(1, Math.min(Number(input.maxHistoryLines || 12), 20)));
        const profile = await this.aiAgentProfileService.getByUserId(userId, brandId || undefined);
        const [kbContext, behaviorBlock, whatsappBlock, catalogContext] = await Promise.all([
            this.knowledgeBaseService.searchForContext(incomingMessage, userId, brandId || profile.company_id),
            Promise.resolve(this.aiAgentProfileService.buildBehaviorBlock(profile)),
            Promise.resolve(this.buildWhatsAppOperatingBlock(profile)),
            this.getCatalogContext(userId, brandId),
        ]);
        const mergedContext = [
            recentHistory.length ? `HISTÓRICO RECENTE:\n${recentHistory.join("\n")}` : "",
            whatsappBlock,
            behaviorBlock,
            catalogContext,
            kbContext ? `BASE DE CONHECIMENTO RELEVANTE:\n${kbContext}` : "",
        ]
            .filter(Boolean)
            .join("\n\n");
        const text = await this.aiService.generateCustomMessage(incomingMessage, {
            tone: profile.tone,
            context: mergedContext,
            maxLength: Math.max(180, Math.min(Number(profile.max_length || 500), 900)),
            language: profile.language,
            includeEmojis: profile.include_emojis,
            agentName: profile.agent_name,
            objective: profile.objective,
            trainingNotes: profile.training_notes,
            preferredTerms: profile.preferred_terms,
            forbiddenTerms: profile.forbidden_terms,
            communicationRules: [
                String(profile.communication_rules || "").trim(),
                "Sempre mantenha a resposta pronta para WhatsApp: curta, útil e com próximo passo claro.",
            ]
                .filter(Boolean)
                .join("\n"),
        });
        return {
            text: String(text || "").trim(),
            profile,
            knowledgeApplied: Boolean(kbContext),
            catalogApplied: Boolean(catalogContext),
        };
    }
}
exports.WhatsAppAgentService = WhatsAppAgentService;
//# sourceMappingURL=whatsappAgent.js.map