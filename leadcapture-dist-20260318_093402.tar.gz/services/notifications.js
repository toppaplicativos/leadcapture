"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
exports.getNotificationService = getNotificationService;
const crypto_1 = require("crypto");
const database_1 = require("../config/database");
const config_1 = require("../config");
const logger_1 = require("../utils/logger");
const socketManager_1 = require("../core/socketManager");
class NotificationService {
    constructor() {
        this.schemaReady = false;
    }
    async ensureSchema() {
        if (this.schemaReady)
            return;
        const pool = (0, database_1.getPool)();
        if (config_1.config.postgres.connectionString || config_1.config.postgres.host) {
            await pool.execute(`
        CREATE TABLE IF NOT EXISTS notifications (
          id VARCHAR(64) PRIMARY KEY,
          user_id VARCHAR(36) NOT NULL,
          type VARCHAR(20) NOT NULL,
          event VARCHAR(120) NOT NULL,
          title VARCHAR(190) NOT NULL,
          message TEXT NOT NULL,
          priority VARCHAR(20) NOT NULL DEFAULT 'medium',
          channels_json JSONB NULL,
          metadata_json JSONB NULL,
          store_id VARCHAR(64) NULL,
          is_read BOOLEAN NOT NULL DEFAULT FALSE,
          read_at TIMESTAMP NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications (user_id, created_at)
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications (user_id, is_read)
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notifications_priority ON notifications (priority)
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notifications_event ON notifications (event)
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notifications_store ON notifications (store_id)
      `);
            await pool.execute(`
        CREATE TABLE IF NOT EXISTS notification_deliveries (
          id BIGSERIAL PRIMARY KEY,
          notification_id VARCHAR(64) NOT NULL,
          channel VARCHAR(20) NOT NULL,
          status VARCHAR(20) NOT NULL DEFAULT 'queued',
          recipient VARCHAR(255) NULL,
          provider_message_id VARCHAR(255) NULL,
          error_message TEXT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notification_deliveries_notification ON notification_deliveries (notification_id)
      `);
            await pool.execute(`
        CREATE INDEX IF NOT EXISTS idx_notification_deliveries_status ON notification_deliveries (status)
      `);
            await pool.execute(`
        CREATE TABLE IF NOT EXISTS notification_preferences (
          user_id VARCHAR(36) PRIMARY KEY,
          preferences_json JSONB NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            this.schemaReady = true;
            return;
        }
        await pool.execute(`
      CREATE TABLE IF NOT EXISTS notifications (
        id VARCHAR(64) PRIMARY KEY,
        user_id VARCHAR(36) NOT NULL,
        type ENUM('system','user','support') NOT NULL,
        event VARCHAR(120) NOT NULL,
        title VARCHAR(190) NOT NULL,
        message TEXT NOT NULL,
        priority ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
        channels_json JSON NULL,
        metadata_json JSON NULL,
        store_id VARCHAR(64) NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        read_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_notifications_user_created (user_id, created_at),
        INDEX idx_notifications_user_read (user_id, is_read),
        INDEX idx_notifications_priority (priority),
        INDEX idx_notifications_event (event),
        INDEX idx_notifications_store (store_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
        await pool.execute(`
      CREATE TABLE IF NOT EXISTS notification_deliveries (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        notification_id VARCHAR(64) NOT NULL,
        channel ENUM('in_app','email','whatsapp','push','webhook') NOT NULL,
        status ENUM('queued','sent','failed','skipped') NOT NULL DEFAULT 'queued',
        recipient VARCHAR(255) NULL,
        provider_message_id VARCHAR(255) NULL,
        error_message TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_notification_deliveries_notification (notification_id),
        INDEX idx_notification_deliveries_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
        await pool.execute(`
      CREATE TABLE IF NOT EXISTS notification_preferences (
        user_id VARCHAR(36) PRIMARY KEY,
        preferences_json JSON NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
        this.schemaReady = true;
    }
    normalizeChannels(channels) {
        const allowed = ["in_app", "email", "whatsapp", "push", "webhook"];
        const unique = new Set();
        for (const channel of channels || []) {
            const normalized = String(channel || "").trim().toLowerCase();
            if (allowed.includes(normalized))
                unique.add(normalized);
        }
        if (unique.size === 0)
            unique.add("in_app");
        return Array.from(unique);
    }
    parseJson(value, fallback) {
        if (value === null || value === undefined)
            return fallback;
        if (typeof value === "object")
            return value;
        if (typeof value !== "string")
            return fallback;
        try {
            return JSON.parse(value);
        }
        catch {
            return fallback;
        }
    }
    async getPreferences(userId) {
        await this.ensureSchema();
        const row = await (0, database_1.queryOne)("SELECT preferences_json FROM notification_preferences WHERE user_id = ? LIMIT 1", [userId]);
        if (!row?.preferences_json)
            return {};
        return this.parseJson(row.preferences_json, {});
    }
    async updatePreferences(userId, preferences) {
        await this.ensureSchema();
        const normalized = {};
        for (const [event, channels] of Object.entries(preferences || {})) {
            const eventKey = String(event || "").trim();
            if (!eventKey)
                continue;
            normalized[eventKey] = this.normalizeChannels(channels);
        }
        const pool = (0, database_1.getPool)();
        await pool.execute(`INSERT INTO notification_preferences (user_id, preferences_json)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE preferences_json = VALUES(preferences_json), updated_at = NOW()`, [userId, JSON.stringify(normalized)]);
        return normalized;
    }
    async resolveChannelsForUser(userId, event, requested) {
        const base = this.normalizeChannels(requested);
        const prefs = await this.getPreferences(userId);
        const fromPreference = prefs[String(event || "").trim()] || prefs["*"];
        if (!fromPreference || fromPreference.length === 0)
            return base;
        // Preferences override explicit channels to respect user choice
        return this.normalizeChannels(fromPreference);
    }
    async recordDelivery(notificationId, channel, status, recipient, errorMessage) {
        const pool = (0, database_1.getPool)();
        await pool.execute(`INSERT INTO notification_deliveries (notification_id, channel, status, recipient, error_message)
       VALUES (?, ?, ?, ?, ?)`, [notificationId, channel, status, recipient || null, errorMessage || null]);
    }
    async dispatchChannel(channel, notification) {
        // In-app is persisted by default; realtime handled outside as broadcast.
        if (channel === "in_app") {
            await this.recordDelivery(notification.notification_id, channel, "sent", notification.user_id);
            return;
        }
        // Initial enterprise scaffolding for external channels.
        // You can plug providers here (SES/Sendgrid, Evolution API, FCM, webhook queues).
        try {
            if (channel === "email") {
                await this.recordDelivery(notification.notification_id, channel, "sent", notification.user_id);
                logger_1.logger.info(`[Notification] email sent placeholder: ${notification.event} -> ${notification.user_id}`);
                return;
            }
            if (channel === "whatsapp") {
                await this.recordDelivery(notification.notification_id, channel, "sent", notification.user_id);
                logger_1.logger.info(`[Notification] whatsapp sent placeholder: ${notification.event} -> ${notification.user_id}`);
                return;
            }
            if (channel === "push") {
                await this.recordDelivery(notification.notification_id, channel, "sent", notification.user_id);
                logger_1.logger.info(`[Notification] push sent placeholder: ${notification.event} -> ${notification.user_id}`);
                return;
            }
            if (channel === "webhook") {
                await this.recordDelivery(notification.notification_id, channel, "sent", notification.user_id);
                logger_1.logger.info(`[Notification] webhook sent placeholder: ${notification.event} -> ${notification.user_id}`);
                return;
            }
            await this.recordDelivery(notification.notification_id, channel, "skipped", notification.user_id);
        }
        catch (error) {
            await this.recordDelivery(notification.notification_id, channel, "failed", notification.user_id, String(error?.message || error));
        }
    }
    async createNotification(input) {
        await this.ensureSchema();
        const notificationId = `ntf_${(0, crypto_1.randomUUID)()}`;
        const priority = ["low", "medium", "high", "critical"].includes(input.priority)
            ? input.priority
            : "medium";
        const userId = String(input.user_id || "").trim();
        const event = String(input.event || "").trim();
        if (!userId)
            throw new Error("user_id is required");
        if (!event)
            throw new Error("event is required");
        const channels = await this.resolveChannelsForUser(userId, event, input.channels);
        const payload = {
            notification_id: notificationId,
            type: input.type,
            event,
            title: String(input.title || "Notificação").trim() || "Notificação",
            message: String(input.message || "").trim(),
            priority,
            channels,
            read: false,
            user_id: userId,
            store_id: input.store_id ? String(input.store_id) : null,
            created_at: new Date().toISOString(),
            metadata: input.metadata && typeof input.metadata === "object" ? input.metadata : {},
        };
        const pool = (0, database_1.getPool)();
        await pool.execute(`INSERT INTO notifications (
        id, user_id, type, event, title, message, priority,
        channels_json, metadata_json, store_id, is_read
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE)`, [
            payload.notification_id,
            payload.user_id,
            payload.type,
            payload.event,
            payload.title,
            payload.message,
            payload.priority,
            JSON.stringify(payload.channels),
            JSON.stringify(payload.metadata || {}),
            payload.store_id ?? null,
        ]);
        // Dispatch channels async but awaited for deterministic result in API actions
        for (const channel of payload.channels) {
            await this.dispatchChannel(channel, payload);
        }
        socketManager_1.socketManager.emitNotification(userId, {
            id: payload.notification_id,
            type: payload.type,
            event: payload.event,
            title: payload.title,
            message: payload.message,
            priority: payload.priority,
            read: payload.read,
            created_at: payload.created_at,
            metadata: payload.metadata,
        });
        const unread = await this.getUnreadCount(userId);
        socketManager_1.socketManager.emitNotificationBadge(userId, unread);
        return payload;
    }
    mapRow(row) {
        return {
            notification_id: String(row.id),
            type: String(row.type),
            event: String(row.event),
            title: String(row.title),
            message: String(row.message),
            priority: String(row.priority),
            channels: this.parseJson(row.channels_json, ["in_app"]),
            read: Boolean(row.is_read),
            user_id: String(row.user_id),
            store_id: row.store_id ? String(row.store_id) : null,
            created_at: new Date(row.created_at).toISOString(),
            metadata: this.parseJson(row.metadata_json, {}),
        };
    }
    async listNotifications(filters) {
        await this.ensureSchema();
        const where = ["user_id = ?"];
        const params = [filters.user_id];
        if (filters.type) {
            where.push("type = ?");
            params.push(filters.type);
        }
        if (filters.priority) {
            where.push("priority = ?");
            params.push(filters.priority);
        }
        if (typeof filters.read === "boolean") {
            where.push("is_read = ?");
            params.push(filters.read ? 1 : 0);
        }
        if (filters.store_id) {
            where.push("store_id = ?");
            params.push(filters.store_id);
        }
        if (filters.q) {
            where.push("(title LIKE ? OR message LIKE ? OR event LIKE ?)");
            const q = `%${String(filters.q).trim()}%`;
            params.push(q, q, q);
        }
        const limit = Math.max(1, Math.min(200, Number(filters.limit || 20)));
        const offset = Math.max(0, Number(filters.offset || 0));
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query(`SELECT * FROM notifications WHERE ${where.join(" AND ")} ORDER BY created_at DESC LIMIT ? OFFSET ?`, [...params, limit, offset]);
        const [countRows] = await pool.query(`SELECT COUNT(*) AS total FROM notifications WHERE ${where.join(" AND ")}`, params);
        return {
            notifications: rows.map((row) => this.mapRow(row)),
            total: Number(countRows?.[0]?.total || 0),
        };
    }
    async getUnreadCount(userId) {
        await this.ensureSchema();
        const row = await (0, database_1.queryOne)("SELECT COUNT(*) AS total FROM notifications WHERE user_id = ? AND is_read = 0", [userId]);
        return Number(row?.total || 0);
    }
    async markAsRead(userId, notificationId) {
        await this.ensureSchema();
        const pool = (0, database_1.getPool)();
        const [result] = await pool.execute("UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ? AND user_id = ?", [notificationId, userId]);
        if (Number(result?.affectedRows || 0) > 0) {
            socketManager_1.socketManager.emitNotificationUpdated(userId, notificationId, { read: true });
            const unread = await this.getUnreadCount(userId);
            socketManager_1.socketManager.emitNotificationBadge(userId, unread);
            return true;
        }
        return false;
    }
    async markAllAsRead(userId) {
        await this.ensureSchema();
        const pool = (0, database_1.getPool)();
        const [result] = await pool.execute("UPDATE notifications SET is_read = 1, read_at = NOW() WHERE user_id = ? AND is_read = 0", [userId]);
        const affected = Number(result?.affectedRows || 0);
        socketManager_1.socketManager.emitToUser(userId, "notification:all-read", { affected });
        socketManager_1.socketManager.emitNotificationBadge(userId, 0);
        return affected;
    }
    async getAnalytics(userId) {
        await this.ensureSchema();
        const pool = (0, database_1.getPool)();
        const [totals] = await pool.query(`SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END) AS read_count,
          SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) AS unread_count,
          ROUND(AVG(CASE WHEN is_read = 1 AND read_at IS NOT NULL THEN TIMESTAMPDIFF(SECOND, created_at, read_at) END), 2) AS avg_time_to_read_seconds
       FROM notifications
       WHERE user_id = ?`, [userId]);
        const [byPriority] = await pool.query(`SELECT priority, COUNT(*) AS total
       FROM notifications
       WHERE user_id = ?
       GROUP BY priority`, [userId]);
        const [byEvent] = await pool.query(`SELECT event, COUNT(*) AS total
       FROM notifications
       WHERE user_id = ?
       GROUP BY event
       ORDER BY total DESC
       LIMIT 20`, [userId]);
        const [deliveryStats] = await pool.query(`SELECT channel, status, COUNT(*) AS total
       FROM notification_deliveries nd
       INNER JOIN notifications n ON n.id = nd.notification_id
       WHERE n.user_id = ?
       GROUP BY channel, status`, [userId]);
        return {
            totals: totals?.[0] || {},
            by_priority: byPriority || [],
            top_events: byEvent || [],
            deliveries: deliveryStats || [],
        };
    }
}
exports.NotificationService = NotificationService;
let notificationServiceInstance = null;
function getNotificationService() {
    if (!notificationServiceInstance) {
        notificationServiceInstance = new NotificationService();
    }
    return notificationServiceInstance;
}
//# sourceMappingURL=notifications.js.map