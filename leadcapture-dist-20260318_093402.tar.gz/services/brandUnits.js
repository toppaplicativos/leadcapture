"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrandUnitsService = void 0;
const crypto_1 = require("crypto");
const database_1 = require("../config/database");
const config_1 = require("../config");
function toSlug(value) {
    return String(value || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 120);
}
function normalizeLogoUrl(value) {
    const normalized = String(value ?? "").trim();
    if (!normalized)
        return null;
    return normalized;
}
class BrandUnitsService {
    constructor() {
        this.schemaReady = false;
        this.schemaReadyPromise = null;
    }
    async tableExists(tableName) {
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`, [tableName]);
        return Number(row?.total || 0) > 0;
    }
    async columnExists(tableName, columnName) {
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`, [tableName, columnName]);
        return Number(row?.total || 0) > 0;
    }
    async indexExists(tableName, indexName) {
        try {
            const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
         FROM pg_indexes
         WHERE tablename = ?
           AND indexname = ?`, [tableName, indexName]);
            return Number(row?.total || 0) > 0;
        }
        catch {
            try {
                const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
           FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`, [tableName, indexName]);
                return Number(row?.total || 0) > 0;
            }
            catch {
                try {
                    const rows = await (0, database_1.query)(`SHOW INDEX FROM ${tableName} WHERE Key_name = ?`, [indexName]);
                    return Array.isArray(rows) && rows.length > 0;
                }
                catch {
                    return false;
                }
            }
        }
    }
    async ensureTableBrandColumnAndIndex(tableName, columnName, indexName) {
        const exists = await this.tableExists(tableName);
        if (!exists)
            return;
        const hasColumn = await this.columnExists(tableName, columnName);
        if (!hasColumn) {
            await (0, database_1.query)(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} VARCHAR(36) NULL`);
        }
        const hasIndex = await this.indexExists(tableName, indexName);
        if (!hasIndex) {
            await (0, database_1.query)(`CREATE INDEX ${indexName} ON ${tableName} (${columnName})`);
        }
    }
    async ensureTableColumn(tableName, columnName, columnDefinition) {
        const exists = await this.tableExists(tableName);
        if (!exists)
            return;
        const hasColumn = await this.columnExists(tableName, columnName);
        if (!hasColumn) {
            await (0, database_1.query)(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${columnDefinition}`);
        }
    }
    async ensureSchema() {
        if (config_1.config.postgres.connectionString || config_1.config.postgres.host) {
            if (this.schemaReady)
                return;
            if (this.schemaReadyPromise) {
                await this.schemaReadyPromise;
                return;
            }
            this.schemaReadyPromise = (async () => {
                await (0, database_1.query)(`
          CREATE TABLE IF NOT EXISTS brand_units (
            id VARCHAR(36) PRIMARY KEY,
            user_id VARCHAR(36) NOT NULL,
            name VARCHAR(120) NOT NULL,
            slug VARCHAR(140) NOT NULL,
            logo_url TEXT NULL,
            site_url TEXT NULL,
            sales_page_url TEXT NULL,
            instagram_url TEXT NULL,
            facebook_url TEXT NULL,
            twitter_url TEXT NULL,
            tiktok_url TEXT NULL,
            slogan VARCHAR(255) NULL,
            primary_color VARCHAR(24) NULL,
            secondary_color VARCHAR(24) NULL,
            theme_json JSON NULL,
            voice_json JSON NULL,
            domain VARCHAR(255) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            is_default BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (user_id, slug)
          )
        `);
                await (0, database_1.query)(`
          CREATE TABLE IF NOT EXISTS user_brand_context (
            user_id VARCHAR(36) PRIMARY KEY,
            active_brand_id VARCHAR(36) NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
          )
        `);
                await this.ensureTableColumn("brand_units", "site_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "sales_page_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "instagram_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "facebook_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "twitter_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "tiktok_url", "TEXT NULL");
                await this.ensureTableColumn("brand_units", "slogan", "VARCHAR(255) NULL");
                await this.ensureTableColumn("brand_units", "primary_color", "VARCHAR(24) NULL");
                await this.ensureTableColumn("brand_units", "secondary_color", "VARCHAR(24) NULL");
                this.schemaReady = true;
            })().finally(() => {
                this.schemaReadyPromise = null;
            });
            await this.schemaReadyPromise;
            this.schemaReady = true;
            return;
        }
        if (this.schemaReady)
            return;
        if (this.schemaReadyPromise) {
            await this.schemaReadyPromise;
            return;
        }
        this.schemaReadyPromise = (async () => {
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS brand_units (
          id VARCHAR(36) PRIMARY KEY,
          user_id VARCHAR(36) NOT NULL,
          name VARCHAR(120) NOT NULL,
          slug VARCHAR(140) NOT NULL,
          logo_url TEXT NULL,
          site_url TEXT NULL,
          sales_page_url TEXT NULL,
          instagram_url TEXT NULL,
          facebook_url TEXT NULL,
          twitter_url TEXT NULL,
          tiktok_url TEXT NULL,
          slogan VARCHAR(255) NULL,
          primary_color VARCHAR(24) NULL,
          secondary_color VARCHAR(24) NULL,
          theme_json JSON NULL,
          voice_json JSON NULL,
          domain VARCHAR(255) NULL,
          status ENUM('active','archived') NOT NULL DEFAULT 'active',
          is_default TINYINT(1) NOT NULL DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_brand_user_slug (user_id, slug),
          KEY idx_brand_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await this.ensureTableColumn("brand_units", "site_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "sales_page_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "instagram_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "facebook_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "twitter_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "tiktok_url", "TEXT NULL");
            await this.ensureTableColumn("brand_units", "slogan", "VARCHAR(255) NULL");
            await this.ensureTableColumn("brand_units", "primary_color", "VARCHAR(24) NULL");
            await this.ensureTableColumn("brand_units", "secondary_color", "VARCHAR(24) NULL");
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS user_brand_context (
          user_id VARCHAR(36) PRIMARY KEY,
          active_brand_id VARCHAR(36) NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_brand_context_active (active_brand_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await this.ensureTableBrandColumnAndIndex("customers", "brand_id", "idx_customers_brand");
            await this.ensureTableBrandColumnAndIndex("message_log", "brand_id", "idx_message_log_brand");
            await this.ensureTableBrandColumnAndIndex("products", "brand_id", "idx_products_brand");
            await this.ensureTableBrandColumnAndIndex("categories", "brand_id", "idx_categories_brand");
            await this.ensureTableBrandColumnAndIndex("price_tables", "brand_id", "idx_price_tables_brand");
            await this.ensureTableBrandColumnAndIndex("expedition_dispatchers", "brand_id", "idx_expedition_dispatchers_brand");
            await this.ensureTableBrandColumnAndIndex("expedition_orders", "brand_id", "idx_expedition_orders_brand");
            await this.ensureTableBrandColumnAndIndex("whatsapp_instances", "brand_id", "idx_whatsapp_instances_brand");
            await this.ensureTableColumn("ai_agent_profiles", "company_id", "VARCHAR(36) NULL");
            const aiProfileCompanyIndexExists = await this.indexExists("ai_agent_profiles", "idx_ai_agent_profiles_company");
            if (!aiProfileCompanyIndexExists) {
                await (0, database_1.query)("CREATE INDEX idx_ai_agent_profiles_company ON ai_agent_profiles (company_id)");
            }
            this.schemaReady = true;
        })().finally(() => {
            this.schemaReadyPromise = null;
        });
        await this.schemaReadyPromise;
    }
    async list(userId) {
        await this.ensureSchema();
        const rows = await (0, database_1.query)(`SELECT * FROM brand_units WHERE user_id = ? ORDER BY is_default DESC, created_at ASC`, [userId]);
        return (rows || []).map((item) => this.hydrateBrandUnit(item));
    }
    async getById(userId, brandId) {
        await this.ensureSchema();
        const row = (await (0, database_1.queryOne)(`SELECT * FROM brand_units WHERE id = ? AND user_id = ? LIMIT 1`, [brandId, userId])) || null;
        return row ? this.hydrateBrandUnit(row) : null;
    }
    hydrateBrandUnit(item) {
        const next = { ...(item || {}) };
        let themeJsonParsed = next.theme_json;
        if (typeof themeJsonParsed === "string") {
            try {
                themeJsonParsed = JSON.parse(themeJsonParsed);
            }
            catch {
                themeJsonParsed = null;
            }
        }
        const fallbackLogo = normalizeLogoUrl(themeJsonParsed?.logo_url || themeJsonParsed?.logoUrl || themeJsonParsed?.logo);
        next.logo_url = normalizeLogoUrl(next.logo_url) || fallbackLogo;
        return next;
    }
    async create(userId, payload) {
        await this.ensureSchema();
        const name = String(payload.name || "").trim();
        if (!name)
            throw new Error("Brand name is required");
        const existingCount = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total FROM brand_units WHERE user_id = ?`, [userId]);
        const shouldBeDefault = Number(existingCount?.total || 0) === 0 || Boolean(payload.is_default);
        const slug = toSlug(payload.slug || name);
        if (!slug)
            throw new Error("Brand slug is invalid");
        if (shouldBeDefault) {
            await (0, database_1.update)(`UPDATE brand_units SET is_default = FALSE WHERE user_id = ?`, [userId]);
        }
        const id = (0, crypto_1.randomUUID)();
        await (0, database_1.query)(`INSERT INTO brand_units
       (id, user_id, name, slug, logo_url, site_url, sales_page_url, instagram_url, facebook_url, twitter_url, tiktok_url, slogan, primary_color, secondary_color, theme_json, voice_json, domain, status, is_default)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`, [
            id,
            userId,
            name,
            slug,
            normalizeLogoUrl(payload.logo_url),
            payload.site_url || null,
            payload.sales_page_url || null,
            payload.instagram_url || null,
            payload.facebook_url || null,
            payload.twitter_url || null,
            payload.tiktok_url || null,
            payload.slogan || null,
            payload.primary_color || null,
            payload.secondary_color || null,
            payload.theme_json ? JSON.stringify(payload.theme_json) : null,
            payload.voice_json ? JSON.stringify(payload.voice_json) : null,
            payload.domain || null,
            shouldBeDefault,
        ]);
        if (shouldBeDefault) {
            await this.setActiveBrand(userId, id);
        }
        const created = await this.getById(userId, id);
        if (!created)
            throw new Error("Failed to create brand unit");
        return created;
    }
    async update(userId, brandId, payload) {
        await this.ensureSchema();
        const fields = [];
        const values = [];
        if (payload.name !== undefined) {
            const name = String(payload.name || "").trim();
            if (!name)
                throw new Error("Brand name is required");
            fields.push("name = ?");
            values.push(name);
        }
        if (payload.slug !== undefined) {
            const slug = toSlug(payload.slug);
            if (!slug)
                throw new Error("Brand slug is invalid");
            fields.push("slug = ?");
            values.push(slug);
        }
        if (payload.logo_url !== undefined) {
            fields.push("logo_url = ?");
            values.push(normalizeLogoUrl(payload.logo_url));
        }
        if (payload.site_url !== undefined) {
            fields.push("site_url = ?");
            values.push(payload.site_url || null);
        }
        if (payload.sales_page_url !== undefined) {
            fields.push("sales_page_url = ?");
            values.push(payload.sales_page_url || null);
        }
        if (payload.instagram_url !== undefined) {
            fields.push("instagram_url = ?");
            values.push(payload.instagram_url || null);
        }
        if (payload.facebook_url !== undefined) {
            fields.push("facebook_url = ?");
            values.push(payload.facebook_url || null);
        }
        if (payload.twitter_url !== undefined) {
            fields.push("twitter_url = ?");
            values.push(payload.twitter_url || null);
        }
        if (payload.tiktok_url !== undefined) {
            fields.push("tiktok_url = ?");
            values.push(payload.tiktok_url || null);
        }
        if (payload.slogan !== undefined) {
            fields.push("slogan = ?");
            values.push(payload.slogan || null);
        }
        if (payload.primary_color !== undefined) {
            fields.push("primary_color = ?");
            values.push(payload.primary_color || null);
        }
        if (payload.secondary_color !== undefined) {
            fields.push("secondary_color = ?");
            values.push(payload.secondary_color || null);
        }
        if (payload.theme_json !== undefined) {
            fields.push("theme_json = ?");
            values.push(payload.theme_json ? JSON.stringify(payload.theme_json) : null);
        }
        if (payload.voice_json !== undefined) {
            fields.push("voice_json = ?");
            values.push(payload.voice_json ? JSON.stringify(payload.voice_json) : null);
        }
        if (payload.domain !== undefined) {
            fields.push("domain = ?");
            values.push(String(payload.domain || "").trim() || null);
        }
        if (payload.status !== undefined) {
            if (payload.status !== "active" && payload.status !== "archived") {
                throw new Error("Brand status is invalid");
            }
            fields.push("status = ?");
            values.push(payload.status);
        }
        if (payload.is_default === true) {
            await (0, database_1.update)(`UPDATE brand_units SET is_default = FALSE WHERE user_id = ?`, [userId]);
            fields.push("is_default = TRUE");
        }
        if (fields.length === 0)
            return this.getById(userId, brandId);
        values.push(brandId, userId);
        await (0, database_1.update)(`UPDATE brand_units SET ${fields.join(", ")}, updated_at = NOW() WHERE id = ? AND user_id = ?`, values);
        if (payload.is_default === true) {
            await this.setActiveBrand(userId, brandId);
        }
        return this.getById(userId, brandId);
    }
    async setActiveBrand(userId, brandId) {
        await this.ensureSchema();
        const brand = await this.getById(userId, brandId);
        if (!brand)
            return false;
        const affected = await (0, database_1.update)(`UPDATE user_brand_context SET active_brand_id = ? WHERE user_id = ?`, [brandId, userId]);
        if (affected === 0) {
            await (0, database_1.query)(`INSERT INTO user_brand_context (user_id, active_brand_id) VALUES (?, ?)`, [
                userId,
                brandId,
            ]);
        }
        return true;
    }
    async getActiveBrandId(userId) {
        await this.ensureSchema();
        const ctx = await (0, database_1.queryOne)(`SELECT active_brand_id FROM user_brand_context WHERE user_id = ? LIMIT 1`, [userId]);
        if (ctx?.active_brand_id)
            return String(ctx.active_brand_id);
        const fallback = await (0, database_1.queryOne)(`SELECT id FROM brand_units WHERE user_id = ? ORDER BY is_default DESC, created_at ASC LIMIT 1`, [userId]);
        return fallback?.id ? String(fallback.id) : null;
    }
    async resolveActiveBrandId(userId, requestedBrandId) {
        await this.ensureSchema();
        const candidate = String(requestedBrandId || "").trim();
        if (candidate) {
            const requested = await this.getById(userId, candidate);
            if (!requested) {
                throw new Error("Brand not found for this user");
            }
            await this.setActiveBrand(userId, candidate);
            return candidate;
        }
        return this.getActiveBrandId(userId);
    }
}
exports.BrandUnitsService = BrandUnitsService;
//# sourceMappingURL=brandUnits.js.map