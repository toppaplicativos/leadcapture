"use strict";
/**
 * SOCKET MANAGER - Gerenciamento de WebSocket com Socket.io
 *
 * Este arquivo contém toda a lógica para:
 * - Inicializar servidor Socket.io
 * - Gerenciar conexões de clientes
 * - Emitir eventos em tempo real
 * - Notificações de novas mensagens
 * - Atualização de status de instâncias
 * - Indicador de digitação
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.socketManager = void 0;
const socket_io_1 = require("socket.io");
const logger_1 = require("./logger");
// ============================================
// SOCKET MANAGER
// ============================================
class SocketManager {
    constructor() {
        this.io = null;
        this.userSockets = new Map();
    }
    /**
     * Inicializa o servidor Socket.io
     * @param httpServer - Servidor HTTP Express
     */
    initialize(httpServer) {
        const rawOrigins = String(process.env.SOCKET_CORS_ORIGINS || process.env.FRONTEND_ORIGINS || process.env.NEXT_PUBLIC_APP_URL || "")
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean);
        const originChecker = (origin, callback) => {
            if (!origin) {
                callback(null, true);
                return;
            }
            if (rawOrigins.length === 0) {
                callback(null, true);
                return;
            }
            const allowed = rawOrigins.some((candidate) => {
                if (candidate === "*")
                    return true;
                return candidate === origin;
            });
            callback(null, allowed);
        };
        this.io = new socket_io_1.Server(httpServer, {
            cors: {
                origin: originChecker,
                methods: ['GET', 'POST'],
                credentials: true,
            },
            transports: ['websocket', 'polling'],
        });
        // Configurar eventos de conexão
        this.io.on('connection', (socket) => {
            logger_1.logger.info(`[Socket] Nova conexão: ${socket.id}`);
            // Evento: Usuário conecta
            socket.on('user:connect', (data) => {
                this.handleUserConnect(socket, data);
            });
            // Evento: Usuário desconecta
            socket.on('disconnect', () => {
                this.handleUserDisconnect(socket);
            });
            // Evento: Entrar em conversa
            socket.on('conversation:join', (data) => {
                this.handleConversationJoin(socket, data);
            });
            // Evento: Sair de conversa
            socket.on('conversation:leave', (data) => {
                this.handleConversationLeave(socket, data);
            });
            // Evento: Digitando
            socket.on('typing:start', (data) => {
                this.handleTypingStart(socket, data);
            });
            // Evento: Parou de digitar
            socket.on('typing:stop', (data) => {
                this.handleTypingStop(socket, data);
            });
            // Evento: Ping (keep-alive)
            socket.on('ping', () => {
                socket.emit('pong');
            });
        });
        logger_1.logger.info('[Socket] Servidor Socket.io inicializado');
        return this.io;
    }
    /**
     * Manipula conexão de usuário
     * @param socket - Socket do cliente
     * @param data - Dados do usuário
     */
    handleUserConnect(socket, data) {
        const { userId } = data;
        // Armazenar socket do usuário
        if (!this.userSockets.has(userId)) {
            this.userSockets.set(userId, []);
        }
        this.userSockets.get(userId).push({
            userId,
            socketId: socket.id,
            connectedAt: new Date(),
        });
        // Juntar o socket a uma sala com o ID do usuário
        socket.join(`user:${userId}`);
        logger_1.logger.info(`[Socket] Usuário ${userId} conectado (socket: ${socket.id})`);
    }
    /**
     * Manipula desconexão de usuário
     * @param socket - Socket do cliente
     */
    handleUserDisconnect(socket) {
        // Encontrar e remover socket do usuário
        for (const [userId, sockets] of this.userSockets.entries()) {
            const index = sockets.findIndex(s => s.socketId === socket.id);
            if (index !== -1) {
                sockets.splice(index, 1);
                logger_1.logger.info(`[Socket] Usuário ${userId} desconectado (socket: ${socket.id})`);
                // Se não há mais sockets para este usuário, remover entrada
                if (sockets.length === 0) {
                    this.userSockets.delete(userId);
                }
                break;
            }
        }
    }
    /**
     * Manipula entrada em conversa
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    handleConversationJoin(socket, data) {
        const { conversationId } = data;
        socket.join(`conversation:${conversationId}`);
        logger_1.logger.info(`[Socket] Socket ${socket.id} entrou na conversa ${conversationId}`);
    }
    /**
     * Manipula saída de conversa
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    handleConversationLeave(socket, data) {
        const { conversationId } = data;
        socket.leave(`conversation:${conversationId}`);
        logger_1.logger.info(`[Socket] Socket ${socket.id} saiu da conversa ${conversationId}`);
    }
    /**
     * Manipula início de digitação
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    handleTypingStart(socket, data) {
        const { conversationId } = data;
        // Emitir para todos na conversa (exceto o remetente)
        socket.to(`conversation:${conversationId}`).emit('typing:start', {
            conversationId,
            socketId: socket.id,
        });
    }
    /**
     * Manipula parada de digitação
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    handleTypingStop(socket, data) {
        const { conversationId } = data;
        socket.to(`conversation:${conversationId}`).emit('typing:stop', {
            conversationId,
            socketId: socket.id,
        });
    }
    /**
     * Emite nova mensagem para todos na conversa
     * @param conversationId - ID da conversa
     * @param message - Dados da mensagem
     */
    emitNewMessage(conversationId, message) {
        if (!this.io)
            return;
        this.io.to(`conversation:${conversationId}`).emit('message:new', {
            conversationId,
            message,
        });
        logger_1.logger.info(`[Socket] Nova mensagem emitida para conversa ${conversationId}`);
    }
    /**
     * Emite atualização de conversa
     * @param conversationId - ID da conversa
     * @param conversation - Dados da conversa
     */
    emitConversationUpdate(conversationId, conversation) {
        if (!this.io)
            return;
        this.io.to(`conversation:${conversationId}`).emit('conversation:update', {
            conversationId,
            conversation,
        });
        logger_1.logger.info(`[Socket] Conversa ${conversationId} atualizada`);
    }
    /**
     * Emite notificação de nova conversa para usuário
     * @param userId - ID do usuário
     * @param conversation - Dados da conversa
     */
    emitNewConversation(userId, conversation) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit('conversation:new', {
            conversation,
        });
        logger_1.logger.info(`[Socket] Nova conversa notificada para usuário ${userId}`);
    }
    /**
     * Emite atualização de status de instância
     * @param userId - ID do usuário
     * @param instanceId - ID da instância
     * @param status - Novo status
     */
    emitInstanceStatusUpdate(userId, instanceId, status) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit('instance:status', {
            instanceId,
            status,
        });
        logger_1.logger.info(`[Socket] Status da instância ${instanceId} atualizado para ${status}`);
    }
    /**
     * Emite QR Code para usuário
     * @param userId - ID do usuário
     * @param instanceId - ID da instância
     * @param qrCode - Dados do QR Code
     */
    emitQRCode(userId, instanceId, qrCode) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit('instance:qrcode', {
            instanceId,
            qrCode,
        });
        logger_1.logger.info(`[Socket] QR Code emitido para usuário ${userId}`);
    }
    /**
     * Emite erro para usuário
     * @param userId - ID do usuário
     * @param error - Mensagem de erro
     */
    emitError(userId, error) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit('error', {
            message: error,
        });
        logger_1.logger.error(`[Socket] Erro emitido para usuário ${userId}: ${error}`);
    }
    /**
     * Emite notificação em tempo real para o usuário
     */
    emitNotification(userId, notification) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit("notification:new", {
            notification,
        });
        logger_1.logger.info(`[Socket] Notification emitted to user ${userId}: ${notification.event}`);
    }
    /**
     * Emite atualização do badge de notificações
     */
    emitNotificationBadge(userId, unreadCount) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit("notification:badge", {
            unread_count: Math.max(0, Number(unreadCount || 0)),
        });
    }
    /**
     * Emite atualização de notificação (read/unread)
     */
    emitNotificationUpdated(userId, notificationId, patch) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit("notification:updated", {
            id: notificationId,
            patch,
        });
    }
    /**
     * Broadcast genérico para uma sala de usuário
     */
    emitToUser(userId, event, payload) {
        if (!this.io)
            return;
        this.io.to(`user:${userId}`).emit(event, payload);
    }
    /**
     * Obtém número de usuários conectados
     */
    getConnectedUsersCount() {
        return this.userSockets.size;
    }
    /**
     * Obtém número de sockets conectados
     */
    getConnectedSocketsCount() {
        let count = 0;
        for (const sockets of this.userSockets.values()) {
            count += sockets.length;
        }
        return count;
    }
    /**
     * Obtém instância do Socket.io
     */
    getIO() {
        return this.io;
    }
}
// Exportar singleton
exports.socketManager = new SocketManager();
//# sourceMappingURL=socketManager.js.map