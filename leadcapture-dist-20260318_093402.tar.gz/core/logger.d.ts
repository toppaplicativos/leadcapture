/**
 * LOGGER - Sistema de Logging Estruturado
 */
type LogLevel = 'info' | 'warn' | 'error' | 'debug';
declare class Logger {
    private prefix;
    log(level: LogLevel, message: string, data?: any): void;
    info(message: string, data?: any): void;
    warn(message: string, data?: any): void;
    error(message: string, data?: any): void;
    debug(message: string, data?: any): void;
}
export declare const logger: Logger;
export {};
//# sourceMappingURL=logger.d.ts.map