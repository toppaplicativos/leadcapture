type AgentWorkspaceOverview = {
    brand_id: string | null;
    readiness_score: number;
    profile: {
        agent_name: string;
        tone: string;
        language: string;
        objective: string;
        include_emojis: boolean;
        max_length: number;
        filled_fields: number;
        total_fields: number;
    };
    training: {
        total_entries: number;
        active_entries: number;
        categories_count: number;
        last_update_at: string | null;
    };
    whatsapp: {
        auto_reply_enabled: boolean;
        total_conversations: number;
        autonomous_conversations: number;
        supervised_conversations: number;
        manual_conversations: number;
        inbound_messages: number;
        outbound_messages: number;
        autonomous_replies: number;
        escalations: number;
        human_takeovers: number;
        autonomy_coverage: number;
    };
};
export declare class AgentWorkspaceService {
    private readonly profileService;
    private resolveKnowledgeActiveColumn;
    private normalizeBrandId;
    private countFilledFields;
    getOverview(userId: string, brandId?: string | null): Promise<AgentWorkspaceOverview>;
}
export {};
//# sourceMappingURL=agentWorkspace.d.ts.map