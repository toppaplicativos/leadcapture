import { NextFunction, Response } from "express";
import { AuthRequest } from "./auth";
export interface BrandRequest extends AuthRequest {
    brandId?: string | null;
}
export declare function attachBrandContext(req: BrandRequest, res: Response, next: NextFunction): Promise<void>;
export declare function requireBrandContext(req: BrandRequest, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=brandContext.d.ts.map