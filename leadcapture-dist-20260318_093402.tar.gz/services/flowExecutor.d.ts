import { InstanceManager } from "../core/instanceManager";
export declare class FlowExecutorService {
    private instanceManager;
    private static _inst;
    private tableReady;
    constructor(instanceManager: InstanceManager);
    private readonly notificationService;
    static init(im: InstanceManager): FlowExecutorService;
    static get(): FlowExecutorService;
    fire(triggerSubtype: string, userId: string, triggerData: Record<string, any>): Promise<void>;
    private runFrom;
    private processNode;
    private handleDelay;
    private handleAction;
    private evaluateCondition;
    private sendWhatsApp;
    private executeWebhook;
    private transformData;
    private createExecutionSnapshot;
    private buildSystemVars;
    private registerNodeOutput;
    private resolveValue;
    private interpolate;
    private resolveTemplatePath;
    private getValueByPath;
    private cloneJson;
    private inferOutputSchema;
    private resolveInstance;
    private updateLeadField;
    private addTag;
    private removeTag;
    private parseTags;
    private ensureTables;
    private insertExecution;
    private persistExecution;
}
//# sourceMappingURL=flowExecutor.d.ts.map