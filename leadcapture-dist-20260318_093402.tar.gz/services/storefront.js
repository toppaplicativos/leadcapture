"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorefrontService = void 0;
const crypto_1 = require("crypto");
const promises_1 = require("dns/promises");
const qrcode_1 = __importDefault(require("qrcode"));
const config_1 = require("../config");
const database_1 = require("../config/database");
const logger_1 = require("../utils/logger");
const inventory_1 = require("./inventory");
const products_1 = require("./products");
function parseJson(value, fallback) {
    if (!value)
        return fallback;
    if (typeof value === "object")
        return value;
    if (typeof value !== "string")
        return fallback;
    try {
        return JSON.parse(value);
    }
    catch {
        return fallback;
    }
}
function toNumber(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
}
function toSlug(value) {
    return String(value || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 120);
}
function sanitizeDomain(value) {
    const cleaned = String(value || "")
        .trim()
        .toLowerCase()
        .replace(/^https?:\/\//, "")
        .replace(/\/$/, "");
    return cleaned.split("/")[0].split(":")[0];
}
function normalizeBrandId(value) {
    return String(value || "").trim();
}
function domainCandidates(host) {
    const normalized = sanitizeDomain(host);
    if (!normalized)
        return [];
    const set = new Set([normalized]);
    if (normalized.startsWith("www."))
        set.add(normalized.slice(4));
    else
        set.add(`www.${normalized}`);
    return Array.from(set);
}
function buildDomainVerificationToken(storeId, domain) {
    return (0, crypto_1.createHash)("sha256")
        .update(`${config_1.config.jwtSecret}:${storeId}:${sanitizeDomain(domain)}`)
        .digest("hex")
        .slice(0, 24);
}
function normalizePublicHost(value) {
    const host = sanitizeDomain(value);
    if (!host || host === "localhost" || host === "127.0.0.1")
        return null;
    return host;
}
function defaultStoreSettings() {
    return {
        checkout: { collect_email: true, collect_address: true },
        notifications: { admin: true, whatsapp: null, email: null, webhook_url: null },
        logistics: {
            default_eta_minutes: 40,
            token_prefix: "DEL",
            confirm_base_url: null,
            require_delivery_token: true,
        },
        automation: {
            order_flow: {
                active: false,
                version: "1.0.0",
                name: "Fluxo Completo de Pedido + Logistica + QR/Token",
                semi_configured: true,
                statuses: [
                    "novo",
                    "confirmando_pagamento",
                    "aprovado",
                    "em_preparacao",
                    "saiu_para_entrega",
                    "entregue",
                    "cancelado",
                ],
                phases: [
                    "order_created",
                    "payment_confirmed",
                    "preparation",
                    "out_for_delivery",
                    "delivery_confirmation",
                    "post_sale",
                ],
            },
        },
        seo: { auto_index: true },
    };
}
function mergeStoreSettings(input) {
    const base = defaultStoreSettings();
    const next = input || {};
    return {
        ...base,
        ...next,
        checkout: {
            ...base.checkout,
            ...(next.checkout || {}),
        },
        notifications: {
            ...base.notifications,
            ...(next.notifications || {}),
        },
        logistics: {
            ...base.logistics,
            ...(next.logistics || {}),
        },
        automation: {
            ...base.automation,
            ...(next.automation || {}),
            order_flow: {
                ...base.automation.order_flow,
                ...((next.automation || {}).order_flow || {}),
            },
        },
    };
}
function mergeStoreSettingsWithPatch(currentSettings, patchSettings) {
    const current = mergeStoreSettings(currentSettings || {});
    const patch = patchSettings || {};
    return mergeStoreSettings({
        ...current,
        ...patch,
        checkout: {
            ...(current.checkout || {}),
            ...(patch.checkout || {}),
        },
        notifications: {
            ...(current.notifications || {}),
            ...(patch.notifications || {}),
        },
        logistics: {
            ...(current.logistics || {}),
            ...(patch.logistics || {}),
        },
        automation: {
            ...(current.automation || {}),
            ...(patch.automation || {}),
            order_flow: {
                ...((current.automation || {}).order_flow || {}),
                ...((patch.automation || {}).order_flow || {}),
            },
        },
        seo: {
            ...(current.seo || {}),
            ...(patch.seo || {}),
        },
    });
}
function toSqlDateTime(value) {
    return value.toISOString().slice(0, 19).replace("T", " ");
}
function formatMoneyBr(value) {
    const amount = Number.isFinite(value) ? value : 0;
    return `R$ ${amount.toFixed(2).replace(".", ",")}`;
}
class StorefrontService {
    constructor() {
        this.schemaReady = false;
        this.schemaPromise = null;
        this.productsService = new products_1.ProductsService();
        this.inventoryService = new inventory_1.InventoryService();
    }
    async columnExists(tableName, columnName) {
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`, [tableName, columnName]);
        return Number(row?.total || 0) > 0;
    }
    async ensureColumn(tableName, columnName, definition) {
        const exists = await this.columnExists(tableName, columnName);
        if (exists)
            return;
        await (0, database_1.query)(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
    }
    mapStore(row) {
        return {
            id: row.id,
            owner_user_id: row.owner_user_id,
            brand_id: normalizeBrandId(row.brand_id || "") || null,
            slug: row.slug,
            name: row.name,
            status: row.status,
            template_id: row.template_id,
            brand: parseJson(row.brand_json, {}),
            theme: parseJson(row.theme_json, {}),
            settings: mergeStoreSettings(parseJson(row.settings_json, {})),
            primary_domain: row.primary_domain || null,
            created_at: row.created_at,
            updated_at: row.updated_at,
        };
    }
    mapTemplate(row) {
        return {
            template_id: row.template_id,
            name: row.name,
            description: row.description || "",
            sections: parseJson(row.sections_json, []),
            style: parseJson(row.style_json, {}),
        };
    }
    parseObjectJson(value) {
        return parseJson(value, {});
    }
    toIsoNow() {
        return new Date().toISOString();
    }
    async synchronizeStoreBrandIdentity(store) {
        const brandId = normalizeBrandId(store.brand_id);
        const userId = String(store.owner_user_id || "").trim();
        if (!brandId || !userId)
            return;
        const brandUnit = await (0, database_1.queryOne)(`SELECT id, name, slug, logo_url, slogan, primary_color, secondary_color, site_url, sales_page_url,
              instagram_url, facebook_url, twitter_url, tiktok_url, domain, status, theme_json
       FROM brand_units
       WHERE id = ? AND user_id = ?
       LIMIT 1`, [brandId, userId]);
        if (!brandUnit)
            return;
        const currentBrand = this.parseObjectJson(store.brand_json);
        const currentTheme = this.parseObjectJson(store.theme_json);
        const brandThemeData = this.parseObjectJson(brandUnit.theme_json);
        const nextBrand = {
            ...currentBrand,
            id: String(brandUnit.id || brandId),
            name: String(brandUnit.name || currentBrand.name || store.name || "").trim() || store.name,
            slug: String(brandUnit.slug || currentBrand.slug || "").trim() || toSlug(String(brandUnit.name || store.name || "")),
            logo_url: String(brandUnit.logo_url || "").trim() || currentBrand.logo_url || null,
            slogan: String(brandUnit.slogan || "").trim() || currentBrand.slogan || null,
            description: String(brandThemeData.description || brandUnit.slogan || "").trim() || currentBrand.description || currentBrand.slogan || null,
            cover_image: String(brandThemeData.cover_image || brandThemeData.cover_image_url || brandThemeData.hero_image || "").trim() || currentBrand.cover_image || null,
            address: String(brandThemeData.address || "").trim() || currentBrand.address || null,
            primary_color: String(brandUnit.primary_color || "").trim() || currentBrand.primary_color || null,
            secondary_color: String(brandUnit.secondary_color || "").trim() || currentBrand.secondary_color || null,
            site_url: String(brandUnit.site_url || "").trim() || currentBrand.site_url || null,
            sales_page_url: String(brandUnit.sales_page_url || "").trim() || currentBrand.sales_page_url || null,
            instagram_url: String(brandUnit.instagram_url || "").trim() || currentBrand.instagram_url || null,
            facebook_url: String(brandUnit.facebook_url || "").trim() || currentBrand.facebook_url || null,
            twitter_url: String(brandUnit.twitter_url || "").trim() || currentBrand.twitter_url || null,
            tiktok_url: String(brandUnit.tiktok_url || "").trim() || currentBrand.tiktok_url || null,
            domain: String(brandUnit.domain || "").trim() || currentBrand.domain || null,
            status: String(brandUnit.status || currentBrand.status || "active").trim() || "active",
            synced_at: this.toIsoNow(),
        };
        const nextTheme = {
            ...currentTheme,
            logo_url: String(brandUnit.logo_url || "").trim() ||
                String(currentTheme.logo_url || currentTheme.logo || "").trim() ||
                undefined,
            primary_color: String(brandUnit.primary_color || "").trim() ||
                String(currentTheme.primary_color || currentTheme.primary || "").trim() ||
                undefined,
            secondary_color: String(brandUnit.secondary_color || "").trim() ||
                String(currentTheme.secondary_color || currentTheme.secondary || "").trim() ||
                undefined,
        };
        const beforeBrand = JSON.stringify(this.parseObjectJson(store.brand_json));
        const afterBrand = JSON.stringify(nextBrand);
        const beforeTheme = JSON.stringify(this.parseObjectJson(store.theme_json));
        const afterTheme = JSON.stringify(nextTheme);
        if (beforeBrand === afterBrand && beforeTheme === afterTheme)
            return;
        await (0, database_1.update)(`UPDATE storefront_stores
       SET brand_json = ?, theme_json = ?, updated_at = NOW()
       WHERE id = ?`, [afterBrand, afterTheme, store.id]);
    }
    async synchronizeStoreProductsFromCatalog(store) {
        const brandId = normalizeBrandId(store.brand_id);
        const userId = String(store.owner_user_id || "").trim();
        if (!brandId || !userId)
            return;
        const catalogProducts = await this.productsService.getActiveProducts(userId, brandId);
        const existingRows = (await (0, database_1.query)(`SELECT id, slug, name, description, category, price, compare_at_price, images_json, metadata_json, is_active, position
       FROM storefront_products
       WHERE store_id = ?`, [store.id]));
        const bySourceId = new Map();
        for (const row of existingRows || []) {
            const metadata = this.parseObjectJson(row.metadata_json);
            const sourceProductId = String(metadata.source_product_id || "").trim();
            if (sourceProductId) {
                bySourceId.set(sourceProductId, { ...row, metadata });
            }
        }
        const activeSourceIds = new Set();
        const resolveUniqueSlug = (rawBase, keepId) => {
            const base = toSlug(rawBase) || `produto-${Date.now()}`;
            let candidate = base;
            let attempt = 1;
            while (true) {
                const owner = (existingRows || []).find((item) => toSlug(String(item.slug || "")) === candidate);
                if (!owner || (keepId && String(owner.id) === keepId)) {
                    return candidate;
                }
                attempt += 1;
                candidate = `${base}-${attempt}`;
            }
        };
        for (let index = 0; index < catalogProducts.length; index += 1) {
            const product = catalogProducts[index];
            const sourceProductId = String(product.id || "").trim();
            if (!sourceProductId)
                continue;
            activeSourceIds.add(sourceProductId);
            const mapped = bySourceId.get(sourceProductId);
            const images = Array.isArray(product.images)
                ? product.images.map((item) => String(item || "").trim()).filter(Boolean)
                : [];
            const imageUrl = String(images[0] || product.imageUrl || product.image || "").trim();
            const mergedMetadata = {
                ...(mapped?.metadata || {}),
                source: "products_catalog",
                source_product_id: sourceProductId,
                source_brand_id: brandId,
                source_synced_at: this.toIsoNow(),
            };
            const targetSlug = resolveUniqueSlug(String(product.name || sourceProductId), mapped?.id);
            const targetName = String(product.name || "").trim() || `Produto ${sourceProductId.slice(0, 6)}`;
            const targetDescription = String(product.description || "").trim() || null;
            const targetCategory = String(product.category || "").trim() || null;
            const targetPrice = toNumber(product.promoPrice ?? product.price, 0);
            const targetComparePrice = Number.isFinite(Number(product.price)) ? Number(product.price) : null;
            if (mapped) {
                const currentImages = parseJson(mapped.images_json, []);
                const currentMetadata = this.parseObjectJson(mapped.metadata_json);
                const hasChanged = String(mapped.slug || "") !== targetSlug ||
                    String(mapped.name || "") !== targetName ||
                    String(mapped.description || "") !== String(targetDescription || "") ||
                    String(mapped.category || "") !== String(targetCategory || "") ||
                    Number(mapped.price || 0) !== targetPrice ||
                    Number(mapped.compare_at_price || 0) !== Number(targetComparePrice || 0) ||
                    JSON.stringify(currentImages) !== JSON.stringify(images) ||
                    JSON.stringify(currentMetadata) !== JSON.stringify(mergedMetadata) ||
                    Number(mapped.is_active || 0) !== 1 ||
                    Number(mapped.position || 0) !== index;
                if (hasChanged) {
                    await (0, database_1.update)(`UPDATE storefront_products
             SET slug = ?, name = ?, description = ?, category = ?, price = ?, compare_at_price = ?,
                 currency = 'BRL', images_json = ?, metadata_json = ?, is_active = 1, position = ?, updated_at = NOW()
             WHERE id = ?`, [
                        targetSlug,
                        targetName,
                        targetDescription,
                        targetCategory,
                        targetPrice,
                        targetComparePrice,
                        JSON.stringify(images),
                        JSON.stringify(mergedMetadata),
                        index,
                        mapped.id,
                    ]);
                }
            }
            else {
                await (0, database_1.query)(`INSERT INTO storefront_products
           (id, store_id, slug, name, description, category, price, compare_at_price, currency, images_json, variants_json, metadata_json, is_active, position)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'BRL', ?, '[]', ?, TRUE, ?)`, [
                    (0, crypto_1.randomUUID)(),
                    store.id,
                    targetSlug,
                    targetName,
                    targetDescription,
                    targetCategory,
                    targetPrice,
                    targetComparePrice,
                    JSON.stringify(images),
                    JSON.stringify(mergedMetadata),
                    index,
                ]);
            }
        }
        for (const row of existingRows || []) {
            const metadata = this.parseObjectJson(row.metadata_json);
            const sourceProductId = String(metadata.source_product_id || "").trim();
            if (!sourceProductId)
                continue;
            if (activeSourceIds.has(sourceProductId))
                continue;
            if (Number(row.is_active || 0) !== 0) {
                await (0, database_1.update)(`UPDATE storefront_products
           SET is_active = FALSE, updated_at = NOW()
           WHERE id = ?`, [row.id]);
            }
        }
    }
    async synchronizeBrandStructure(userId, brandId, options) {
        await this.ensureSchema();
        const normalizedBrandId = normalizeBrandId(brandId);
        if (!normalizedBrandId)
            return null;
        const store = await this.ensureSingleStoreForBrand(userId, normalizedBrandId);
        if (!store)
            return null;
        const storeRow = await this.getOwnedStoreRow(userId, String(store.id), normalizedBrandId);
        if (!storeRow)
            return store;
        await this.synchronizeStoreBrandIdentity(storeRow);
        if (options?.syncProducts !== false) {
            await this.synchronizeStoreProductsFromCatalog(storeRow);
        }
        if (storeRow.status === "draft") {
            await (0, database_1.update)(`UPDATE storefront_stores SET status = 'active', updated_at = NOW() WHERE id = ? AND status = 'draft'`, [storeRow.id]);
        }
        const refreshed = await this.getOwnedStoreRow(userId, String(store.id), normalizedBrandId);
        return refreshed ? this.mapStore(refreshed) : store;
    }
    async ensureSchema() {
        if (this.schemaReady)
            return;
        if (this.schemaPromise)
            return this.schemaPromise;
        this.schemaPromise = (async () => {
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_templates (
          template_id VARCHAR(80) PRIMARY KEY,
          name VARCHAR(120) NOT NULL,
          description TEXT NULL,
          sections_json JSON NULL,
          style_json JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_stores (
          id VARCHAR(36) PRIMARY KEY,
          owner_user_id VARCHAR(36) NOT NULL,
          brand_id VARCHAR(36) NOT NULL DEFAULT '',
          slug VARCHAR(140) NOT NULL,
          name VARCHAR(180) NOT NULL,
          status ENUM('draft','active','archived') NOT NULL DEFAULT 'draft',
          template_id VARCHAR(80) NOT NULL,
          brand_json JSON NULL,
          theme_json JSON NULL,
          settings_json JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_slug (slug),
          KEY idx_storefront_owner (owner_user_id),
          KEY idx_storefront_owner_brand (owner_user_id, brand_id),
          KEY idx_storefront_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_domains (
          id VARCHAR(36) PRIMARY KEY,
          store_id VARCHAR(36) NOT NULL,
          domain VARCHAR(255) NOT NULL,
          is_primary TINYINT(1) NOT NULL DEFAULT 0,
          verification_status ENUM('pending','verified','failed') NOT NULL DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_domain (domain),
          KEY idx_storefront_domain_store (store_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_products (
          id VARCHAR(36) PRIMARY KEY,
          store_id VARCHAR(36) NOT NULL,
          slug VARCHAR(160) NOT NULL,
          name VARCHAR(180) NOT NULL,
          description TEXT NULL,
          category VARCHAR(120) NULL,
          price DECIMAL(12,2) NOT NULL DEFAULT 0,
          compare_at_price DECIMAL(12,2) NULL,
          currency CHAR(3) NOT NULL DEFAULT 'BRL',
          images_json JSON NULL,
          variants_json JSON NULL,
          metadata_json JSON NULL,
          is_active TINYINT(1) NOT NULL DEFAULT 1,
          position INT NOT NULL DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_product_slug (store_id, slug),
          KEY idx_storefront_product_store (store_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_pages (
          id VARCHAR(36) PRIMARY KEY,
          store_id VARCHAR(36) NOT NULL,
          slug VARCHAR(160) NOT NULL,
          title VARCHAR(180) NOT NULL,
          page_type ENUM('home','about','products','product','custom','ai_generated') NOT NULL DEFAULT 'custom',
          sections_json JSON NULL,
          seo_json JSON NULL,
          is_published TINYINT(1) NOT NULL DEFAULT 1,
          created_by_ai TINYINT(1) NOT NULL DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_page_slug (store_id, slug),
          KEY idx_storefront_page_store (store_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_orders (
          id VARCHAR(36) PRIMARY KEY,
          order_number VARCHAR(40) NOT NULL,
          store_id VARCHAR(36) NOT NULL,
          status ENUM('novo','confirmando_pagamento','aprovado','em_preparacao','saiu_para_entrega','entregue','cancelado') NOT NULL DEFAULT 'novo',
          currency CHAR(3) NOT NULL DEFAULT 'BRL',
          subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
          shipping DECIMAL(12,2) NOT NULL DEFAULT 0,
          discount DECIMAL(12,2) NOT NULL DEFAULT 0,
          total DECIMAL(12,2) NOT NULL DEFAULT 0,
          payment_method VARCHAR(40) NULL,
          customer_name VARCHAR(180) NOT NULL,
          customer_phone VARCHAR(40) NOT NULL,
          customer_email VARCHAR(190) NULL,
          customer_address_json JSON NULL,
          items_json JSON NULL,
          delivery_token VARCHAR(80) NULL,
          delivery_status ENUM('aguardando_confirmacao','confirmado','expirado','cancelado') NULL,
          delivery_qr_data_url LONGTEXT NULL,
          courier_name VARCHAR(140) NULL,
          courier_phone VARCHAR(40) NULL,
          courier_route_url TEXT NULL,
          delivered_at TIMESTAMP NULL,
          delivery_confirmed_by VARCHAR(140) NULL,
          delivery_confirmed_via ENUM('qr','token','admin') NULL,
          notes TEXT NULL,
          source ENUM('site','whatsapp','admin') NOT NULL DEFAULT 'site',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_order_number (order_number),
          KEY idx_storefront_order_store (store_id),
          KEY idx_storefront_order_status (store_id, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_order_notifications (
          id VARCHAR(36) PRIMARY KEY,
          order_id VARCHAR(36) NOT NULL,
          store_id VARCHAR(36) NOT NULL,
          channel ENUM('admin','whatsapp','email') NOT NULL,
          target VARCHAR(255) NULL,
          status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
          payload_json JSON NULL,
          last_error TEXT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_storefront_notif_order (order_id),
          KEY idx_storefront_notif_store (store_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_order_timeline (
          id VARCHAR(36) PRIMARY KEY,
          order_id VARCHAR(36) NOT NULL,
          store_id VARCHAR(36) NOT NULL,
          event_type VARCHAR(80) NOT NULL,
          status_before VARCHAR(80) NULL,
          status_after VARCHAR(80) NULL,
          actor_type ENUM('system','admin','customer','courier') NOT NULL DEFAULT 'system',
          actor_name VARCHAR(140) NULL,
          payload_json JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          KEY idx_storefront_timeline_order (order_id, created_at),
          KEY idx_storefront_timeline_store (store_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_delivery_tokens (
          id VARCHAR(36) PRIMARY KEY,
          order_id VARCHAR(36) NOT NULL,
          store_id VARCHAR(36) NOT NULL,
          token VARCHAR(80) NOT NULL,
          expires_at TIMESTAMP NULL,
          used_at TIMESTAMP NULL,
          used_via ENUM('qr','token','admin') NULL,
          used_by VARCHAR(140) NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_storefront_delivery_token (token),
          KEY idx_storefront_delivery_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_post_sale_queue (
          id VARCHAR(36) PRIMARY KEY,
          order_id VARCHAR(36) NOT NULL,
          store_id VARCHAR(36) NOT NULL,
          stage ENUM('2h_checkin','24h_review') NOT NULL,
          run_at TIMESTAMP NOT NULL,
          status ENUM('pending','sent','failed','cancelled') NOT NULL DEFAULT 'pending',
          payload_json JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_storefront_post_sale_run (status, run_at),
          KEY idx_storefront_post_sale_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await this.ensureColumn("storefront_orders", "payment_method", "VARCHAR(40) NULL");
            await this.ensureColumn("storefront_stores", "brand_id", "VARCHAR(36) NOT NULL DEFAULT ''");
            await this.ensureColumn("storefront_orders", "delivery_token", "VARCHAR(80) NULL");
            await this.ensureColumn("storefront_orders", "delivery_status", "ENUM('aguardando_confirmacao','confirmado','expirado','cancelado') NULL");
            await this.ensureColumn("storefront_orders", "delivery_qr_data_url", "LONGTEXT NULL");
            await this.ensureColumn("storefront_orders", "courier_name", "VARCHAR(140) NULL");
            await this.ensureColumn("storefront_orders", "courier_phone", "VARCHAR(40) NULL");
            await this.ensureColumn("storefront_orders", "courier_route_url", "TEXT NULL");
            await this.ensureColumn("storefront_orders", "delivered_at", "TIMESTAMP NULL");
            await this.ensureColumn("storefront_orders", "delivery_confirmed_by", "VARCHAR(140) NULL");
            await this.ensureColumn("storefront_orders", "delivery_confirmed_via", "ENUM('qr','token','admin') NULL");
            await (0, database_1.query)(`
        CREATE TABLE IF NOT EXISTS storefront_customers (
          id VARCHAR(36) PRIMARY KEY,
          store_id VARCHAR(36) NOT NULL,
          name VARCHAR(180) NOT NULL,
          email VARCHAR(190) NULL,
          phone VARCHAR(40) NULL,
          address_json JSON NULL,
          notes TEXT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_sf_customer_store (store_id),
          KEY idx_sf_customer_phone (store_id, phone),
          KEY idx_sf_customer_email (store_id, email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            await this.ensureColumn("storefront_orders", "customer_id", "VARCHAR(36) NULL");
            await (0, database_1.query)(`
        ALTER TABLE storefront_orders
        MODIFY COLUMN status ENUM('novo','confirmando_pagamento','aprovado','em_preparacao','saiu_para_entrega','entregue','cancelado') NOT NULL DEFAULT 'novo'
      `);
            await this.seedTemplates();
            this.schemaReady = true;
        })().finally(() => {
            this.schemaPromise = null;
        });
        await this.schemaPromise;
    }
    async seedTemplates() {
        const templates = [
            {
                template_id: "modern_minimal",
                name: "Modern Minimal",
                description: "Visual clean com foco em produto e conversao.",
                sections: ["hero", "featured", "products_grid", "cta", "footer"],
                style: { palette: { background: "#f8fafc", surface: "#ffffff", primary: "#0f172a", accent: "#0ea5e9" } },
            },
            {
                template_id: "dark_premium",
                name: "Dark Premium",
                description: "Layout escuro com destaque de marca para ticket alto.",
                sections: ["hero", "social_proof", "products_grid", "faq", "cta", "footer"],
                style: { palette: { background: "#020617", surface: "#0f172a", primary: "#f8fafc", accent: "#22d3ee" } },
            },
            {
                template_id: "creator_brand",
                name: "Creator Brand",
                description: "Storytelling e imagem em primeiro plano para creators.",
                sections: ["hero", "about", "benefits", "products_grid", "testimonials", "cta", "footer"],
                style: { palette: { background: "#fff7ed", surface: "#ffffff", primary: "#7c2d12", accent: "#ea580c" } },
            },
        ];
        for (const tpl of templates) {
            await (0, database_1.query)(`INSERT INTO storefront_templates (template_id, name, description, sections_json, style_json)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           name = VALUES(name),
           description = VALUES(description),
           sections_json = VALUES(sections_json),
           style_json = VALUES(style_json)`, [tpl.template_id, tpl.name, tpl.description, JSON.stringify(tpl.sections), JSON.stringify(tpl.style)]);
        }
    }
    buildOwnedBrandScope(brandId, tableAlias = "s") {
        const normalized = normalizeBrandId(brandId);
        if (!normalized) {
            return { sql: ` AND (${tableAlias}.brand_id = '' OR ${tableAlias}.brand_id IS NULL)`, params: [] };
        }
        return { sql: ` AND ${tableAlias}.brand_id = ?`, params: [normalized] };
    }
    async getOwnedStoreRow(userId, storeId, brandId) {
        await this.ensureSchema();
        const scope = this.buildOwnedBrandScope(brandId, "s");
        return ((await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
         FROM storefront_stores s
         LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
         WHERE s.id = ? AND s.owner_user_id = ?${scope.sql}
         LIMIT 1`, [storeId, userId, ...scope.params])) || null);
    }
    async resolveBrandSeed(userId, brandId) {
        const normalizedBrand = normalizeBrandId(brandId);
        if (normalizedBrand) {
            const brandUnit = await (0, database_1.queryOne)(`SELECT id, name, slug, logo_url, slogan, primary_color, secondary_color
         FROM brand_units
         WHERE id = ? AND user_id = ?
         LIMIT 1`, [normalizedBrand, userId]);
            if (brandUnit) {
                const name = String(brandUnit.name || "").trim() || "Loja da Marca";
                const slugBase = toSlug(String(brandUnit.slug || "").trim() || name) || `store-${normalizedBrand.slice(0, 8)}`;
                return {
                    name,
                    slugBase,
                    brand: {
                        id: String(brandUnit.id || normalizedBrand),
                        name,
                        slug: String(brandUnit.slug || "").trim() || slugBase,
                        logo_url: String(brandUnit.logo_url || "").trim() || undefined,
                        slogan: String(brandUnit.slogan || "").trim() || undefined,
                        primary_color: String(brandUnit.primary_color || "").trim() || undefined,
                        secondary_color: String(brandUnit.secondary_color || "").trim() || undefined,
                    },
                };
            }
        }
        const fallbackName = "Loja Principal";
        return {
            name: fallbackName,
            slugBase: toSlug(`${fallbackName}-${userId.slice(0, 6)}`) || `store-${Date.now()}`,
            brand: { name: fallbackName },
        };
    }
    async makeUniqueStoreSlug(baseInput) {
        const base = toSlug(baseInput) || `store-${Date.now()}`;
        for (let attempt = 0; attempt < 30; attempt++) {
            const candidate = attempt === 0 ? base : `${base}-${attempt + 1}`;
            const exists = await (0, database_1.queryOne)(`SELECT id FROM storefront_stores WHERE slug = ? LIMIT 1`, [candidate]);
            if (!exists)
                return candidate;
        }
        return `${base}-${Date.now().toString().slice(-6)}`;
    }
    async ensureSingleStoreForBrand(userId, brandId) {
        await this.ensureSchema();
        const scope = this.buildOwnedBrandScope(brandId, "s");
        const existing = await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
       FROM storefront_stores s
      LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
       WHERE s.owner_user_id = ?${scope.sql}
       ORDER BY (s.status = 'active') DESC, s.updated_at DESC
       LIMIT 1`, [userId, ...scope.params]);
        if (existing)
            return this.mapStore(existing);
        const seed = await this.resolveBrandSeed(userId, brandId);
        const uniqueSlug = await this.makeUniqueStoreSlug(seed.slugBase);
        return this.createStore(userId, {
            name: seed.name,
            slug: uniqueSlug,
            status: "active",
            template_id: "modern_minimal",
            brand: seed.brand,
        }, brandId);
    }
    async listTemplates() {
        await this.ensureSchema();
        const rows = await (0, database_1.query)(`SELECT * FROM storefront_templates ORDER BY template_id ASC`);
        return rows.map((row) => this.mapTemplate(row));
    }
    async listStores(userId, brandId) {
        if (normalizeBrandId(brandId)) {
            await this.synchronizeBrandStructure(userId, brandId, { syncProducts: true });
        }
        const primaryStore = await this.ensureSingleStoreForBrand(userId, brandId);
        return primaryStore ? [primaryStore] : [];
    }
    async getStoreById(userId, storeId, brandId) {
        if (normalizeBrandId(brandId)) {
            await this.synchronizeBrandStructure(userId, brandId, { syncProducts: true });
        }
        const row = await this.getOwnedStoreRow(userId, storeId, brandId);
        return row ? this.mapStore(row) : null;
    }
    async createStore(userId, payload, brandId) {
        await this.ensureSchema();
        const scope = this.buildOwnedBrandScope(brandId, "s");
        const existing = await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
       FROM storefront_stores s
      LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
       WHERE s.owner_user_id = ?${scope.sql}
       ORDER BY (s.status = 'active') DESC, s.updated_at DESC
       LIMIT 1`, [userId, ...scope.params]);
        if (existing) {
            const patch = {};
            if (payload.name !== undefined)
                patch.name = payload.name;
            if (payload.slug !== undefined)
                patch.slug = payload.slug;
            if (payload.status !== undefined)
                patch.status = payload.status;
            if (payload.template_id !== undefined)
                patch.template_id = payload.template_id;
            if (payload.brand !== undefined)
                patch.brand = payload.brand;
            if (payload.theme !== undefined)
                patch.theme = payload.theme;
            if (payload.settings !== undefined)
                patch.settings = payload.settings;
            if (Object.keys(patch).length > 0) {
                const updated = await this.updateStore(userId, existing.id, patch, brandId);
                if (updated)
                    return updated;
            }
            return this.mapStore(existing);
        }
        const name = String(payload.name || "").trim();
        if (!name)
            throw new Error("Store name is required");
        const slug = toSlug(payload.slug || name);
        if (!slug)
            throw new Error("Store slug is invalid");
        const slugInUse = await (0, database_1.queryOne)(`SELECT id FROM storefront_stores WHERE slug = ? LIMIT 1`, [slug]);
        if (slugInUse)
            throw new Error("Store slug already in use");
        const templateId = String(payload.template_id || "modern_minimal").trim();
        const template = await (0, database_1.queryOne)(`SELECT template_id FROM storefront_templates WHERE template_id = ? LIMIT 1`, [templateId]);
        if (!template)
            throw new Error("Template not found");
        const id = (0, crypto_1.randomUUID)();
        await (0, database_1.query)(`INSERT INTO storefront_stores
       (id, owner_user_id, brand_id, slug, name, status, template_id, brand_json, theme_json, settings_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            id,
            userId,
            normalizeBrandId(brandId),
            slug,
            name,
            payload.status || "draft",
            templateId,
            JSON.stringify(payload.brand || { name }),
            JSON.stringify(payload.theme || {}),
            JSON.stringify(mergeStoreSettings(payload.settings || {})),
        ]);
        await this.ensureDefaultPagesForStore(id);
        if (payload.custom_domain) {
            await this.upsertDomain(userId, id, payload.custom_domain, true, brandId);
        }
        const created = await this.getOwnedStoreRow(userId, id, brandId);
        if (!created)
            throw new Error("Failed to create store");
        return this.mapStore(created);
    }
    async updateStore(userId, storeId, payload, brandId) {
        await this.ensureSchema();
        const existing = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!existing)
            return null;
        const fields = [];
        const params = [];
        if (payload.name !== undefined) {
            const name = String(payload.name || "").trim();
            if (!name)
                throw new Error("Store name is required");
            fields.push("name = ?");
            params.push(name);
        }
        if (payload.slug !== undefined) {
            const slug = toSlug(payload.slug);
            if (!slug)
                throw new Error("Store slug is invalid");
            const inUse = await (0, database_1.queryOne)(`SELECT id FROM storefront_stores WHERE slug = ? AND id <> ? LIMIT 1`, [slug, storeId]);
            if (inUse)
                throw new Error("Store slug already in use");
            fields.push("slug = ?");
            params.push(slug);
        }
        if (payload.status !== undefined) {
            fields.push("status = ?");
            params.push(payload.status);
        }
        if (payload.template_id !== undefined) {
            const templateId = String(payload.template_id || "").trim();
            const template = await (0, database_1.queryOne)(`SELECT template_id FROM storefront_templates WHERE template_id = ? LIMIT 1`, [templateId]);
            if (!template)
                throw new Error("Template not found");
            fields.push("template_id = ?");
            params.push(templateId);
        }
        if (payload.brand !== undefined) {
            fields.push("brand_json = ?");
            params.push(JSON.stringify(payload.brand || {}));
        }
        if (payload.theme !== undefined) {
            fields.push("theme_json = ?");
            params.push(JSON.stringify(payload.theme || {}));
        }
        if (payload.settings !== undefined) {
            fields.push("settings_json = ?");
            const currentSettings = parseJson(existing.settings_json, {});
            params.push(JSON.stringify(mergeStoreSettingsWithPatch(currentSettings, payload.settings || {})));
        }
        if (fields.length > 0) {
            const normalizedBrand = normalizeBrandId(brandId);
            const brandSql = normalizedBrand ? " AND brand_id = ?" : " AND (brand_id = '' OR brand_id IS NULL)";
            params.push(storeId, userId);
            if (normalizedBrand)
                params.push(normalizedBrand);
            await (0, database_1.update)(`UPDATE storefront_stores SET ${fields.join(", ")}, updated_at = NOW() WHERE id = ? AND owner_user_id = ?${brandSql}`, params);
        }
        const updated = await this.getOwnedStoreRow(userId, storeId, brandId);
        return updated ? this.mapStore(updated) : null;
    }
    async upsertDomain(userId, storeId, domainInput, makePrimary = true, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            throw new Error("Custom domain is invalid");
        const external = await (0, database_1.queryOne)(`SELECT store_id FROM storefront_domains WHERE domain = ? AND store_id <> ? LIMIT 1`, [domain, storeId]);
        if (external)
            throw new Error("Domain already linked to another store");
        if (makePrimary) {
            await (0, database_1.update)(`UPDATE storefront_domains SET is_primary = FALSE WHERE store_id = ?`, [storeId]);
        }
        const current = await (0, database_1.queryOne)(`SELECT id FROM storefront_domains WHERE store_id = ? AND domain = ? LIMIT 1`, [storeId, domain]);
        if (current) {
            await (0, database_1.update)(`UPDATE storefront_domains SET is_primary = ?, verification_status = 'pending', updated_at = NOW() WHERE id = ?`, [makePrimary ? 1 : 0, current.id]);
        }
        else {
            await (0, database_1.query)(`INSERT INTO storefront_domains (id, store_id, domain, is_primary, verification_status)
         VALUES (?, ?, ?, ?, 'pending')`, [(0, crypto_1.randomUUID)(), storeId, domain, makePrimary ? 1 : 0]);
        }
        return (0, database_1.queryOne)(`SELECT * FROM storefront_domains WHERE store_id = ? AND domain = ? LIMIT 1`, [storeId, domain]);
    }
    async listDomains(userId, storeId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        return (0, database_1.query)(`SELECT * FROM storefront_domains WHERE store_id = ? ORDER BY is_primary DESC, domain ASC`, [storeId]);
    }
    async setPrimaryDomain(userId, storeId, domainInput, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            throw new Error("Custom domain is invalid");
        const existing = await (0, database_1.queryOne)(`SELECT id FROM storefront_domains WHERE store_id = ? AND domain = ? LIMIT 1`, [storeId, domain]);
        if (!existing)
            throw new Error("Domain not found");
        await (0, database_1.update)(`UPDATE storefront_domains SET is_primary = FALSE WHERE store_id = ?`, [storeId]);
        await (0, database_1.update)(`UPDATE storefront_domains SET is_primary = TRUE, updated_at = NOW() WHERE id = ?`, [existing.id]);
        return (0, database_1.queryOne)(`SELECT * FROM storefront_domains WHERE id = ? LIMIT 1`, [existing.id]);
    }
    async deleteDomain(userId, storeId, domainInput, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            throw new Error("Custom domain is invalid");
        const existing = await (0, database_1.queryOne)(`SELECT id, is_primary FROM storefront_domains WHERE store_id = ? AND domain = ? LIMIT 1`, [storeId, domain]);
        if (!existing)
            throw new Error("Domain not found");
        const affected = await (0, database_1.update)(`DELETE FROM storefront_domains WHERE id = ?`, [existing.id]);
        if (affected > 0 && Number(existing.is_primary || 0) === 1) {
            const fallback = await (0, database_1.queryOne)(`SELECT id FROM storefront_domains WHERE store_id = ? ORDER BY updated_at DESC, domain ASC LIMIT 1`, [storeId]);
            if (fallback) {
                await (0, database_1.update)(`UPDATE storefront_domains SET is_primary = TRUE, updated_at = NOW() WHERE id = ?`, [fallback.id]);
            }
        }
        return affected > 0;
    }
    async getDomainInstructions(userId, storeId, domainInput, publicHostInput, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            throw new Error("Custom domain is invalid");
        const verificationToken = buildDomainVerificationToken(storeId, domain);
        const verificationHost = `_leadcapture-verify.${domain}`;
        const verificationValue = `leadcapture-verification=${verificationToken}`;
        const publicHost = normalizePublicHost(String(publicHostInput || ""));
        const recordType = domain.startsWith("www.") ? "CNAME" : publicHost ? "ALIAS_OR_A" : "TXT_ONLY";
        return {
            domain,
            verification: {
                type: "TXT",
                host: verificationHost,
                value: verificationValue,
            },
            connection: {
                type: recordType,
                host: domain.startsWith("www.") ? "www" : "@",
                target: publicHost,
                note: publicHost
                    ? domain.startsWith("www.")
                        ? `Crie um CNAME apontando para ${publicHost}`
                        : `Aponte o domínio raiz para o servidor que atende ${publicHost} ou configure ALIAS/ANAME no seu provedor.`
                    : "Configure o apontamento do domínio para o servidor público da aplicação.",
            },
            expected_origin: publicHost ? `https://${domain}` : null,
            verification_token: verificationToken,
        };
    }
    async verifyDomainOwnership(userId, storeId, domainInput, publicHostInput, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            throw new Error("Custom domain is invalid");
        const existing = await (0, database_1.queryOne)(`SELECT id FROM storefront_domains WHERE store_id = ? AND domain = ? LIMIT 1`, [storeId, domain]);
        if (!existing)
            throw new Error("Domain not found");
        const instructions = await this.getDomainInstructions(userId, storeId, domain, publicHostInput, brandId);
        let txtVerified = false;
        let cnameVerified = false;
        let aResolved = false;
        let txtRecords = [];
        let cnameRecords = [];
        let aRecords = [];
        try {
            const txt = await (0, promises_1.resolveTxt)(instructions.verification.host);
            txtRecords = txt.map((entry) => entry.join(""));
            txtVerified = txtRecords.includes(instructions.verification.value);
        }
        catch { }
        try {
            const cname = await (0, promises_1.resolveCname)(domain);
            cnameRecords = cname.map((item) => sanitizeDomain(item));
            const target = normalizePublicHost(String(instructions.connection.target || ""));
            cnameVerified = !!target && cnameRecords.includes(target);
        }
        catch { }
        try {
            const a = await (0, promises_1.resolve4)(domain);
            aRecords = Array.isArray(a) ? a : [];
            aResolved = aRecords.length > 0;
        }
        catch { }
        const verified = txtVerified;
        await (0, database_1.update)(`UPDATE storefront_domains SET verification_status = ?, updated_at = NOW() WHERE id = ?`, [verified ? "verified" : "failed", existing.id]);
        return {
            domain,
            verified,
            verification_status: verified ? "verified" : "failed",
            checks: {
                txt_verified: txtVerified,
                cname_verified: cnameVerified,
                a_resolved: aResolved,
                txt_records: txtRecords,
                cname_records: cnameRecords,
                a_records: aRecords,
            },
            instructions,
        };
    }
    async upsertProduct(userId, storeId, payload, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const productId = String(payload.product_id || "").trim();
        const currency = String(payload.currency || "BRL").toUpperCase().slice(0, 3);
        if (!productId) {
            const name = String(payload.name || "").trim();
            if (!name)
                throw new Error("Product name is required");
            const slug = toSlug(payload.slug || name);
            if (!slug)
                throw new Error("Product slug is invalid");
            const used = await (0, database_1.queryOne)(`SELECT id FROM storefront_products WHERE store_id = ? AND slug = ? LIMIT 1`, [storeId, slug]);
            if (used)
                throw new Error("Product slug already in use for this store");
            const id = (0, crypto_1.randomUUID)();
            await (0, database_1.query)(`INSERT INTO storefront_products
         (id, store_id, slug, name, description, category, price, compare_at_price, currency, images_json, variants_json, metadata_json, is_active, position)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
                id,
                storeId,
                slug,
                name,
                payload.description || null,
                payload.category || null,
                toNumber(payload.price, 0),
                payload.compare_at_price == null ? null : toNumber(payload.compare_at_price, 0),
                currency,
                JSON.stringify(payload.images || []),
                JSON.stringify(payload.variants || []),
                JSON.stringify(payload.metadata || {}),
                payload.is_active === false ? 0 : 1,
                Number(payload.position || 0),
            ]);
            return (0, database_1.queryOne)(`SELECT * FROM storefront_products WHERE id = ? LIMIT 1`, [id]);
        }
        const existing = await (0, database_1.queryOne)(`SELECT p.id FROM storefront_products p INNER JOIN storefront_stores s ON s.id = p.store_id
       WHERE p.id = ? AND p.store_id = ? AND s.owner_user_id = ? LIMIT 1`, [productId, storeId, userId]);
        if (!existing)
            throw new Error("Product not found");
        const fields = [];
        const params = [];
        if (payload.name !== undefined) {
            fields.push("name = ?");
            params.push(String(payload.name || "").trim());
        }
        if (payload.slug !== undefined) {
            const slug = toSlug(payload.slug);
            if (!slug)
                throw new Error("Product slug is invalid");
            fields.push("slug = ?");
            params.push(slug);
        }
        if (payload.description !== undefined) {
            fields.push("description = ?");
            params.push(payload.description || null);
        }
        if (payload.category !== undefined) {
            fields.push("category = ?");
            params.push(payload.category || null);
        }
        if (payload.price !== undefined) {
            fields.push("price = ?");
            params.push(toNumber(payload.price, 0));
        }
        if (payload.compare_at_price !== undefined) {
            fields.push("compare_at_price = ?");
            params.push(payload.compare_at_price == null ? null : toNumber(payload.compare_at_price, 0));
        }
        if (payload.currency !== undefined) {
            fields.push("currency = ?");
            params.push(currency);
        }
        if (payload.images !== undefined) {
            fields.push("images_json = ?");
            params.push(JSON.stringify(payload.images || []));
        }
        if (payload.variants !== undefined) {
            fields.push("variants_json = ?");
            params.push(JSON.stringify(payload.variants || []));
        }
        if (payload.metadata !== undefined) {
            fields.push("metadata_json = ?");
            params.push(JSON.stringify(payload.metadata || {}));
        }
        if (payload.is_active !== undefined) {
            fields.push("is_active = ?");
            params.push(payload.is_active ? 1 : 0);
        }
        if (payload.position !== undefined) {
            fields.push("position = ?");
            params.push(Number(payload.position || 0));
        }
        if (fields.length > 0) {
            params.push(productId);
            await (0, database_1.update)(`UPDATE storefront_products SET ${fields.join(", ")}, updated_at = NOW() WHERE id = ?`, params);
        }
        return (0, database_1.queryOne)(`SELECT * FROM storefront_products WHERE id = ? LIMIT 1`, [productId]);
    }
    async listProducts(userId, storeId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        await this.synchronizeStoreProductsFromCatalog(store);
        return (0, database_1.query)(`SELECT * FROM storefront_products WHERE store_id = ? ORDER BY position ASC, created_at DESC`, [storeId]);
    }
    async upsertPage(userId, storeId, payload, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const pageId = String(payload.page_id || "").trim();
        if (!pageId) {
            const title = String(payload.title || "").trim();
            if (!title)
                throw new Error("Page title is required");
            const slug = toSlug(payload.slug || title);
            if (!slug)
                throw new Error("Page slug is invalid");
            const used = await (0, database_1.queryOne)(`SELECT id FROM storefront_pages WHERE store_id = ? AND slug = ? LIMIT 1`, [storeId, slug]);
            if (used)
                throw new Error("Page slug already in use for this store");
            const id = (0, crypto_1.randomUUID)();
            await (0, database_1.query)(`INSERT INTO storefront_pages
         (id, store_id, slug, title, page_type, sections_json, seo_json, is_published, created_by_ai)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
                id,
                storeId,
                slug,
                title,
                payload.page_type || "custom",
                JSON.stringify(payload.sections || []),
                JSON.stringify(payload.seo || {}),
                payload.is_published === false ? 0 : 1,
                payload.created_by_ai ? 1 : 0,
            ]);
            return (0, database_1.queryOne)(`SELECT * FROM storefront_pages WHERE id = ? LIMIT 1`, [id]);
        }
        const existing = await (0, database_1.queryOne)(`SELECT p.id FROM storefront_pages p INNER JOIN storefront_stores s ON s.id = p.store_id
       WHERE p.id = ? AND p.store_id = ? AND s.owner_user_id = ? LIMIT 1`, [pageId, storeId, userId]);
        if (!existing)
            throw new Error("Page not found");
        const fields = [];
        const params = [];
        if (payload.title !== undefined) {
            const title = String(payload.title || "").trim();
            if (!title)
                throw new Error("Page title is required");
            fields.push("title = ?");
            params.push(title);
        }
        if (payload.slug !== undefined) {
            const slug = toSlug(payload.slug);
            if (!slug)
                throw new Error("Page slug is invalid");
            fields.push("slug = ?");
            params.push(slug);
        }
        if (payload.page_type !== undefined) {
            fields.push("page_type = ?");
            params.push(payload.page_type);
        }
        if (payload.sections !== undefined) {
            fields.push("sections_json = ?");
            params.push(JSON.stringify(payload.sections || []));
        }
        if (payload.seo !== undefined) {
            fields.push("seo_json = ?");
            params.push(JSON.stringify(payload.seo || {}));
        }
        if (payload.is_published !== undefined) {
            fields.push("is_published = ?");
            params.push(payload.is_published ? 1 : 0);
        }
        if (payload.created_by_ai !== undefined) {
            fields.push("created_by_ai = ?");
            params.push(payload.created_by_ai ? 1 : 0);
        }
        if (fields.length > 0) {
            params.push(pageId);
            await (0, database_1.update)(`UPDATE storefront_pages SET ${fields.join(", ")}, updated_at = NOW() WHERE id = ?`, params);
        }
        return (0, database_1.queryOne)(`SELECT * FROM storefront_pages WHERE id = ? LIMIT 1`, [pageId]);
    }
    async listPages(userId, storeId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        return (0, database_1.query)(`SELECT * FROM storefront_pages WHERE store_id = ? ORDER BY created_at ASC`, [storeId]);
    }
    extractStoreSettings(store) {
        const source = store.settings !== undefined ? store.settings : store.settings_json;
        return mergeStoreSettings(parseJson(source, {}));
    }
    async getStoreByIdRaw(storeId) {
        return ((await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
         FROM storefront_stores s
         LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
         WHERE s.id = ?
         LIMIT 1`, [storeId])) || null);
    }
    async getOrderRow(storeId, orderId) {
        return ((await (0, database_1.queryOne)(`SELECT * FROM storefront_orders WHERE id = ? AND store_id = ? LIMIT 1`, [orderId, storeId])) ||
            null);
    }
    async appendOrderTimeline(input) {
        await (0, database_1.query)(`INSERT INTO storefront_order_timeline
       (id, order_id, store_id, event_type, status_before, status_after, actor_type, actor_name, payload_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            (0, crypto_1.randomUUID)(),
            input.orderId,
            input.storeId,
            input.eventType,
            input.statusBefore || null,
            input.statusAfter || null,
            input.actorType || "system",
            input.actorName || null,
            JSON.stringify(input.payload || {}),
        ]);
    }
    buildDeliveryAddress(addressInput) {
        const address = parseJson(addressInput, {});
        const street = String(address.rua || address.street || address.logradouro || "").trim();
        const number = String(address.numero || address.number || "").trim();
        const district = String(address.bairro || address.district || "").trim();
        const city = String(address.cidade || address.city || "").trim();
        const state = String(address.estado || address.state || "").trim();
        const zip = String(address.cep || address.zip || "").trim();
        const line = [street, number].filter(Boolean).join(", ");
        const full = [line, district, city, state, zip].filter(Boolean).join(", ").trim();
        return full || null;
    }
    buildGoogleMapsRoute(addressInput) {
        const destination = this.buildDeliveryAddress(addressInput);
        if (!destination)
            return null;
        return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(destination)}`;
    }
    resolveConfirmBaseUrl(store, settings) {
        const candidate = String(settings?.logistics?.confirm_base_url ||
            process.env.STOREFRONT_CONFIRM_BASE_URL ||
            process.env.APP_BASE_URL ||
            process.env.PUBLIC_BASE_URL ||
            "").trim();
        if (candidate) {
            if (/^https?:\/\//i.test(candidate))
                return candidate.replace(/\/+$/, "");
            return `https://${sanitizeDomain(candidate)}`;
        }
        const domain = sanitizeDomain(String(store.primary_domain || ""));
        if (domain)
            return `https://${domain}`;
        return "https://app.seusistema.com";
    }
    buildConfirmUrl(store, settings, token) {
        const base = this.resolveConfirmBaseUrl(store, settings);
        return `${base}/api/storefront/public/delivery/confirm?token=${encodeURIComponent(token)}`;
    }
    async generateDeliveryToken(orderNumber, tokenPrefixInput) {
        const prefix = String(tokenPrefixInput || "DEL")
            .replace(/[^a-z0-9]/gi, "")
            .toUpperCase()
            .slice(0, 8) || "DEL";
        const orderRef = String(orderNumber || "")
            .replace(/[^a-z0-9]/gi, "")
            .toUpperCase()
            .slice(-6) || "ORDER";
        for (let i = 0; i < 12; i += 1) {
            const suffix = Math.random().toString(36).slice(2, 7).toUpperCase();
            const token = `${prefix}-${orderRef}-${suffix}`;
            const exists = (await (0, database_1.queryOne)(`SELECT id FROM storefront_delivery_tokens WHERE token = ? LIMIT 1`, [token])) ||
                (await (0, database_1.queryOne)(`SELECT id FROM storefront_orders WHERE delivery_token = ? LIMIT 1`, [token]));
            if (!exists)
                return token;
        }
        throw new Error("Failed to generate unique delivery token");
    }
    async createNotification(input) {
        await (0, database_1.query)(`INSERT INTO storefront_order_notifications
       (id, order_id, store_id, channel, target, status, payload_json)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`, [(0, crypto_1.randomUUID)(), input.orderId, input.storeId, input.channel, input.target || null, JSON.stringify(input.payload)]);
    }
    async queueCustomerMessage(order, stage, message, payload) {
        const target = String(order.customer_phone || "").trim();
        if (!target)
            return;
        await this.createNotification({
            orderId: order.id,
            storeId: order.store_id,
            channel: "whatsapp",
            target,
            payload: {
                event: "customer.status_update",
                stage,
                message,
                order_id: order.id,
                order_number: order.order_number,
                ...payload,
            },
        });
    }
    async queuePostSale(order) {
        const stages = [
            { stage: "2h_checkin", delayHours: 2 },
            { stage: "24h_review", delayHours: 24 },
        ];
        for (const item of stages) {
            const exists = await (0, database_1.queryOne)(`SELECT id FROM storefront_post_sale_queue WHERE order_id = ? AND stage = ? LIMIT 1`, [order.id, item.stage]);
            if (exists)
                continue;
            const runAt = new Date(Date.now() + item.delayHours * 60 * 60 * 1000);
            await (0, database_1.query)(`INSERT INTO storefront_post_sale_queue (id, order_id, store_id, stage, run_at, status, payload_json)
         VALUES (?, ?, ?, ?, ?, 'pending', ?)`, [
                (0, crypto_1.randomUUID)(),
                order.id,
                order.store_id,
                item.stage,
                toSqlDateTime(runAt),
                JSON.stringify({
                    stage: item.stage,
                    queued_at: new Date().toISOString(),
                    order_number: order.order_number,
                }),
            ]);
        }
    }
    async transitionOrderStatus(order, status, input) {
        const extraFields = input.extraFields || {};
        const keys = Object.keys(extraFields);
        if (order.status === status && keys.length === 0) {
            return order;
        }
        const sets = ["status = ?", "updated_at = NOW()"];
        const params = [status];
        for (const key of keys) {
            sets.push(`${key} = ?`);
            params.push(extraFields[key]);
        }
        params.push(order.id, order.store_id);
        await (0, database_1.update)(`UPDATE storefront_orders SET ${sets.join(", ")} WHERE id = ? AND store_id = ?`, params);
        const updated = await this.getOrderRow(order.store_id, order.id);
        if (!updated)
            throw new Error("Order not found");
        await this.appendOrderTimeline({
            orderId: order.id,
            storeId: order.store_id,
            eventType: input.eventType,
            statusBefore: order.status,
            statusAfter: status,
            actorType: input.actorType || "system",
            actorName: input.actorName || null,
            payload: input.payload || {},
        });
        return updated;
    }
    async listOrders(userId, storeId, options, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const where = ["store_id = ?"];
        const params = [storeId];
        if (options?.status) {
            where.push("status = ?");
            params.push(options.status);
        }
        const safeLimit = Math.max(1, Math.min(Number.parseInt(String(options?.limit ?? 100), 10) || 100, 200));
        const safeOffset = Math.max(0, Number.parseInt(String(options?.offset ?? 0), 10) || 0);
        return (0, database_1.query)(`SELECT * FROM storefront_orders WHERE ${where.join(" AND ")} ORDER BY created_at DESC LIMIT ${safeLimit} OFFSET ${safeOffset}`, params);
    }
    async listOrderTimeline(userId, storeId, orderId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            throw new Error("Order not found");
        return (0, database_1.query)(`SELECT * FROM storefront_order_timeline WHERE store_id = ? AND order_id = ? ORDER BY created_at ASC`, [storeId, orderId]);
    }
    async getOrderFlowAutomation(userId, storeId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const settings = this.extractStoreSettings({ settings_json: store.settings_json });
        return {
            order_flow: settings.automation?.order_flow || defaultStoreSettings().automation.order_flow,
            logistics: settings.logistics || defaultStoreSettings().logistics,
            notifications: settings.notifications || defaultStoreSettings().notifications,
        };
    }
    async updateOrderFlowAutomation(userId, storeId, payload, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const currentSettings = this.extractStoreSettings({ settings_json: store.settings_json });
        const patch = {
            logistics: payload.logistics || {},
            notifications: payload.notifications || {},
            automation: {
                order_flow: {},
            },
        };
        if (payload.active !== undefined) {
            patch.automation.order_flow.active = !!payload.active;
        }
        const merged = mergeStoreSettingsWithPatch(currentSettings, patch);
        await (0, database_1.update)(`UPDATE storefront_stores SET settings_json = ?, updated_at = NOW() WHERE id = ? AND owner_user_id = ?`, [
            JSON.stringify(merged),
            storeId,
            userId,
        ]);
        return {
            order_flow: merged.automation?.order_flow || defaultStoreSettings().automation.order_flow,
            logistics: merged.logistics || defaultStoreSettings().logistics,
            notifications: merged.notifications || defaultStoreSettings().notifications,
        };
    }
    async dispatchPostSaleQueue(userId, storeId, limit = 30, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const rows = await (0, database_1.query)(`SELECT q.id, q.order_id, q.store_id, q.stage, q.payload_json, o.customer_name, o.customer_phone, o.order_number
       FROM storefront_post_sale_queue q
       INNER JOIN storefront_orders o ON o.id = q.order_id
       WHERE q.store_id = ? AND q.status = 'pending' AND q.run_at <= NOW()
       ORDER BY q.run_at ASC
       LIMIT ?`, [storeId, Math.max(1, Math.min(Number(limit || 30), 200))]);
        let sent = 0;
        let failed = 0;
        for (const item of rows) {
            try {
                const order = (await this.getOrderRow(item.store_id, item.order_id));
                if (!order) {
                    failed += 1;
                    await (0, database_1.update)(`UPDATE storefront_post_sale_queue SET status = 'failed', payload_json = ?, updated_at = NOW() WHERE id = ?`, [JSON.stringify({ error: "order_not_found" }), item.id]);
                    continue;
                }
                const message = item.stage === "2h_checkin"
                    ? "Seu pedido chegou tudo certo? Se precisar de algo, estou aqui."
                    : "Pode avaliar sua experiencia? Sua opiniao ajuda muito nossa loja.";
                await this.queueCustomerMessage(order, item.stage, message, {
                    post_sale_stage: item.stage,
                    order_number: item.order_number,
                });
                await (0, database_1.update)(`UPDATE storefront_post_sale_queue SET status = 'sent', updated_at = NOW() WHERE id = ?`, [item.id]);
                sent += 1;
            }
            catch (error) {
                failed += 1;
                await (0, database_1.update)(`UPDATE storefront_post_sale_queue SET status = 'failed', payload_json = ?, updated_at = NOW() WHERE id = ?`, [JSON.stringify({ error: String(error?.message || "dispatch_failed") }), item.id]);
            }
        }
        return { total: rows.length, sent, failed };
    }
    async confirmOrderPayment(userId, storeId, orderId, actorName, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            throw new Error("Order not found");
        const updated = await this.transitionOrderStatus(order, "aprovado", {
            eventType: "payment.confirmed",
            actorType: "admin",
            actorName: actorName || null,
            payload: { order_number: order.order_number },
        });
        await this.queueCustomerMessage(updated, "payment_confirmed", `Pagamento confirmado para o pedido #${updated.order_number}. Seu pedido esta sendo preparado.`);
        return updated;
    }
    async startOrderPreparation(userId, storeId, orderId, actorName, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            throw new Error("Order not found");
        const updated = await this.transitionOrderStatus(order, "em_preparacao", {
            eventType: "order.preparation_started",
            actorType: "admin",
            actorName: actorName || null,
            payload: { order_number: order.order_number },
        });
        await this.queueCustomerMessage(updated, "preparation_started", `Estamos preparando seu pedido #${updated.order_number}.`);
        return updated;
    }
    async sendOrderOutForDelivery(userId, storeId, orderId, payload, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            throw new Error("Order not found");
        const settings = this.extractStoreSettings({ settings_json: store.settings_json });
        const etaMinutes = Math.max(5, Math.min(Number(payload?.eta_minutes || settings.logistics?.default_eta_minutes || 40), 240));
        const courierName = String(payload?.courier_name || order.courier_name || "").trim() || null;
        const courierPhone = String(payload?.courier_phone || order.courier_phone || "").trim() || null;
        const token = await this.generateDeliveryToken(order.order_number, String(settings.logistics?.token_prefix || "DEL"));
        const confirmUrl = this.buildConfirmUrl(store, settings, token);
        const qrDataUrl = await qrcode_1.default.toDataURL(confirmUrl, { width: 320, margin: 1 });
        const routeUrl = this.buildGoogleMapsRoute(order.customer_address_json);
        await (0, database_1.update)(`UPDATE storefront_delivery_tokens
       SET used_at = NOW(), used_via = 'admin', used_by = 'system:rotated', updated_at = NOW()
       WHERE order_id = ? AND used_at IS NULL`, [order.id]);
        const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
        await (0, database_1.query)(`INSERT INTO storefront_delivery_tokens
       (id, order_id, store_id, token, expires_at, used_at, used_via, used_by)
       VALUES (?, ?, ?, ?, ?, NULL, NULL, NULL)`, [(0, crypto_1.randomUUID)(), order.id, order.store_id, token, toSqlDateTime(expiresAt)]);
        const updated = await this.transitionOrderStatus(order, "saiu_para_entrega", {
            eventType: "delivery.out_for_delivery",
            actorType: "admin",
            payload: {
                order_number: order.order_number,
                courier_name: courierName,
                courier_phone: courierPhone,
                eta_minutes: etaMinutes,
            },
            extraFields: {
                delivery_token: token,
                delivery_status: "aguardando_confirmacao",
                delivery_qr_data_url: qrDataUrl,
                courier_name: courierName,
                courier_phone: courierPhone,
                courier_route_url: routeUrl,
            },
        });
        await this.queueCustomerMessage(updated, "out_for_delivery", `Seu pedido #${updated.order_number} saiu para entrega. Previsao: ${etaMinutes} minutos.`, {
            delivery_token: token,
            confirm_url: confirmUrl,
            courier_name: courierName,
            courier_phone: courierPhone,
            courier_route_url: routeUrl,
            delivery_qr_data_url: qrDataUrl,
        });
        return {
            order: updated,
            delivery: {
                token,
                confirm_url: confirmUrl,
                qr_data_url: qrDataUrl,
                route_url: routeUrl,
                eta_minutes: etaMinutes,
                courier_name: courierName,
                courier_phone: courierPhone,
            },
        };
    }
    async completeDelivery(order, input) {
        if (order.status === "entregue") {
            return order;
        }
        const updated = await this.transitionOrderStatus(order, "entregue", {
            eventType: "delivery.confirmed",
            actorType: input.via === "admin" ? "admin" : "courier",
            actorName: input.confirmedBy || null,
            payload: { via: input.via },
            extraFields: {
                delivery_status: "confirmado",
                delivered_at: toSqlDateTime(new Date()),
                delivery_confirmed_by: input.confirmedBy || "cliente",
                delivery_confirmed_via: input.via,
            },
        });
        await this.queueCustomerMessage(updated, "delivery_confirmed", `Entrega confirmada do pedido #${updated.order_number}. Obrigado pela compra!`);
        await this.queuePostSale(updated);
        return updated;
    }
    async confirmOrderDeliveryByAdmin(userId, storeId, orderId, actorName, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            throw new Error("Order not found");
        if (order.delivery_token) {
            await (0, database_1.update)(`UPDATE storefront_delivery_tokens
         SET used_at = IFNULL(used_at, NOW()), used_via = IFNULL(used_via, 'admin'), used_by = IFNULL(used_by, ?), updated_at = NOW()
         WHERE token = ?`, [actorName || "admin", order.delivery_token]);
        }
        return this.completeDelivery(order, { via: "admin", confirmedBy: actorName || "admin" });
    }
    async confirmOrderDeliveryByToken(tokenInput, via = "token", actorName) {
        await this.ensureSchema();
        const token = String(tokenInput || "").trim().toUpperCase();
        if (!token)
            throw new Error("delivery token is required");
        const tokenRow = (await (0, database_1.queryOne)(`SELECT id, order_id, store_id, token, expires_at, used_at FROM storefront_delivery_tokens WHERE token = ? LIMIT 1`, [token])) ||
            null;
        let order = null;
        if (tokenRow) {
            order = await this.getOrderRow(tokenRow.store_id, tokenRow.order_id);
        }
        if (!order) {
            order =
                (await (0, database_1.queryOne)(`SELECT * FROM storefront_orders WHERE delivery_token = ? LIMIT 1`, [token])) || null;
        }
        if (!order)
            throw new Error("Delivery token not found");
        if (tokenRow?.expires_at && !tokenRow.used_at) {
            const expires = new Date(tokenRow.expires_at);
            if (Number.isFinite(expires.getTime()) && expires.getTime() < Date.now()) {
                await (0, database_1.update)(`UPDATE storefront_orders SET delivery_status = 'expirado', updated_at = NOW() WHERE id = ?`, [order.id]);
                await (0, database_1.update)(`UPDATE storefront_delivery_tokens SET used_via = 'admin', used_by = 'expired', updated_at = NOW() WHERE id = ?`, [
                    tokenRow.id,
                ]);
                throw new Error("Delivery token expired");
            }
        }
        if (tokenRow && tokenRow.used_at) {
            const latest = await this.getOrderRow(order.store_id, order.id);
            if (!latest)
                throw new Error("Order not found");
            return { order: latest, already_confirmed: true };
        }
        if (tokenRow) {
            await (0, database_1.update)(`UPDATE storefront_delivery_tokens SET used_at = NOW(), used_via = ?, used_by = ?, updated_at = NOW() WHERE id = ?`, [via, actorName || "token_validation", tokenRow.id]);
        }
        else {
            await (0, database_1.query)(`INSERT INTO storefront_delivery_tokens
         (id, order_id, store_id, token, expires_at, used_at, used_via, used_by)
         VALUES (?, ?, ?, ?, NULL, NOW(), ?, ?)`, [(0, crypto_1.randomUUID)(), order.id, order.store_id, token, via, actorName || "token_validation"]);
        }
        const completed = await this.completeDelivery(order, {
            via: via === "admin" ? "admin" : via === "qr" ? "qr" : "token",
            confirmedBy: actorName || "cliente",
        });
        return { order: completed, already_confirmed: false };
    }
    async updateOrderStatus(userId, storeId, orderId, status, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        const order = await this.getOrderRow(storeId, orderId);
        if (!order)
            return null;
        if (status === "aprovado")
            return this.confirmOrderPayment(userId, storeId, orderId, undefined, brandId);
        if (status === "em_preparacao")
            return this.startOrderPreparation(userId, storeId, orderId, undefined, brandId);
        if (status === "saiu_para_entrega") {
            const result = await this.sendOrderOutForDelivery(userId, storeId, orderId, undefined, brandId);
            return result.order;
        }
        if (status === "entregue")
            return this.confirmOrderDeliveryByAdmin(userId, storeId, orderId, undefined, brandId);
        const updated = await this.transitionOrderStatus(order, status, {
            eventType: "order.status_updated",
            actorType: "admin",
            payload: { status },
        });
        return updated;
    }
    async listOrderNotifications(userId, storeId, orderId, brandId) {
        await this.ensureSchema();
        const store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            throw new Error("Store not found");
        return (0, database_1.query)(`SELECT * FROM storefront_order_notifications WHERE store_id = ? AND order_id = ? ORDER BY created_at ASC`, [storeId, orderId]);
    }
    async resolvePublicStore(input) {
        await this.ensureSchema();
        const host = String(input.host || "").trim();
        let store = null;
        if (host) {
            const domains = domainCandidates(host);
            if (domains.length > 0) {
                const placeholders = domains.map(() => "?").join(",");
                store =
                    (await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
             FROM storefront_domains d
             INNER JOIN storefront_stores s ON s.id = d.store_id
             WHERE d.domain IN (${placeholders})
               AND (
                 s.status = 'active'
                 OR EXISTS (
                   SELECT 1
                   FROM storefront_pages hp
                   WHERE hp.store_id = s.id
                     AND hp.is_published = TRUE
                     AND (hp.page_type = 'home' OR hp.slug = 'home')
                 )
               )
             ORDER BY d.is_primary DESC
             LIMIT 1`, domains)) || null;
            }
        }
        if (!store && input.slug) {
            const slug = toSlug(input.slug);
            if (slug) {
                store =
                    (await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
             FROM storefront_stores s
             LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
             WHERE s.slug = ?
               AND (
                 s.status = 'active'
                 OR EXISTS (
                   SELECT 1
                   FROM storefront_pages hp
                   WHERE hp.store_id = s.id
                     AND hp.is_published = TRUE
                     AND (hp.page_type = 'home' OR hp.slug = 'home')
                 )
               )
             LIMIT 1`, [slug])) || null;
                if (!store) {
                    store =
                        (await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
               FROM storefront_pages p
               INNER JOIN storefront_stores s ON s.id = p.store_id
               LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
               WHERE p.slug = ?
                 AND p.is_published = TRUE
                 AND (p.page_type = 'home' OR p.slug = 'home')
                 AND (
                   s.status = 'active'
                   OR EXISTS (
                     SELECT 1
                     FROM storefront_pages hp
                     WHERE hp.store_id = s.id
                       AND hp.is_published = TRUE
                       AND (hp.page_type = 'home' OR hp.slug = 'home')
                   )
                 )
               LIMIT 1`, [slug])) || null;
                }
            }
        }
        if (!store)
            return null;
        await this.synchronizeStoreBrandIdentity(store);
        await this.synchronizeStoreProductsFromCatalog(store);
        const refreshedStore = await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
       FROM storefront_stores s
       LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
       WHERE s.id = ?
       LIMIT 1`, [store.id]);
        if (refreshedStore) {
            store = refreshedStore;
        }
        const [template, products, pages, domains] = await Promise.all([
            (0, database_1.queryOne)(`SELECT * FROM storefront_templates WHERE template_id = ? LIMIT 1`, [store.template_id]),
            (0, database_1.query)(`SELECT * FROM storefront_products WHERE store_id = ? AND is_active = TRUE ORDER BY position ASC, created_at DESC`, [store.id]),
            (0, database_1.query)(`SELECT * FROM storefront_pages WHERE store_id = ? AND is_published = TRUE ORDER BY created_at ASC`, [store.id]),
            (0, database_1.query)(`SELECT domain FROM storefront_domains WHERE store_id = ? ORDER BY is_primary DESC`, [store.id]),
        ]);
        return {
            store: this.mapStore(store),
            template: template ? this.mapTemplate(template) : null,
            products,
            pages,
            domains: domains.map((row) => row.domain),
        };
    }
    async getPublicProduct(storeSlug, productSlug) {
        await this.ensureSchema();
        const slug = toSlug(storeSlug);
        const product = toSlug(productSlug);
        if (!slug || !product)
            return null;
        let store = (await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
         FROM storefront_stores s
         LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
         WHERE s.slug = ?
           AND (
             s.status = 'active'
             OR EXISTS (
               SELECT 1
               FROM storefront_pages hp
               WHERE hp.store_id = s.id
                 AND hp.is_published = TRUE
                 AND (hp.page_type = 'home' OR hp.slug = 'home')
             )
           )
         LIMIT 1`, [slug])) || null;
        if (!store)
            return null;
        await this.synchronizeStoreBrandIdentity(store);
        await this.synchronizeStoreProductsFromCatalog(store);
        const refreshedStore = await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
       FROM storefront_stores s
       LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
       WHERE s.id = ?
       LIMIT 1`, [store.id]);
        if (refreshedStore) {
            store = refreshedStore;
        }
        return (0, database_1.queryOne)(`SELECT p.*
       FROM storefront_products p
       WHERE p.store_id = ?
         AND p.slug = ?
         AND p.is_active = TRUE
       LIMIT 1`, [store.id, product]);
    }
    async getPublicPage(storeSlug, pageSlug) {
        await this.ensureSchema();
        const slug = toSlug(storeSlug);
        const page = toSlug(pageSlug);
        if (!slug || !page)
            return null;
        let store = (await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
         FROM storefront_stores s
         LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
         WHERE s.slug = ?
           AND (
             s.status = 'active'
             OR EXISTS (
               SELECT 1
               FROM storefront_pages hp
               WHERE hp.store_id = s.id
                 AND hp.is_published = TRUE
                 AND (hp.page_type = 'home' OR hp.slug = 'home')
             )
           )
         LIMIT 1`, [slug])) || null;
        if (!store)
            return null;
        await this.synchronizeStoreBrandIdentity(store);
        await this.synchronizeStoreProductsFromCatalog(store);
        const refreshedStore = await (0, database_1.queryOne)(`SELECT s.*, d.domain AS primary_domain
       FROM storefront_stores s
       LEFT JOIN storefront_domains d ON d.store_id = s.id AND d.is_primary = TRUE
       WHERE s.id = ?
       LIMIT 1`, [store.id]);
        if (refreshedStore) {
            store = refreshedStore;
        }
        return (0, database_1.queryOne)(`SELECT p.*
       FROM storefront_pages p
       WHERE p.store_id = ?
         AND p.slug = ?
         AND p.is_published = TRUE
       LIMIT 1`, [store.id, page]);
    }
    /** Find existing customer by phone (preferred) or email, or create a new record */
    async findOrCreateCustomer(storeId, data) {
        const phone = String(data.phone || "").replace(/\D/g, "");
        const email = String(data.email || "").trim().toLowerCase() || null;
        // Try match by phone first (most reliable for this domain)
        let existing = null;
        if (phone) {
            existing = await (0, database_1.queryOne)(`SELECT id FROM storefront_customers WHERE store_id = ? AND phone = ? LIMIT 1`, [storeId, phone]);
        }
        if (!existing && email) {
            existing = await (0, database_1.queryOne)(`SELECT id FROM storefront_customers WHERE store_id = ? AND email = ? LIMIT 1`, [storeId, email]);
        }
        if (existing) {
            // Update name / address on returning customer
            await (0, database_1.update)(`UPDATE storefront_customers SET name = ?, email = COALESCE(?, email), address_json = ?, updated_at = NOW() WHERE id = ?`, [data.name, email, JSON.stringify(data.address || {}), existing.id]);
            return String(existing.id);
        }
        const id = (0, crypto_1.randomUUID)();
        await (0, database_1.query)(`INSERT INTO storefront_customers (id, store_id, name, email, phone, address_json) VALUES (?, ?, ?, ?, ?, ?)`, [id, storeId, data.name, email, phone, JSON.stringify(data.address || {})]);
        return id;
    }
    async createPublicOrder(storeSlug, payload) {
        await this.ensureSchema();
        const storeBundle = await this.resolvePublicStore({ slug: storeSlug });
        if (!storeBundle)
            throw new Error("Store not found");
        const items = Array.isArray(payload.items) ? payload.items : [];
        if (items.length === 0)
            throw new Error("Order requires at least one product");
        const productIds = Array.from(new Set(items.map((i) => String(i.product_id || "").trim()).filter(Boolean)));
        if (productIds.length === 0)
            throw new Error("Order products are invalid");
        const placeholders = productIds.map(() => "?").join(",");
        const products = (await (0, database_1.query)(`SELECT * FROM storefront_products WHERE store_id = ? AND is_active = TRUE AND id IN (${placeholders})`, [storeBundle.store.id, ...productIds]));
        const map = new Map(products.map((p) => [String(p.id), p]));
        const normalizedItems = items.map((item) => {
            const productId = String(item.product_id || "").trim();
            const quantity = Math.max(1, Math.min(99, Number(item.quantity || 1)));
            const product = map.get(productId);
            if (!product)
                throw new Error(`Product not available: ${productId}`);
            const price = toNumber(product.price, 0);
            return {
                product_id: product.id,
                product_slug: product.slug,
                name: product.name,
                unit_price: price,
                quantity,
                line_total: Number((price * quantity).toFixed(2)),
            };
        });
        const subtotal = Number(normalizedItems.reduce((sum, item) => sum + Number(item.line_total || 0), 0).toFixed(2));
        const total = subtotal;
        const customerName = String(payload.customer?.name || "").trim();
        const customerPhone = String(payload.customer?.phone || "").trim();
        if (!customerName || !customerPhone)
            throw new Error("Customer name and phone are required");
        const orderId = (0, crypto_1.randomUUID)();
        const orderNumber = this.generateOrderNumber();
        const customerEmail = String(payload.customer?.email || "").trim() || null;
        const paymentMethod = String(payload.payment_method || "").trim().toLowerCase() || null;
        const inventoryUserId = String(storeBundle.store.owner_user_id || "").trim();
        const inventoryBrandId = normalizeBrandId(storeBundle.store.brand_id || "") || null;
        for (const item of normalizedItems) {
            const stock = await this.inventoryService.getProductStock(inventoryUserId, inventoryBrandId, String(item.product_id));
            const available = Number(stock?.stock_available || 0);
            if (available < Number(item.quantity || 0)) {
                throw new Error(`Estoque insuficiente para ${item.name}. Disponível: ${available}, Solicitado: ${Number(item.quantity || 0)}`);
            }
        }
        const customerId = await this.findOrCreateCustomer(storeBundle.store.id, {
            name: customerName,
            phone: customerPhone,
            email: customerEmail,
            address: payload.customer?.address,
        });
        const reservedItems = [];
        try {
            for (const item of normalizedItems) {
                await this.inventoryService.reserveStock(inventoryUserId, inventoryBrandId, String(item.product_id), Number(item.quantity || 0), orderId);
                reservedItems.push({ product_id: String(item.product_id), quantity: Number(item.quantity || 0) });
            }
            await (0, database_1.query)(`INSERT INTO storefront_orders
         (id, order_number, store_id, customer_id, status, currency, subtotal, shipping, discount, total, payment_method, customer_name, customer_phone, customer_email, customer_address_json, items_json, notes, source)
         VALUES (?, ?, ?, ?, 'novo', 'BRL', ?, 0, 0, ?, ?, ?, ?, ?, ?, ?, ?, 'site')`, [
                orderId,
                orderNumber,
                storeBundle.store.id,
                customerId,
                subtotal,
                total,
                paymentMethod,
                customerName,
                customerPhone,
                customerEmail,
                JSON.stringify(payload.customer?.address || {}),
                JSON.stringify(normalizedItems),
                String(payload.notes || "").trim() || null,
            ]);
        }
        catch (error) {
            for (const item of reservedItems) {
                await this.inventoryService
                    .releaseStock(inventoryUserId, inventoryBrandId, item.product_id, item.quantity, orderId)
                    .catch(() => undefined);
            }
            throw error;
        }
        await this.appendOrderTimeline({
            orderId,
            storeId: storeBundle.store.id,
            eventType: "order.created",
            statusBefore: null,
            statusAfter: "novo",
            actorType: "customer",
            actorName: customerName,
            payload: {
                order_number: orderNumber,
                payment_method: paymentMethod,
                total,
                items: normalizedItems,
            },
        });
        const notifications = await this.createOrderNotifications(storeBundle.store, {
            order_id: orderId,
            order_number: orderNumber,
            customer_name: customerName,
            customer_phone: customerPhone,
            payment_method: paymentMethod,
            total,
            items: normalizedItems,
        });
        let order = await (0, database_1.queryOne)(`SELECT * FROM storefront_orders WHERE id = ? LIMIT 1`, [orderId]);
        if (!order)
            throw new Error("Failed to persist order");
        const settings = this.extractStoreSettings({ settings: storeBundle.store.settings });
        const automationActive = !!settings.automation?.order_flow?.active;
        if (automationActive) {
            order = await this.transitionOrderStatus(order, "confirmando_pagamento", {
                eventType: "order.processing_started",
                actorType: "system",
                payload: { reason: "order_flow_active" },
            });
            await this.queueCustomerMessage(order, "order_received", `Pedido recebido com sucesso. Pedido #${order.order_number} no total de ${formatMoneyBr(toNumber(order.total, 0))}. Estamos processando seu pedido.`);
        }
        return {
            order,
            notifications,
            store: {
                id: storeBundle.store.id,
                slug: storeBundle.store.slug,
                name: storeBundle.store.name,
            },
        };
    }
    async exportStoreAdminBundle(userId, storeId, brandId) {
        await this.ensureSchema();
        let store = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (!store)
            return null;
        await this.synchronizeStoreBrandIdentity(store);
        await this.synchronizeStoreProductsFromCatalog(store);
        const refreshedStore = await this.getOwnedStoreRow(userId, storeId, brandId);
        if (refreshedStore) {
            store = refreshedStore;
        }
        const [template, domains, products, pages] = await Promise.all([
            (0, database_1.queryOne)(`SELECT * FROM storefront_templates WHERE template_id = ? LIMIT 1`, [store.template_id]),
            (0, database_1.query)(`SELECT * FROM storefront_domains WHERE store_id = ? ORDER BY is_primary DESC`, [store.id]),
            (0, database_1.query)(`SELECT * FROM storefront_products WHERE store_id = ? ORDER BY position ASC, created_at DESC`, [store.id]),
            (0, database_1.query)(`SELECT * FROM storefront_pages WHERE store_id = ? ORDER BY created_at ASC`, [store.id]),
        ]);
        return {
            store: this.mapStore(store),
            template: template ? this.mapTemplate(template) : null,
            domains,
            products,
            pages,
        };
    }
    async markDomainVerified(storeId, domainInput) {
        await this.ensureSchema();
        const domain = sanitizeDomain(domainInput);
        if (!domain)
            return false;
        const affected = await (0, database_1.update)(`UPDATE storefront_domains SET verification_status = 'verified', updated_at = NOW() WHERE store_id = ? AND domain = ?`, [storeId, domain]);
        return affected > 0;
    }
    async transactionalHealthCheck() {
        await this.ensureSchema();
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query("SELECT 1 AS ok");
        return Array.isArray(rows) && rows.length > 0;
    }
    generateOrderNumber() {
        const now = new Date();
        const y = now.getUTCFullYear().toString().slice(-2);
        const m = String(now.getUTCMonth() + 1).padStart(2, "0");
        const d = String(now.getUTCDate()).padStart(2, "0");
        return `SF${y}${m}${d}${Math.floor(Math.random() * 9000) + 1000}`;
    }
    async createOrderNotifications(store, payload) {
        const settings = this.extractStoreSettings(store);
        const notifications = settings.notifications || {};
        const queue = [];
        if (notifications.admin !== false)
            queue.push({ channel: "admin", target: "panel" });
        const whatsapp = String(notifications.whatsapp || "").trim();
        if (whatsapp)
            queue.push({ channel: "whatsapp", target: whatsapp });
        const email = String(notifications.email || "").trim();
        if (email)
            queue.push({ channel: "email", target: email });
        for (const item of queue) {
            await this.createNotification({
                orderId: payload.order_id,
                storeId: store.id,
                channel: item.channel,
                target: item.target,
                payload,
            });
        }
        const webhookUrl = String(notifications.webhook_url || "").trim();
        if (webhookUrl) {
            logger_1.logger.info({
                module: "storefront",
                event: "order.created",
                store_id: store.id,
                order_id: payload.order_id,
                webhook_url: webhookUrl,
            }, "Storefront webhook pending dispatch");
        }
        return (0, database_1.query)(`SELECT * FROM storefront_order_notifications WHERE order_id = ? ORDER BY created_at ASC`, [payload.order_id]);
    }
    async ensureDefaultPagesForStore(storeId) {
        const defaults = [
            {
                slug: "home",
                title: "Home",
                page_type: "home",
                sections: [
                    {
                        type: "hero",
                        content: {
                            headline: "Sua marca com loja online pronta para vender",
                            subheadline: "Template dinamico, pedidos no site e estrutura preparada para escalar.",
                            cta: "Comprar agora",
                        },
                    },
                    { type: "products_grid", content: { title: "Produtos em destaque" } },
                    { type: "cta", content: { title: "Fale conosco para ofertas personalizadas", action: "Pedir pelo site" } },
                ],
            },
            {
                slug: "sobre",
                title: "Sobre",
                page_type: "about",
                sections: [
                    { type: "story", content: { title: "Nossa historia", body: "Conte aqui a historia da sua marca, missao e valores." } },
                    { type: "values", content: { items: ["Qualidade", "Atendimento", "Entrega"] } },
                ],
            },
            {
                slug: "produtos",
                title: "Produtos",
                page_type: "products",
                sections: [{ type: "catalog", content: { title: "Catalogo", filters: ["categoria", "preco", "novidades"] } }],
            },
        ];
        for (const page of defaults) {
            await (0, database_1.query)(`INSERT IGNORE INTO storefront_pages
         (id, store_id, slug, title, page_type, sections_json, seo_json, is_published, created_by_ai)
         VALUES (?, ?, ?, ?, ?, ?, ?, TRUE, FALSE)`, [(0, crypto_1.randomUUID)(), storeId, page.slug, page.title, page.page_type, JSON.stringify(page.sections), JSON.stringify({ title: page.title })]);
        }
    }
}
exports.StorefrontService = StorefrontService;
//# sourceMappingURL=storefront.js.map