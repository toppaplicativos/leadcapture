export type BusinessStatus = "novo" | "aguardando_pagamento" | "pago" | "em_preparacao" | "em_entrega" | "entregue" | "cancelado";
export type PaymentStatus = "pending" | "paid" | "failed" | "refunded";
export type DeliveryStatus = "nao_iniciado" | "em_preparacao" | "saiu_para_entrega" | "entregue" | "cancelado";
export type TemplateTarget = "expedition" | "seller" | "client";
export type TemplateEvent = "order.created" | "order.paid" | "order.preparing" | "order.shipped" | "order.delivered" | "order.cancelled" | "payment.confirmed" | "payment.failed" | "delivery.assigned" | "delivery.out_for_delivery" | "delivery.completed" | "delivery.failed";
export type NotificationTemplate = {
    id: string;
    user_id: string;
    brand_id: string | null;
    event: TemplateEvent;
    target: TemplateTarget;
    channel: "whatsapp" | "email" | "sms" | "in_app";
    subject: string | null;
    body_template: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
};
export type ResponsibleRole = "seller" | "expedition" | "support" | "manager";
export type OrderResponsible = {
    id: string;
    order_id: string;
    user_id: string;
    brand_id: string | null;
    responsible_user_id: string;
    responsible_name: string;
    role: ResponsibleRole;
    assigned_at: string;
    unassigned_at: string | null;
    is_active: boolean;
};
export declare function renderTemplate(template: string, variables: Record<string, any>): string;
export declare function formatMoney(value: number | string): string;
export declare function formatDate(value: string | Date): string;
export declare class OrderManagementService {
    private schemaReady;
    ensureSchema(): Promise<void>;
    canTransition(from: BusinessStatus, to: BusinessStatus): boolean;
    getAllowedTransitions(current: BusinessStatus): BusinessStatus[];
    getStatusLabel(status: BusinessStatus): string;
    getStatusFlow(): Record<BusinessStatus, {
        label: string;
        next: BusinessStatus[];
    }>;
    listTemplates(userId: string, brandId: string | null): Promise<NotificationTemplate[]>;
    getTemplate(userId: string, templateId: string): Promise<NotificationTemplate | null>;
    upsertTemplate(input: {
        userId: string;
        brandId: string | null;
        event: TemplateEvent;
        target: TemplateTarget;
        channel: string;
        subject?: string | null;
        bodyTemplate: string;
        isActive?: boolean;
    }): Promise<NotificationTemplate>;
    deleteTemplate(userId: string, templateId: string): Promise<boolean>;
    seedDefaultTemplates(userId: string, brandId: string | null): Promise<number>;
    private getDefaultTemplates;
    processOrderEvent(input: {
        userId: string;
        brandId: string | null;
        orderId: string;
        event: TemplateEvent;
        variables: Record<string, any>;
    }): Promise<Array<{
        target: TemplateTarget;
        channel: string;
        rendered: string;
        status: string;
    }>>;
    previewTemplate(bodyTemplate: string, sampleVariables?: Record<string, any>): Promise<string>;
    assignResponsible(input: {
        orderId: string;
        userId: string;
        brandId: string | null;
        responsibleUserId: string;
        responsibleName: string;
        role: ResponsibleRole;
    }): Promise<OrderResponsible>;
    getOrderResponsibles(orderId: string): Promise<OrderResponsible[]>;
    unassignResponsible(orderId: string, userId: string, role: ResponsibleRole): Promise<boolean>;
    detectProblems(userId: string, brandId: string | null): Promise<{
        stale_payments: number;
        stalled_preparation: number;
        late_deliveries: number;
        unassigned_orders: number;
        total_problems: number;
        details: Array<{
            type: string;
            count: number;
            description: string;
        }>;
    }>;
    getAdvancedAnalytics(userId: string, brandId: string | null, period?: {
        start?: string;
        end?: string;
    }): Promise<Record<string, any>>;
    getAutomationLog(userId: string, brandId: string | null, filters?: {
        orderId?: string;
        event?: string;
        target?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        logs: any[];
        total: number;
    }>;
    buildOrderVariables(order: Record<string, any>, extras?: Record<string, any>): Record<string, any>;
}
//# sourceMappingURL=orderManagement.d.ts.map