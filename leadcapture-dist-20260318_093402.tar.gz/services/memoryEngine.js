"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.memoryEngine = exports.MemoryEngineService = void 0;
const database_1 = require("../config/database");
const generative_ai_1 = require("@google/generative-ai");
const config_1 = require("../config");
const logger_1 = require("../utils/logger");
const DEFAULT_MEMORY = {
    profile: {},
    conversation_summary: "",
    intent_stage: "descoberta",
    pain_points: [],
    objections: [],
    preferences: {},
    topics_discussed: [],
    sentiment: "desconhecido",
    last_topic: "",
    last_interaction_at: new Date().toISOString(),
    memory_version: 0,
};
// ─── Service ──────────────────────────────────────────────────────────────────
class MemoryEngineService {
    constructor() {
        // ─── Ensure columns exist ─────────────────────────────────────────────────
        this._columnsChecked = false;
        this.genAI = new generative_ai_1.GoogleGenerativeAI(config_1.config.geminiApiKey);
        const modelName = process.env.GEMINI_MEMORY_MODEL || process.env.GEMINI_TEXT_MODEL || "gemini-2.0-flash";
        this.model = this.genAI.getGenerativeModel({ model: modelName });
    }
    async ensureColumns() {
        if (this._columnsChecked)
            return;
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query("SHOW COLUMNS FROM clients LIKE 'context_memory'");
        const exists = Array.isArray(rows) && rows.length > 0;
        if (!exists) {
            await pool.execute("ALTER TABLE clients ADD COLUMN context_memory JSON NULL, ADD COLUMN memory_updated_at TIMESTAMP NULL, ADD COLUMN memory_version INT NOT NULL DEFAULT 0");
            logger_1.logger.info("[MemoryEngine] Added context_memory, memory_updated_at, memory_version columns to clients");
        }
        this._columnsChecked = true;
    }
    // ─── Get memory ───────────────────────────────────────────────────────────
    async getMemory(clientId) {
        await this.ensureColumns();
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query("SELECT context_memory, memory_version FROM clients WHERE id = ? AND is_active = TRUE LIMIT 1", [clientId]);
        if (!rows[0])
            return null;
        const raw = rows[0].context_memory;
        if (!raw)
            return { ...DEFAULT_MEMORY };
        try {
            const parsed = typeof raw === "string" ? JSON.parse(raw) : raw;
            return { ...DEFAULT_MEMORY, ...parsed };
        }
        catch {
            return { ...DEFAULT_MEMORY };
        }
    }
    async getMemoryByPhone(userId, phone, brandId) {
        await this.ensureColumns();
        const pool = (0, database_1.getPool)();
        const normalized = phone.replace(/\D/g, "");
        const normalizedBrandId = String(brandId || "").trim();
        const [rows] = await pool.query(`SELECT id, context_memory, memory_version FROM clients
       WHERE user_id = ? AND is_active = TRUE
         ${normalizedBrandId ? "AND brand_id = ?" : ""}
         AND (REPLACE(REPLACE(REPLACE(phone, ' ',''), '-',''), '+','') LIKE ? OR REPLACE(REPLACE(REPLACE(phone, ' ',''), '-',''), '+','') LIKE ?)
       LIMIT 1`, normalizedBrandId
            ? [userId, normalizedBrandId, `%${normalized}`, `%${normalized.slice(-10)}`]
            : [userId, `%${normalized}`, `%${normalized.slice(-10)}`]);
        if (!rows[0])
            return null;
        const raw = rows[0].context_memory;
        let memory;
        try {
            memory = raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : { ...DEFAULT_MEMORY };
        }
        catch {
            memory = { ...DEFAULT_MEMORY };
        }
        return { clientId: rows[0].id, memory };
    }
    // ─── Update memory via AI ─────────────────────────────────────────────────
    async updateMemoryFromMessage(userId, phone, newMessage, direction, brandId) {
        try {
            await this.ensureColumns();
            const result = await this.getMemoryByPhone(userId, phone, brandId);
            if (!result)
                return; // Client not found — skip silently
            const { clientId, memory } = result;
            const currentVersion = memory.memory_version || 0;
            const prompt = this.buildUpdatePrompt(memory, newMessage, direction);
            let updatedMemory;
            try {
                const aiResult = await this.model.generateContent(prompt);
                const text = aiResult.response.text().trim();
                // Extract JSON from response (Gemini may wrap it in markdown)
                const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/\{[\s\S]*\}/);
                const jsonStr = jsonMatch ? (jsonMatch[1] || jsonMatch[0]) : text;
                const parsed = JSON.parse(jsonStr);
                updatedMemory = { ...DEFAULT_MEMORY, ...memory, ...parsed };
            }
            catch (aiErr) {
                // If AI fails, at minimum update last_interaction_at
                logger_1.logger.warn(`[MemoryEngine] AI update failed for ${phone}: ${aiErr.message}`);
                updatedMemory = {
                    ...memory,
                    last_topic: direction === "inbound" ? newMessage.slice(0, 120) : memory.last_topic,
                    last_interaction_at: new Date().toISOString(),
                };
            }
            updatedMemory.memory_version = currentVersion + 1;
            updatedMemory.last_interaction_at = new Date().toISOString();
            const pool = (0, database_1.getPool)();
            await pool.execute("UPDATE clients SET context_memory = ?, memory_updated_at = NOW(), memory_version = ? WHERE id = ?", [JSON.stringify(updatedMemory), updatedMemory.memory_version, clientId]);
        }
        catch (err) {
            logger_1.logger.error(`[MemoryEngine] updateMemoryFromMessage error for ${phone}: ${err.message}`);
        }
    }
    // ─── Direct update (from route/manual) ───────────────────────────────────
    async saveMemory(clientId, memory) {
        await this.ensureColumns();
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query("SELECT context_memory, memory_version FROM clients WHERE id = ? LIMIT 1", [clientId]);
        if (!rows[0])
            throw new Error("Client not found");
        const current = (() => {
            try {
                const raw = rows[0].context_memory;
                return raw ? (typeof raw === "string" ? JSON.parse(raw) : raw) : { ...DEFAULT_MEMORY };
            }
            catch {
                return { ...DEFAULT_MEMORY };
            }
        })();
        const merged = {
            ...DEFAULT_MEMORY,
            ...current,
            ...memory,
            memory_version: (current.memory_version || 0) + 1,
            last_interaction_at: new Date().toISOString(),
        };
        await pool.execute("UPDATE clients SET context_memory = ?, memory_updated_at = NOW(), memory_version = ? WHERE id = ?", [JSON.stringify(merged), merged.memory_version, clientId]);
    }
    async resetMemory(clientId) {
        await this.ensureColumns();
        const pool = (0, database_1.getPool)();
        const fresh = { ...DEFAULT_MEMORY, last_interaction_at: new Date().toISOString() };
        await pool.execute("UPDATE clients SET context_memory = ?, memory_updated_at = NOW(), memory_version = 0 WHERE id = ?", [JSON.stringify(fresh), clientId]);
    }
    // ─── Build prompt context string (for injection into AI prompts) ──────────
    buildPromptContext(memory) {
        if (!memory || !memory.conversation_summary)
            return "";
        const lines = ["=== CONTEXTO DO LEAD (Memória Persistente) ==="];
        if (memory.profile?.nome)
            lines.push(`Nome: ${memory.profile.nome}`);
        if (memory.profile?.empresa)
            lines.push(`Empresa: ${memory.profile.empresa}`);
        if (memory.profile?.segmento)
            lines.push(`Segmento: ${memory.profile.segmento}`);
        if (memory.profile?.cidade)
            lines.push(`Cidade: ${memory.profile.cidade}`);
        if (memory.conversation_summary) {
            lines.push(`\nResumo da conversa: ${memory.conversation_summary}`);
        }
        if (memory.intent_stage) {
            const stageLabels = {
                descoberta: "Descoberta",
                interesse: "Interesse",
                consideracao: "Consideração",
                decisao: "Decisão",
                pos_venda: "Pós-venda",
                inativo: "Inativo",
            };
            lines.push(`Estágio: ${stageLabels[memory.intent_stage] || memory.intent_stage}`);
        }
        if (memory.pain_points?.length) {
            lines.push(`Dores identificadas: ${memory.pain_points.join(", ")}`);
        }
        if (memory.objections?.length) {
            lines.push(`Objeções: ${memory.objections.join(", ")}`);
        }
        if (memory.last_topic) {
            lines.push(`Último assunto: ${memory.last_topic}`);
        }
        if (memory.sentiment && memory.sentiment !== "desconhecido") {
            lines.push(`Sentimento atual: ${memory.sentiment}`);
        }
        if (memory.preferences && Object.keys(memory.preferences).length > 0) {
            const prefs = Object.entries(memory.preferences).map(([k, v]) => `${k}: ${v}`).join(", ");
            lines.push(`Preferências: ${prefs}`);
        }
        lines.push("=============================================");
        return lines.join("\n");
    }
    // ─── Internal: build AI prompt for memory update ──────────────────────────
    buildUpdatePrompt(current, newMessage, direction) {
        const currentJson = JSON.stringify(current, null, 2);
        const dirLabel = direction === "inbound" ? "Lead disse" : "Sistema/vendedor disse";
        return `Você é um motor de memória contextual de CRM inteligente.

Sua tarefa: atualizar o contexto do lead com base na nova mensagem recebida.

REGRAS:
- Preserve todas as informações já presentes no contexto atual
- Apenas refine ou adicione informações com base na nova mensagem
- Não apague dados anteriores a menos que sejam contraditos
- Mantenha os campos existentes mesmo que não sejam mencionados na nova mensagem
- Retorne APENAS um JSON válido, sem markdown, sem explicações
- O JSON deve ter exatamente esta estrutura:
{
  "profile": { "nome": "", "cidade": "", "segmento": "", "empresa": "" },
  "conversation_summary": "resumo cumulativo em 2-3 frases",
  "intent_stage": "descoberta|interesse|consideracao|decisao|pos_venda|inativo",
  "pain_points": ["..."],
  "objections": ["..."],
  "preferences": { "chave": "valor" },
  "topics_discussed": ["..."],
  "sentiment": "positivo|neutro|negativo|desconhecido",
  "last_topic": "último assunto discutido"
}

CONTEXTO ATUAL DO LEAD:
${currentJson}

NOVA MENSAGEM (${dirLabel}):
"${newMessage}"

Retorne o JSON atualizado:`;
    }
}
exports.MemoryEngineService = MemoryEngineService;
// Singleton
exports.memoryEngine = new MemoryEngineService();
//# sourceMappingURL=memoryEngine.js.map