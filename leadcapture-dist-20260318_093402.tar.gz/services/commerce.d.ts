export type CommerceProductType = "fisico" | "digital" | "servico";
export type CommerceOrderStatus = "criado" | "aguardando_pagamento" | "pago" | "cancelado" | "estornado" | "abandonado";
export type CommerceOrderOrigin = "whatsapp" | "checkout_web";
export type CommercePaymentMethod = "pix" | "cartao" | "boleto" | "desconhecido";
export type CommerceProduct = {
    id: string;
    user_id: string;
    brand_id?: string | null;
    nome: string;
    descricao?: string | null;
    tipo: CommerceProductType;
    preco: number;
    preco_promocional?: number | null;
    parcelamento: number;
    estoque?: number | null;
    tempo_entrega?: string | null;
    garantia?: string | null;
    imagem?: string | null;
    ativo: boolean;
    created_at: string;
    updated_at: string;
};
export type CommerceOrder = {
    id: string;
    user_id: string;
    brand_id?: string | null;
    lead_id?: string | null;
    instance_id?: string | null;
    valor_total: number;
    subtotal: number;
    desconto: number;
    cupom_codigo?: string | null;
    forma_pagamento: CommercePaymentMethod;
    status_pedido: CommerceOrderStatus;
    origem: CommerceOrderOrigin;
    customer_name?: string | null;
    customer_email?: string | null;
    customer_phone?: string | null;
    checkout_token: string;
    checkout_expires_at?: string | null;
    payment_link?: string | null;
    data_criacao: string;
    data_pagamento?: string | null;
    created_at: string;
    updated_at: string;
};
export type CommerceOrderItem = {
    id: number;
    order_id: string;
    product_id?: string | null;
    nome: string;
    quantidade: number;
    valor_unitario: number;
    valor_total: number;
    metadata_json?: string | null;
};
export declare class CommerceService {
    private schemaReady;
    private schemaReadyPromise;
    private customersColumnsCache;
    private normalizeBrandId;
    private normalizePaymentMethod;
    private normalizeOrderStatus;
    private parseNumber;
    private makeCheckoutToken;
    private getCustomersColumns;
    private resolveOwnerColumn;
    private parseTags;
    private updateLeadLifecycle;
    private appendOrderEvent;
    ensureSchema(): Promise<void>;
    private buildBrandWhereClause;
    listProducts(userId: string, brandId?: string | null): Promise<CommerceProduct[]>;
    getProductById(userId: string, brandId: string | null, productId: string): Promise<CommerceProduct | null>;
    private getCatalogProductById;
    createProduct(userId: string, brandId: string | null, payload: Partial<{
        nome: string;
        descricao: string;
        tipo: CommerceProductType;
        preco: number;
        preco_promocional: number | null;
        parcelamento: number;
        estoque: number | null;
        tempo_entrega: string;
        garantia: string;
        imagem: string;
        ativo: boolean;
    }>): Promise<CommerceProduct>;
    updateProduct(userId: string, brandId: string | null, productId: string, payload: Partial<{
        nome: string;
        descricao: string;
        tipo: CommerceProductType;
        preco: number;
        preco_promocional: number | null;
        parcelamento: number;
        estoque: number | null;
        tempo_entrega: string;
        garantia: string;
        imagem: string;
        ativo: boolean;
    }>): Promise<CommerceProduct | null>;
    listOrders(userId: string, brandId: string | null, filters?: {
        status?: string;
        lead_id?: string;
        limit?: number;
        offset?: number;
    }): Promise<CommerceOrder[]>;
    getOrderById(userId: string, brandId: string | null, orderId: string): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
    } | null>;
    createOrder(userId: string, brandId: string | null, input: {
        lead_id?: string | null;
        instance_id?: string | null;
        origem?: CommerceOrderOrigin;
        forma_pagamento?: CommercePaymentMethod | string;
        customer_name?: string;
        customer_email?: string;
        customer_phone?: string;
        cupom_codigo?: string;
        desconto?: number;
        checkout_base_url: string;
        itens: Array<{
            product_id?: string;
            nome?: string;
            quantidade?: number;
            valor_unitario?: number;
            imagem?: string | null;
            imagens?: string[];
            descricao?: string | null;
            categoria?: string | null;
        }>;
    }): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
        checkout_url: string;
    }>;
    updateOrderStatus(userId: string, brandId: string | null, orderId: string, input: {
        status_pedido: CommerceOrderStatus | string;
        forma_pagamento?: CommercePaymentMethod | string;
        data_pagamento?: string | null;
    }): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
    } | null>;
    getCheckoutByToken(checkoutToken: string): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
        expired: boolean;
    } | null>;
    rebuildCheckoutFromToken(checkoutToken: string, input: {
        checkout_base_url: string;
        forma_pagamento?: CommercePaymentMethod | string;
        customer_name?: string;
        customer_email?: string;
        customer_phone?: string;
        itens?: Array<{
            product_id?: string;
            nome?: string;
            quantidade?: number;
            valor_unitario?: number;
        }>;
    }): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
        checkout_url: string;
    }>;
    completeCheckout(checkoutToken: string, input: {
        forma_pagamento?: CommercePaymentMethod | string;
        customer_name?: string;
        customer_email?: string;
        customer_phone?: string;
    }): Promise<{
        order: CommerceOrder;
        items: CommerceOrderItem[];
    }>;
    markAbandonedPendingOrders(minutesWithoutPayment?: number): Promise<{
        updated: number;
    }>;
}
//# sourceMappingURL=commerce.d.ts.map