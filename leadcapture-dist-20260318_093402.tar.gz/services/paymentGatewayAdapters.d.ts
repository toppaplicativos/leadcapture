export type GatewayEnvironment = "sandbox" | "production";
export type GatewayCreatePaymentInput = {
    amount: number;
    currency: string;
    method: string;
    installments: number;
    description: string;
    customer: {
        name?: string | null;
        email?: string | null;
        phone?: string | null;
    };
    metadata?: Record<string, any>;
};
export type GatewayCreatePaymentOutput = {
    provider_payment_id: string;
    payment_url: string;
    status: "pending" | "paid" | "failed";
    raw_response: Record<string, any>;
};
export type GatewayWebhookEvent = {
    provider_payment_id?: string;
    status?: "pending" | "paid" | "failed" | "canceled";
    raw?: Record<string, any>;
};
export type GatewayCredentials = {
    publicKey?: string | null;
    secretKey?: string | null;
    webhookSecret?: string | null;
};
export interface PaymentGatewayAdapter {
    createPayment(input: GatewayCreatePaymentInput): Promise<GatewayCreatePaymentOutput>;
    createSubscription?(input: Record<string, any>): Promise<Record<string, any>>;
    refund?(input: {
        providerPaymentId: string;
        amount?: number;
    }): Promise<Record<string, any>>;
    testConnection?(): Promise<{
        ok: boolean;
        reason?: string;
        details?: Record<string, any>;
    }>;
    resolveWebhookEvent?(args: {
        payload: string;
        body?: Record<string, any>;
        headers?: Record<string, any>;
    }): Promise<GatewayWebhookEvent | null>;
    validateWebhook(args: {
        payload: string;
        signature?: string;
        headers?: Record<string, any>;
        webhookSecret?: string;
    }): boolean;
}
export declare function getGatewayAdapter(gatewayName: string, environment: GatewayEnvironment, credentials?: GatewayCredentials): PaymentGatewayAdapter;
//# sourceMappingURL=paymentGatewayAdapters.d.ts.map