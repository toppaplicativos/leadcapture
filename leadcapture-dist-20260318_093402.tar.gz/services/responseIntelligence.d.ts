export type SentimentColor = "green" | "yellow" | "red" | "black";
export type ResponseClassification = {
    sentiment: SentimentColor;
    intent: "interested" | "neutral" | "negative" | "opt_out" | "viewed_no_reply";
    confidence: number;
    scoreDelta: number;
    tagsToAdd: string[];
    tagsToRemove: string[];
    suggestedStatus: string | null;
    suggestedAction: string;
    autoFlowTrigger: string | null;
};
export type ResponseIntelligenceResult = {
    classification: ResponseClassification;
    leadId: string;
    phone: string;
    applied: boolean;
};
export declare class ResponseIntelligenceService {
    private gemini;
    private getGemini;
    classifyText(text: string): ResponseClassification;
    classifyWithAI(text: string, contextBlock?: string): Promise<ResponseClassification>;
    private enrichClassification;
    classifyViewedNoReply(): ResponseClassification;
    applyToLead(userId: string, leadId: string, classification: ResponseClassification): Promise<void>;
    getHighScoreLeads(userId: string, threshold?: number, brandId?: string | null): Promise<Array<{
        id: string;
        name: string;
        phone: string;
        score: number;
        tags: string[];
    }>>;
    private customerColumnsCache;
    private getCustomerColumns;
    private parseJsonArray;
}
//# sourceMappingURL=responseIntelligence.d.ts.map