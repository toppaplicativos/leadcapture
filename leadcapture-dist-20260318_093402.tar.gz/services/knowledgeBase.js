"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeBaseService = void 0;
const crypto_1 = require("crypto");
const database_1 = require("../config/database");
const logger_1 = require("../utils/logger");
class KnowledgeBaseService {
    constructor() {
        this.columnsCache = null;
        this.tableColumnsCache = new Map();
    }
    async getColumns() {
        if (this.columnsCache)
            return this.columnsCache;
        const rows = await (0, database_1.query)("SHOW COLUMNS FROM knowledge_base");
        const map = new Map();
        for (const row of rows) {
            map.set(String(row.Field), {
                field: String(row.Field),
                type: String(row.Type || ""),
                nullable: String(row.Null || "").toUpperCase() === "YES",
                defaultValue: row.Default,
                extra: String(row.Extra || ""),
            });
        }
        this.columnsCache = map;
        return map;
    }
    hasColumn(columns, name) {
        return columns.has(name);
    }
    isNumericType(meta) {
        if (!meta)
            return false;
        const t = String(meta.type || "").toLowerCase();
        return /\b(bigint|integer|int|smallint|serial|bigserial)\b/.test(t);
    }
    async tableExists(tableName) {
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`, [tableName]);
        return Number(row?.total || 0) > 0;
    }
    async getTableColumns(tableName) {
        const cached = this.tableColumnsCache.get(tableName);
        if (cached)
            return cached;
        try {
            const rows = await (0, database_1.query)(`SHOW COLUMNS FROM ${tableName}`);
            const map = new Map();
            for (const row of rows) {
                map.set(String(row.Field), {
                    field: String(row.Field),
                    type: String(row.Type || ""),
                    nullable: String(row.Null || "").toUpperCase() === "YES",
                    defaultValue: row.Default,
                    extra: String(row.Extra || ""),
                });
            }
            this.tableColumnsCache.set(tableName, map);
            return map;
        }
        catch {
            const empty = new Map();
            this.tableColumnsCache.set(tableName, empty);
            return empty;
        }
    }
    resolveCompaniesOwnerColumn(columns) {
        if (this.hasColumn(columns, "owner_user_id"))
            return "owner_user_id";
        if (this.hasColumn(columns, "user_id"))
            return "user_id";
        if (this.hasColumn(columns, "created_by"))
            return "created_by";
        return null;
    }
    async findOrCreateCompanyId(tableName, userId) {
        const columns = await this.getTableColumns(tableName);
        if (columns.size === 0 || !this.hasColumn(columns, "id"))
            return null;
        const ownerCol = this.resolveCompaniesOwnerColumn(columns);
        const existing = ownerCol
            ? await (0, database_1.queryOne)(`SELECT id FROM ${tableName} WHERE ${ownerCol} = ? ORDER BY created_at ASC LIMIT 1`, [userId])
            : await (0, database_1.queryOne)(`SELECT id FROM ${tableName} ORDER BY created_at ASC LIMIT 1`);
        if (existing?.id)
            return String(existing.id);
        const idMeta = columns.get("id");
        const needsManualId = !!idMeta &&
            !this.isNumericType(idMeta) &&
            !String(idMeta.extra || "").toLowerCase().includes("auto_increment") &&
            (idMeta.defaultValue === null || idMeta.defaultValue === undefined);
        const values = [];
        if (needsManualId)
            values.push(["id", (0, crypto_1.randomUUID)()]);
        if (ownerCol)
            values.push([ownerCol, userId]);
        if (this.hasColumn(columns, "name"))
            values.push(["name", "Empresa Principal"]);
        if (this.hasColumn(columns, "is_active"))
            values.push(["is_active", true]);
        if (this.hasColumn(columns, "active"))
            values.push(["active", true]);
        const nonNullNoDefault = Array.from(columns.values())
            .filter((col) => !col.nullable &&
            col.defaultValue == null &&
            !String(col.extra || "").toLowerCase().includes("auto_increment") &&
            !(col.field === "id" && this.isNumericType(col)))
            .map((col) => col.field);
        const provided = new Set(values.map(([field]) => field));
        const missingRequired = nonNullNoDefault.filter((field) => !provided.has(field));
        if (missingRequired.length > 0) {
            return null;
        }
        if (values.length === 0)
            return null;
        const cols = values.map(([field]) => field).join(", ");
        const placeholders = values.map(() => "?").join(", ");
        const params = values.map(([, value]) => value);
        await (0, database_1.query)(`INSERT INTO ${tableName} (${cols}) VALUES (${placeholders})`, params);
        if (provided.has("id")) {
            const idValue = values.find(([field]) => field === "id")?.[1];
            if (idValue)
                return String(idValue);
        }
        const created = ownerCol
            ? await (0, database_1.queryOne)(`SELECT id FROM ${tableName} WHERE ${ownerCol} = ? ORDER BY created_at DESC LIMIT 1`, [userId])
            : await (0, database_1.queryOne)(`SELECT id FROM ${tableName} ORDER BY created_at DESC LIMIT 1`);
        return created?.id ? String(created.id) : null;
    }
    async resolveCompanyIdForInsert(userId, requestedCompanyId) {
        const normalizedRequested = String(requestedCompanyId || "").trim();
        if (normalizedRequested) {
            const exists = await (0, database_1.queryOne)("SELECT id FROM companies WHERE id = ?", [normalizedRequested]);
            if (exists)
                return normalizedRequested;
        }
        const knowledgeColumns = await this.getColumns();
        const companyMeta = knowledgeColumns.get("company_id");
        if (!companyMeta)
            return null;
        const requiresCompany = !companyMeta.nullable && companyMeta.defaultValue == null;
        if (!requiresCompany)
            return null;
        const candidates = ["company", "companies"];
        for (const tableName of candidates) {
            if (!(await this.tableExists(tableName)))
                continue;
            const id = await this.findOrCreateCompanyId(tableName, userId);
            if (id)
                return id;
        }
        throw new Error("company_id is required for knowledge base entries");
    }
    resolveOwnerColumn(columns) {
        if (this.hasColumn(columns, "user_id"))
            return "user_id";
        if (this.hasColumn(columns, "created_by"))
            return "created_by";
        return null;
    }
    resolveActiveColumn(columns) {
        if (this.hasColumn(columns, "active"))
            return "active";
        if (this.hasColumn(columns, "is_active"))
            return "is_active";
        return null;
    }
    parseEnumValues(columnMeta) {
        if (!columnMeta)
            return [];
        const type = String(columnMeta.type || "").trim();
        const enumMatch = type.match(/^enum\((.*)\)$/i);
        if (!enumMatch)
            return [];
        const payload = enumMatch[1] || "";
        const values = payload
            .split(",")
            .map((item) => item.trim().replace(/^'/, "").replace(/'$/, "").replace(/\\'/g, "'"))
            .filter(Boolean);
        return values;
    }
    normalizeCategory(columns, category) {
        if (!this.hasColumn(columns, "category"))
            return null;
        const normalized = String(category || "").trim();
        const enumValues = this.parseEnumValues(columns.get("category"));
        if (!enumValues.length) {
            return normalized || null;
        }
        if (normalized && enumValues.includes(normalized))
            return normalized;
        if (enumValues.includes("custom"))
            return "custom";
        return enumValues[0] || null;
    }
    normalizeTags(columns, tags) {
        if (!this.hasColumn(columns, "tags"))
            return undefined;
        if (tags === undefined)
            return undefined;
        const meta = columns.get("tags");
        const isJson = String(meta?.type || "").toLowerCase().includes("json");
        if (!isJson)
            return tags || null;
        const raw = String(tags || "").trim();
        if (!raw)
            return JSON.stringify([]);
        try {
            const parsed = JSON.parse(raw);
            return JSON.stringify(Array.isArray(parsed) ? parsed : [parsed]);
        }
        catch {
            const parts = raw
                .split(",")
                .map((item) => item.trim())
                .filter(Boolean);
            return JSON.stringify(parts.length ? parts : [raw]);
        }
    }
    async create(userId, dto) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        if (!ownerColumn) {
            throw new Error("knowledge_base owner column not found");
        }
        const activeColumn = this.resolveActiveColumn(columns);
        const entries = [];
        const idMeta = columns.get("id");
        const needsManualId = !!idMeta &&
            !this.isNumericType(idMeta) &&
            !String(idMeta.extra || "").toLowerCase().includes("auto_increment") &&
            (idMeta.defaultValue === null || idMeta.defaultValue === undefined);
        if (needsManualId && this.hasColumn(columns, "id")) {
            entries.push(["id", (0, crypto_1.randomUUID)()]);
        }
        entries.push([ownerColumn, userId]);
        if (this.hasColumn(columns, "company_id")) {
            const companyId = await this.resolveCompanyIdForInsert(userId, dto.company_id);
            if (companyId !== null && companyId !== undefined && String(companyId).trim()) {
                entries.push(["company_id", companyId]);
            }
        }
        if (this.hasColumn(columns, "title"))
            entries.push(["title", dto.title]);
        if (this.hasColumn(columns, "content"))
            entries.push(["content", dto.content]);
        if (this.hasColumn(columns, "category")) {
            entries.push(["category", this.normalizeCategory(columns, dto.category)]);
        }
        const normalizedTags = this.normalizeTags(columns, dto.tags);
        if (normalizedTags !== undefined)
            entries.push(["tags", normalizedTags]);
        if (activeColumn)
            entries.push([activeColumn, dto.active !== false]);
        const sqlColumns = entries.map(([name]) => name).join(", ");
        const placeholders = entries.map(() => "?").join(", ");
        const values = entries.map(([, value]) => value);
        await (0, database_1.query)(`INSERT INTO knowledge_base (${sqlColumns}) VALUES (${placeholders})`, values);
        const insertedId = entries.find(([name]) => name === "id")?.[1];
        logger_1.logger.info(`Knowledge base entry created: ${dto.title}${insertedId ? ` (ID: ${insertedId})` : ""}`);
        if (insertedId !== undefined) {
            const inserted = await this.getById(insertedId, userId);
            if (inserted)
                return inserted;
        }
        const latest = await this.getAll({ user_id: userId, search: dto.title, active: dto.active !== false });
        if (latest[0])
            return latest[0];
        throw new Error("Failed to create knowledge base entry");
    }
    async getById(id, userId) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        if (!ownerColumn)
            return null;
        return (0, database_1.queryOne)(`SELECT * FROM knowledge_base WHERE id = ? AND ${ownerColumn} = ?`, [id, userId]);
    }
    async getAll(filters) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        const activeColumn = this.resolveActiveColumn(columns);
        let where = "WHERE 1=1";
        const params = [];
        if (filters?.user_id && ownerColumn) {
            where += ` AND ${ownerColumn} = ?`;
            params.push(filters.user_id);
        }
        if (filters?.category && this.hasColumn(columns, "category")) {
            where += " AND category = ?";
            params.push(this.normalizeCategory(columns, filters.category));
        }
        if (filters?.active !== undefined && activeColumn) {
            where += ` AND ${activeColumn} = ?`;
            params.push(filters.active ? 1 : 0);
        }
        if (filters?.company_id && this.hasColumn(columns, "company_id")) {
            where += " AND company_id = ?";
            params.push(filters.company_id);
        }
        if (filters?.search) {
            where += " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)";
            const s = `%${filters.search}%`;
            params.push(s, s, s);
        }
        return (0, database_1.query)(`SELECT * FROM knowledge_base ${where} ORDER BY created_at DESC`, params);
    }
    async update(id, userId, data) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        if (!ownerColumn)
            return null;
        const fields = [];
        const values = [];
        if (data.title !== undefined && this.hasColumn(columns, "title")) {
            fields.push("title = ?");
            values.push(data.title);
        }
        if (data.content !== undefined && this.hasColumn(columns, "content")) {
            fields.push("content = ?");
            values.push(data.content);
        }
        if (data.category !== undefined && this.hasColumn(columns, "category")) {
            fields.push("category = ?");
            values.push(this.normalizeCategory(columns, data.category));
        }
        if (data.tags !== undefined && this.hasColumn(columns, "tags")) {
            fields.push("tags = ?");
            values.push(this.normalizeTags(columns, data.tags));
        }
        const activeColumn = this.resolveActiveColumn(columns);
        if (data.active !== undefined && activeColumn) {
            fields.push(`${activeColumn} = ?`);
            values.push(data.active ? true : false);
        }
        if (fields.length === 0)
            return this.getById(id, userId);
        values.push(id, userId);
        await (0, database_1.update)(`UPDATE knowledge_base SET ${fields.join(", ")} WHERE id = ? AND ${ownerColumn} = ?`, values);
        logger_1.logger.info(`Knowledge base updated: ID ${id}`);
        return this.getById(id, userId);
    }
    async delete(id, userId) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        if (!ownerColumn)
            return false;
        const affected = await (0, database_1.update)(`DELETE FROM knowledge_base WHERE id = ? AND ${ownerColumn} = ?`, [id, userId]);
        return affected > 0;
    }
    // Search knowledge base for AI context (used by Gemini for message generation)
    async searchForContext(searchQuery, userId, companyId) {
        const columns = await this.getColumns();
        const ownerColumn = this.resolveOwnerColumn(columns);
        const activeColumn = this.resolveActiveColumn(columns);
        let where = "WHERE active = true";
        const params = [];
        if (activeColumn) {
            where = `WHERE ${activeColumn} = ?`;
            params.push(1);
        }
        else {
            where = "WHERE 1=1";
        }
        if (ownerColumn) {
            where += ` AND ${ownerColumn} = ?`;
            params.push(userId);
        }
        if (companyId && this.hasColumn(columns, "company_id")) {
            where += " AND company_id = ?";
            params.push(companyId);
        }
        where += " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)";
        const s = `%${searchQuery}%`;
        params.push(s, s, s);
        const entries = await (0, database_1.query)(`SELECT title, content FROM knowledge_base ${where} LIMIT 5`, params);
        if (entries.length === 0)
            return "";
        return entries.map(e => `## ${e.title}\n${e.content}`).join("\n\n---\n\n");
    }
}
exports.KnowledgeBaseService = KnowledgeBaseService;
//# sourceMappingURL=knowledgeBase.js.map