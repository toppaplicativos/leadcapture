/**
 * SOCKET MANAGER - Gerenciamento de WebSocket com Socket.io
 *
 * Este arquivo contém toda a lógica para:
 * - Inicializar servidor Socket.io
 * - Gerenciar conexões de clientes
 * - Emitir eventos em tempo real
 * - Notificações de novas mensagens
 * - Atualização de status de instâncias
 * - Indicador de digitação
 */
import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
interface NotificationRealtimePayload {
    id: string;
    type: string;
    event: string;
    title: string;
    message: string;
    priority: string;
    read: boolean;
    created_at: string;
    metadata?: Record<string, any>;
}
declare class SocketManager {
    private io;
    private userSockets;
    /**
     * Inicializa o servidor Socket.io
     * @param httpServer - Servidor HTTP Express
     */
    initialize(httpServer: HTTPServer): SocketIOServer;
    /**
     * Manipula conexão de usuário
     * @param socket - Socket do cliente
     * @param data - Dados do usuário
     */
    private handleUserConnect;
    /**
     * Manipula desconexão de usuário
     * @param socket - Socket do cliente
     */
    private handleUserDisconnect;
    /**
     * Manipula entrada em conversa
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    private handleConversationJoin;
    /**
     * Manipula saída de conversa
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    private handleConversationLeave;
    /**
     * Manipula início de digitação
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    private handleTypingStart;
    /**
     * Manipula parada de digitação
     * @param socket - Socket do cliente
     * @param data - ID da conversa
     */
    private handleTypingStop;
    /**
     * Emite nova mensagem para todos na conversa
     * @param conversationId - ID da conversa
     * @param message - Dados da mensagem
     */
    emitNewMessage(conversationId: string, message: any): void;
    /**
     * Emite atualização de conversa
     * @param conversationId - ID da conversa
     * @param conversation - Dados da conversa
     */
    emitConversationUpdate(conversationId: string, conversation: any): void;
    /**
     * Emite notificação de nova conversa para usuário
     * @param userId - ID do usuário
     * @param conversation - Dados da conversa
     */
    emitNewConversation(userId: string, conversation: any): void;
    /**
     * Emite atualização de status de instância
     * @param userId - ID do usuário
     * @param instanceId - ID da instância
     * @param status - Novo status
     */
    emitInstanceStatusUpdate(userId: string, instanceId: string, status: string): void;
    /**
     * Emite QR Code para usuário
     * @param userId - ID do usuário
     * @param instanceId - ID da instância
     * @param qrCode - Dados do QR Code
     */
    emitQRCode(userId: string, instanceId: string, qrCode: string): void;
    /**
     * Emite erro para usuário
     * @param userId - ID do usuário
     * @param error - Mensagem de erro
     */
    emitError(userId: string, error: string): void;
    /**
     * Emite notificação em tempo real para o usuário
     */
    emitNotification(userId: string, notification: NotificationRealtimePayload): void;
    /**
     * Emite atualização do badge de notificações
     */
    emitNotificationBadge(userId: string, unreadCount: number): void;
    /**
     * Emite atualização de notificação (read/unread)
     */
    emitNotificationUpdated(userId: string, notificationId: string, patch: Record<string, any>): void;
    /**
     * Broadcast genérico para uma sala de usuário
     */
    emitToUser(userId: string, event: string, payload: Record<string, any>): void;
    /**
     * Obtém número de usuários conectados
     */
    getConnectedUsersCount(): number;
    /**
     * Obtém número de sockets conectados
     */
    getConnectedSocketsCount(): number;
    /**
     * Obtém instância do Socket.io
     */
    getIO(): SocketIOServer | null;
}
export declare const socketManager: SocketManager;
export {};
//# sourceMappingURL=socketManager.d.ts.map