"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignEngineService = void 0;
const crypto_1 = require("crypto");
const database_1 = require("../config/database");
const contextEngine_1 = require("./contextEngine");
const gemini_1 = require("./gemini");
const logger_1 = require("../utils/logger");
// ─── Default speed settings ──────────────────────────────────────
const DEFAULT_SPEED = {
    maxPerMinute: 3,
    minIntervalSeconds: 10,
    maxIntervalSeconds: 30,
    dailyLimit: 200,
    autoPauseOnBlockRate: 15,
};
// ─── Helpers ──────────────────────────────────────────────────────
function normalizePhone(value) {
    return String(value || "").replace(/\D/g, "");
}
function isTransientInstanceConnectionError(error) {
    const message = String(error?.message || error || "").toLowerCase();
    if (!message)
        return false;
    return (message.includes("instance not connected") ||
        message.includes("instance not found") ||
        message.includes("not initialized") ||
        message.includes("offline") ||
        message.includes("socket closed"));
}
function parseJsonSafe(value) {
    if (!value)
        return {};
    if (typeof value === "object")
        return value;
    if (typeof value !== "string")
        return {};
    try {
        return JSON.parse(value);
    }
    catch {
        return {};
    }
}
function parseJsonArray(value) {
    if (!value)
        return [];
    if (Array.isArray(value))
        return value.map(i => String(i).trim()).filter(Boolean);
    if (typeof value !== "string")
        return [];
    try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed))
            return parsed.map(i => String(i).trim()).filter(Boolean);
    }
    catch { /* ignore */ }
    return [];
}
function isTruthyFlag(value) {
    if (typeof value === "boolean")
        return value;
    if (typeof value === "number")
        return value !== 0;
    const normalized = String(value || "").trim().toLowerCase();
    return normalized === "1" || normalized === "true" || normalized === "t" || normalized === "yes";
}
function toNullableBoolean(value) {
    if (value === null || value === undefined || String(value).trim() === "")
        return null;
    return isTruthyFlag(value);
}
function randomDelay(min, max) {
    return Math.floor(min * 1000 + Math.random() * (max - min) * 1000);
}
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
function getCurrentMinutesForTimeZone(now, timeZone) {
    if (!timeZone) {
        return now.getHours() * 60 + now.getMinutes();
    }
    try {
        const parts = new Intl.DateTimeFormat("en-US", {
            hour12: false,
            hour: "2-digit",
            minute: "2-digit",
            timeZone,
        }).formatToParts(now);
        const hour = Number(parts.find((part) => part.type === "hour")?.value || 0);
        const minute = Number(parts.find((part) => part.type === "minute")?.value || 0);
        return Math.max(0, Math.min(1439, hour * 60 + minute));
    }
    catch {
        return now.getHours() * 60 + now.getMinutes();
    }
}
function withTimeout(promise, timeoutMs, timeoutMessage) {
    let timer = null;
    const timeoutPromise = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(timeoutMessage)), timeoutMs);
    });
    return Promise.race([promise, timeoutPromise]).finally(() => {
        if (timer)
            clearTimeout(timer);
    });
}
function parseTagList(value) {
    if (Array.isArray(value)) {
        return value.map((item) => String(item || "").trim()).filter(Boolean);
    }
    const raw = String(value || "").trim();
    if (!raw)
        return [];
    return raw
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
}
function normalizeDestinationType(value) {
    const raw = String(value || "").trim().toLowerCase();
    if (raw === "group" || raw === "group_sequence")
        return raw;
    return "lead_list";
}
function normalizeDestinationTargetType(value) {
    const raw = String(value || "").trim().toLowerCase();
    if (raw === "channel")
        return "channel";
    if (raw === "contact")
        return "contact";
    return "group";
}
function normalizeJid(value) {
    const raw = String(value || "").trim();
    if (!raw)
        return "";
    if (raw.includes("@"))
        return raw;
    const digits = raw.replace(/\D/g, "");
    if (!digits)
        return "";
    return `${digits}@s.whatsapp.net`;
}
function normalizeLeadStatusValue(value) {
    const raw = String(value || "").trim().toLowerCase();
    if (!raw)
        return "";
    const compact = raw
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[\s-]+/g, "_");
    const aliases = {
        novo: "new",
        new_lead: "new",
        contatado: "contacted",
        respondeu: "replied",
        negociando: "negotiating",
        convertido: "converted",
        perdido: "lost",
        inativo: "inactive",
    };
    return aliases[compact] || compact;
}
function normalizeStatusFilterInput(statuses) {
    if (!Array.isArray(statuses))
        return [];
    const normalized = statuses
        .map((item) => normalizeLeadStatusValue(item))
        .filter(Boolean);
    return [...new Set(normalized)];
}
function normalizeCampaignFilterInput(filter) {
    const source = filter || {};
    const normalizedStatuses = normalizeStatusFilterInput(source.statuses);
    return {
        ...source,
        statuses: normalizedStatuses.length ? normalizedStatuses : ["new"],
    };
}
const STATUS_VARIANTS_MAP = {
    new: ["new", "novo", "new lead", "lead novo", "novo lead"],
    contacted: ["contacted", "contatado", "contatados", "contato iniciado", "em contato"],
    replied: ["replied", "respondeu", "respondido", "engajado"],
    negotiating: ["negotiating", "negociando", "em negociacao", "em negociação"],
    converted: ["converted", "convertido", "cliente", "won", "fechado"],
    lost: ["lost", "perdido", "descartado", "nao interessado", "não interessado"],
    inactive: ["inactive", "inativo"],
};
function expandStatusFilterVariants(statuses) {
    const result = new Set();
    for (const status of statuses) {
        const canonical = normalizeLeadStatusValue(status);
        const variants = STATUS_VARIANTS_MAP[canonical] || [canonical || String(status || "").trim().toLowerCase()];
        for (const variant of variants) {
            const normalized = String(variant || "").trim().toLowerCase();
            if (normalized)
                result.add(normalized);
        }
    }
    return [...result];
}
function isInDailyWindow(now, start, end, timeZone) {
    const [startH, startM] = String(start || "").split(":").map((v) => Number(v || 0));
    const [endH, endM] = String(end || "").split(":").map((v) => Number(v || 0));
    const nowMinutes = getCurrentMinutesForTimeZone(now, timeZone);
    const startMinutes = Math.max(0, Math.min(1439, startH * 60 + startM));
    const endMinutes = Math.max(0, Math.min(1439, endH * 60 + endM));
    if (startMinutes === endMinutes)
        return true;
    if (startMinutes < endMinutes) {
        return nowMinutes >= startMinutes && nowMinutes <= endMinutes;
    }
    return nowMinutes >= startMinutes || nowMinutes <= endMinutes;
}
// ─── Service ──────────────────────────────────────────────────────
class CampaignEngineService {
    async columnExists(tableName, columnName) {
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`, [tableName, columnName]);
        return Number(row?.total || 0) > 0;
    }
    async indexExists(tableName, indexName) {
        try {
            const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
         FROM pg_indexes
         WHERE tablename = ? AND indexname = ?`, [tableName, indexName]);
            return Number(row?.total || 0) > 0;
        }
        catch {
            try {
                const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
           FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`, [tableName, indexName]);
                return Number(row?.total || 0) > 0;
            }
            catch {
                try {
                    const rows = await (0, database_1.query)(`SHOW INDEX FROM ${tableName} WHERE Key_name = ?`, [indexName]);
                    return Array.isArray(rows) && rows.length > 0;
                }
                catch {
                    return false;
                }
            }
        }
    }
    async ensureColumn(tableName, columnName, definition) {
        const exists = await this.columnExists(tableName, columnName);
        if (!exists) {
            try {
                await (0, database_1.query)(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
            }
            catch (error) {
                const message = String(error?.message || "").toLowerCase();
                if (error?.code === "ER_DUP_FIELDNAME" || message.includes("duplicate column")) {
                    return;
                }
                throw error;
            }
        }
    }
    async ensureIndex(tableName, indexName, columnName) {
        const exists = await this.indexExists(tableName, indexName);
        if (!exists) {
            await (0, database_1.query)(`CREATE INDEX ${indexName} ON ${tableName} (${columnName})`);
        }
    }
    constructor(instanceManager, rotationEngine) {
        this.instanceManager = instanceManager;
        this.rotationEngine = rotationEngine;
        this.schemaReady = false;
        this.activeCampaigns = new Map();
        this.contextEngine = new contextEngine_1.ContextEngineService();
        this.gemini = new gemini_1.GeminiService();
        // ─── Customer columns ──────────────────────────────────────────
        this.customerColumnsCache = null;
        this.campaignHistoryColumnsCache = null;
    }
    // ─── Schema ────────────────────────────────────────────────────
    async ensureSchema() {
        if (this.schemaReady)
            return;
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS campaign_leads (
        id VARCHAR(36) PRIMARY KEY,
        campaign_id VARCHAR(36) NOT NULL,
        user_id VARCHAR(36) NOT NULL,
        brand_id VARCHAR(36) DEFAULT NULL,
        lead_id VARCHAR(64) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        whatsapp_valid TINYINT(1) DEFAULT NULL,
        whatsapp_jid VARCHAR(120) DEFAULT NULL,
        message_text TEXT,
        ai_generated TINYINT(1) DEFAULT 0,
        status ENUM('pending','validating','ready','sending','sent','delivered','read','replied','failed','skipped','opted_out') DEFAULT 'pending',
        sent_at TIMESTAMP NULL,
        delivered_at TIMESTAMP NULL,
        read_at TIMESTAMP NULL,
        replied_at TIMESTAMP NULL,
        reply_text TEXT,
        reply_classification ENUM('interested','neutral','negative','opt_out') DEFAULT NULL,
        score_delta INT DEFAULT 0,
        tags_added JSON,
        error_message TEXT,
        attempt_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_campaign_lead (campaign_id, lead_id),
        KEY idx_cl_campaign (campaign_id),
        KEY idx_cl_user (user_id),
        KEY idx_cl_brand (brand_id),
        KEY idx_cl_lead (lead_id),
        KEY idx_cl_status (status),
        KEY idx_cl_phone (phone)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
        await this.ensureColumn("campaign_history", "use_ai", "TINYINT(1) DEFAULT 0");
        await this.ensureColumn("campaign_history", "filter_json", "JSON");
        await this.ensureColumn("campaign_history", "speed_json", "JSON");
        await this.ensureColumn("campaign_history", "campaign_mode", "VARCHAR(40) DEFAULT 'educational'");
        await this.ensureColumn("campaign_history", "settings", "JSON");
        await this.ensureColumn("campaign_history", "interested_count", "INT DEFAULT 0");
        await this.ensureColumn("campaign_history", "neutral_count", "INT DEFAULT 0");
        await this.ensureColumn("campaign_history", "negative_count", "INT DEFAULT 0");
        await this.ensureColumn("campaign_history", "opted_out_count", "INT DEFAULT 0");
        await this.ensureColumn("campaign_history", "use_instance_rotation", "TINYINT(1) DEFAULT 0");
        await this.ensureColumn("campaign_history", "rotation_mode", "VARCHAR(20) DEFAULT 'balanced'");
        await this.ensureColumn("campaign_history", "brand_id", "VARCHAR(36) DEFAULT NULL");
        await this.ensureColumn("campaign_leads", "brand_id", "VARCHAR(36) DEFAULT NULL");
        await this.ensureIndex("campaign_history", "idx_campaign_history_brand", "brand_id");
        await this.ensureIndex("campaign_leads", "idx_campaign_leads_brand", "brand_id");
        this.schemaReady = true;
    }
    async getCustomerColumns() {
        if (!this.customerColumnsCache) {
            const rows = await (0, database_1.query)("SHOW COLUMNS FROM customers");
            this.customerColumnsCache = rows.map(r => String(r.Field || ""));
        }
        return new Set(this.customerColumnsCache);
    }
    async getOwnerColumn() {
        const cols = await this.getCustomerColumns();
        if (cols.has("owner_user_id"))
            return "owner_user_id";
        if (cols.has("user_id"))
            return "user_id";
        return null;
    }
    async getCityColumn() {
        const cols = await this.getCustomerColumns();
        if (cols.has("city"))
            return "city";
        if (cols.has("address_city"))
            return "address_city";
        return null;
    }
    async getCategoryColumn() {
        const cols = await this.getCustomerColumns();
        if (cols.has("category"))
            return "category";
        return null;
    }
    async hasCustomerColumn(column) {
        const cols = await this.getCustomerColumns();
        return cols.has(column);
    }
    async getCampaignHistoryColumns() {
        if (!this.campaignHistoryColumnsCache) {
            const rows = await (0, database_1.query)("SHOW COLUMNS FROM campaign_history");
            this.campaignHistoryColumnsCache = rows.map((row) => String(row.Field || ""));
        }
        return new Set(this.campaignHistoryColumnsCache);
    }
    normalizeCampaignDestinationSettings(settingsInput) {
        const settings = settingsInput && typeof settingsInput === "object" ? settingsInput : {};
        const destinationRaw = (settings.destination || {});
        const type = normalizeDestinationType(destinationRaw.type);
        const targetType = normalizeDestinationTargetType(destinationRaw.targetType);
        const targetsRaw = Array.isArray(destinationRaw.targets) ? destinationRaw.targets : [];
        const normalizedTargets = [];
        const seen = new Set();
        for (const item of targetsRaw) {
            const jid = normalizeJid(item?.jid);
            const instance_id = String(item?.instance_id || item?.instanceId || "").trim();
            if (!jid || !instance_id)
                continue;
            const target_type = normalizeDestinationTargetType(item?.target_type || item?.targetType || targetType);
            const key = `${instance_id}::${jid}`;
            if (seen.has(key))
                continue;
            seen.add(key);
            normalizedTargets.push({
                jid,
                instance_id,
                instance_name: String(item?.instance_name || item?.instanceName || "").trim() || undefined,
                name: String(item?.name || item?.contact_name || jid).trim() || jid,
                target_type,
                last_message_at: item?.last_message_at ? String(item?.last_message_at) : null,
            });
        }
        return {
            type,
            targetType: targetType,
            targets: normalizedTargets,
        };
    }
    async listDestinationTargets(userId, input, brandId) {
        await this.ensureSchema();
        const filters = input || {};
        const targetType = String(filters.targetType || "group").toLowerCase();
        const search = String(filters.search || "").trim();
        const instanceId = String(filters.instanceId || "").trim();
        const limit = Math.max(20, Math.min(Number(filters.limit || 120), 400));
        const normalizedBrandId = String(brandId || "").trim();
        const hasInstanceBrand = await this.columnExists("whatsapp_instances", "brand_id");
        const connectedOnly = filters.connectedOnly !== false;
        let sql = `
      SELECT
        c.remote_jid,
        c.contact_name,
        c.instance_id,
        c.is_group,
        i.name AS instance_name,
        COALESCE(c.last_message_at, c.updated_at, c.created_at) AS last_message_at
      FROM whatsapp_conversations c
      JOIN whatsapp_instances i ON i.id = c.instance_id
      WHERE i.created_by = ?
    `;
        const params = [userId];
        if (hasInstanceBrand) {
            if (normalizedBrandId) {
                sql += " AND i.brand_id = ?";
                params.push(normalizedBrandId);
            }
            else {
                sql += " AND i.brand_id IS NULL";
            }
        }
        if (connectedOnly) {
            sql += " AND i.status = 'connected'";
        }
        if (instanceId) {
            sql += " AND c.instance_id = ?";
            params.push(instanceId);
        }
        if (targetType === "group") {
            sql += " AND (c.is_group = 1 OR c.remote_jid LIKE '%@g.us')";
        }
        else if (targetType === "channel") {
            sql += " AND (c.remote_jid LIKE '%@newsletter' OR c.remote_jid LIKE '%@broadcast')";
        }
        else if (targetType === "contact") {
            sql += " AND (COALESCE(c.is_group, 0) = 0 AND c.remote_jid NOT LIKE '%@g.us' AND c.remote_jid NOT LIKE '%@newsletter' AND c.remote_jid NOT LIKE '%@broadcast')";
        }
        if (search) {
            sql += " AND (c.contact_name LIKE ? OR c.remote_jid LIKE ? OR i.name LIKE ?)";
            const like = `%${search}%`;
            params.push(like, like, like);
        }
        sql += " ORDER BY COALESCE(c.last_message_at, c.updated_at, c.created_at) DESC LIMIT ?";
        params.push(limit);
        const rows = await (0, database_1.query)(sql, params);
        const seen = new Set();
        const mapped = [];
        for (const row of rows) {
            const jid = normalizeJid(row?.remote_jid);
            if (!jid)
                continue;
            const resolvedTargetType = jid.endsWith("@newsletter") || jid.endsWith("@broadcast")
                ? "channel"
                : (Boolean(Number(row?.is_group || 0)) || jid.endsWith("@g.us") ? "group" : "contact");
            const key = `${row.instance_id}::${jid}`;
            if (seen.has(key))
                continue;
            seen.add(key);
            mapped.push({
                jid,
                name: String(row?.contact_name || jid),
                instance_id: String(row?.instance_id || ""),
                instance_name: String(row?.instance_name || ""),
                target_type: resolvedTargetType,
                last_message_at: row?.last_message_at ? new Date(row.last_message_at).toISOString() : null,
            });
        }
        return mapped;
    }
    // ─── Lead filtering ────────────────────────────────────────────
    async filterLeads(userId, filter) {
        await this.ensureSchema();
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const conditions = [];
        const params = [];
        // Owner
        if (ownerCol) {
            conditions.push(`${ownerCol} = ?`);
            params.push(userId);
        }
        if (cols.has("brand_id")) {
            conditions.push(`brand_id IS NULL`);
        }
        // Must have phone
        if (cols.has("phone")) {
            conditions.push(`phone IS NOT NULL AND TRIM(phone) != ''`);
        }
        // Status filter
        if (filter.statuses?.length) {
            const expandedStatuses = expandStatusFilterVariants(filter.statuses);
            if (expandedStatuses.length > 0) {
                const placeholders = expandedStatuses.map(() => "?").join(",");
                conditions.push(`LOWER(TRIM(COALESCE(status, ''))) IN (${placeholders})`);
                params.push(...expandedStatuses);
            }
        }
        // City filter
        if (filter.cities?.length) {
            const cityCol = cols.has("city") ? "city" : cols.has("address_city") ? "address_city" : null;
            if (cityCol) {
                const placeholders = filter.cities.map(() => "?").join(",");
                conditions.push(`${cityCol} IN (${placeholders})`);
                params.push(...filter.cities);
            }
        }
        // Source filter
        if (filter.sources?.length && cols.has("source")) {
            const placeholders = filter.sources.map(() => "?").join(",");
            conditions.push(`source IN (${placeholders})`);
            params.push(...filter.sources);
        }
        // Score filter
        if (cols.has("lead_score")) {
            if (typeof filter.scoreMin === "number") {
                conditions.push("lead_score >= ?");
                params.push(filter.scoreMin);
            }
            if (typeof filter.scoreMax === "number") {
                conditions.push("lead_score <= ?");
                params.push(filter.scoreMax);
            }
        }
        // Category/segment filter via source_details or category column
        if (filter.segments?.length) {
            if (cols.has("category")) {
                const placeholders = filter.segments.map(() => "?").join(",");
                conditions.push(`category IN (${placeholders})`);
                params.push(...filter.segments);
            }
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
        const selectCols = [
            "id", "name", "phone",
            cols.has("status") ? "status" : "'new' AS status",
            cols.has("tags") ? "tags" : "NULL AS tags",
            cols.has("city") ? "city" : cols.has("address_city") ? "address_city AS city" : "NULL AS city",
            cols.has("state") ? "state" : "NULL AS state",
            cols.has("category") ? "category" : "NULL AS category",
            cols.has("lead_score") ? "lead_score" : "0 AS lead_score",
            cols.has("source") ? "source" : "'manual' AS source",
            cols.has("source_details") ? "source_details" : "NULL AS source_details",
        ].join(", ");
        let leads = await (0, database_1.query)(`SELECT ${selectCols} FROM customers ${where} ORDER BY id ASC`, params);
        // Tag-based filtering in JS (MySQL JSON searching is complex across schemas)
        if (filter.tagsInclude?.length) {
            leads = leads.filter(lead => {
                const tags = parseJsonArray(lead.tags);
                const tagsLower = new Set(tags.map(t => t.toLowerCase()));
                return filter.tagsInclude.some(tag => tagsLower.has(tag.toLowerCase()));
            });
        }
        if (filter.tagsExclude?.length) {
            leads = leads.filter(lead => {
                const tags = parseJsonArray(lead.tags);
                const tagsLower = new Set(tags.map(t => t.toLowerCase()));
                return !filter.tagsExclude.some(tag => tagsLower.has(tag.toLowerCase()));
            });
        }
        // WhatsApp filter
        if (filter.hasWhatsapp === true) {
            leads = leads.filter(lead => {
                const details = parseJsonSafe(lead.source_details);
                const validation = details?.whatsapp_validation || {};
                return validation?.has_whatsapp === true || isTruthyFlag(lead.whatsapp_valid);
            });
        }
        // Exclude opted_out leads
        leads = leads.filter(lead => {
            const tags = parseJsonArray(lead.tags);
            const tagsLower = new Set(tags.map(t => t.toLowerCase()));
            return !tagsLower.has("opt_out") && !tagsLower.has("bloqueado");
        });
        return leads;
    }
    // ─── Campaign CRUD ─────────────────────────────────────────────
    async createCampaign(userId, input, brandId) {
        await this.ensureSchema();
        const id = (0, crypto_1.randomUUID)();
        const speed = { ...DEFAULT_SPEED, ...input.speedControl };
        const filter = normalizeCampaignFilterInput(input.filter || {});
        const mode = input.campaignMode || "educational";
        const sourceSettings = input.settings && typeof input.settings === "object" ? input.settings : {};
        const destinationSettings = this.normalizeCampaignDestinationSettings(sourceSettings);
        const hasDestinationTargets = destinationSettings.type !== "lead_list" && destinationSettings.targets.length > 0;
        // Count matching leads
        const leads = hasDestinationTargets ? [] : await this.filterLeadsByBrand(userId, filter, brandId);
        const requestedInitialStatus = String(input.initialStatus || "draft").toLowerCase();
        let status = input.scheduledAt ? "scheduled" : "draft";
        if (!input.scheduledAt && requestedInitialStatus === "paused") {
            status = "paused";
        }
        const normalizedBrandId = String(brandId || "").trim() || null;
        const mergedSettings = {
            campaignMode: mode,
            ...sourceSettings,
            destination: destinationSettings,
            finalActions: {
                nextStatus: String(sourceSettings?.finalActions?.nextStatus || "").trim() || undefined,
                addTags: parseTagList(sourceSettings?.finalActions?.addTags),
            },
            actionWindow: {
                enabled: Boolean(sourceSettings?.actionWindow?.enabled),
                start: String(sourceSettings?.actionWindow?.start || "08:00"),
                end: String(sourceSettings?.actionWindow?.end || "20:00"),
            },
            requestedInitialStatus,
        };
        await (0, database_1.query)(`INSERT INTO campaign_history (
        id, user_id, brand_id, instance_id, name, message_template, ai_prompt, use_ai,
        filter_json, speed_json, campaign_mode, target_count, status, scheduled_at, settings
        , use_instance_rotation, rotation_mode
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            id, userId, normalizedBrandId, input.instanceId, input.name,
            input.messageTemplate || null,
            input.aiPrompt || null,
            input.useAI ? true : false,
            JSON.stringify(filter),
            JSON.stringify(speed),
            mode,
            hasDestinationTargets ? destinationSettings.targets.length : leads.length,
            status,
            input.scheduledAt || null,
            JSON.stringify(mergedSettings),
            input.useInstanceRotation ? true : false,
            String(input.rotationMode || "balanced"),
        ]);
        // Create campaign_leads records
        if (hasDestinationTargets) {
            for (const target of destinationSettings.targets) {
                const jid = normalizeJid(target.jid);
                const compactPhone = normalizePhone(jid).slice(0, 20) || "0000000000";
                const syntheticLeadId = `dest:${target.target_type}:${jid}`.slice(0, 64);
                await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, whatsapp_jid, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
           ON DUPLICATE KEY UPDATE id = id`, [(0, crypto_1.randomUUID)(), id, userId, normalizedBrandId, syntheticLeadId, compactPhone, jid]);
            }
        }
        else {
            for (const lead of leads) {
                const phone = normalizePhone(lead.phone);
                if (!phone)
                    continue;
                await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, status)
           VALUES (?, ?, ?, ?, ?, ?, 'pending')
           ON DUPLICATE KEY UPDATE id = id`, [(0, crypto_1.randomUUID)(), id, userId, normalizedBrandId, String(lead.id), phone]);
            }
        }
        return this.getCampaign(userId, id, normalizedBrandId);
    }
    async updateCampaign(userId, campaignId, input, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim() || null;
        // Only allow editing campaigns in draft, scheduled, or paused status
        const existing = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!existing)
            return null;
        if (!["draft", "scheduled", "paused"].includes(existing.status)) {
            throw new Error("Apenas campanhas em rascunho, agendadas ou pausadas podem ser editadas");
        }
        const existingDestination = this.normalizeCampaignDestinationSettings(existing.settings || {});
        const effectiveSettings = {
            ...(existing.settings || {}),
            ...((input.settings && typeof input.settings === "object") ? input.settings : {}),
        };
        const effectiveDestination = this.normalizeCampaignDestinationSettings(effectiveSettings);
        const destinationSignature = (destination) => {
            const targets = (destination.targets || [])
                .map((item) => `${item.instance_id}::${item.jid}::${item.target_type}`)
                .sort();
            return `${destination.type}|${destination.targetType}|${targets.join("|")}`;
        };
        const destinationChanged = destinationSignature(existingDestination) !== destinationSignature(effectiveDestination);
        const sets = [];
        const params = [];
        if (input.name !== undefined) {
            sets.push("name = ?");
            params.push(input.name);
        }
        if (input.instanceId !== undefined) {
            const normalizedInstanceId = String(input.instanceId || "").trim();
            if (normalizedInstanceId) {
                sets.push("instance_id = ?");
                params.push(normalizedInstanceId);
            }
        }
        if (input.messageTemplate !== undefined) {
            sets.push("message_template = ?");
            params.push(input.messageTemplate || null);
        }
        if (input.aiPrompt !== undefined) {
            sets.push("ai_prompt = ?");
            params.push(input.aiPrompt || null);
        }
        if (input.useAI !== undefined) {
            sets.push("use_ai = ?");
            params.push(input.useAI ? true : false);
        }
        if (input.campaignMode !== undefined) {
            sets.push("campaign_mode = ?");
            params.push(input.campaignMode);
        }
        if (input.filter !== undefined && (effectiveDestination.type === "lead_list" || effectiveDestination.targets.length === 0)) {
            const normalizedFilter = normalizeCampaignFilterInput(input.filter || {});
            sets.push("filter_json = ?");
            params.push(JSON.stringify(normalizedFilter));
        }
        if (input.speedControl !== undefined) {
            const speed = { ...DEFAULT_SPEED, ...input.speedControl };
            sets.push("speed_json = ?");
            params.push(JSON.stringify(speed));
        }
        if (input.scheduledAt !== undefined) {
            sets.push("scheduled_at = ?");
            params.push(input.scheduledAt || null);
        }
        if (input.useInstanceRotation !== undefined) {
            sets.push("use_instance_rotation = ?");
            params.push(input.useInstanceRotation ? true : false);
        }
        if (input.rotationMode !== undefined) {
            sets.push("rotation_mode = ?");
            params.push(input.rotationMode);
        }
        if (input.settings !== undefined) {
            const existingSettings = existing.settings || {};
            const mergedSettings = {
                ...existingSettings,
                ...input.settings,
            };
            sets.push("settings = ?");
            params.push(JSON.stringify(mergedSettings));
        }
        const shouldRebuildPendingTargets = input.filter !== undefined || destinationChanged;
        if (shouldRebuildPendingTargets) {
            const effectiveFilter = normalizeCampaignFilterInput((input.filter || existing.filter_json || {}));
            await (0, database_1.query)(`DELETE FROM campaign_leads
         WHERE campaign_id = ?
           AND user_id = ?
           AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
           AND status IN ('pending','validating','ready')`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
            if (effectiveDestination.type !== "lead_list" && effectiveDestination.targets.length > 0) {
                for (const target of effectiveDestination.targets) {
                    const jid = normalizeJid(target.jid);
                    const compactPhone = normalizePhone(jid).slice(0, 20) || "0000000000";
                    const syntheticLeadId = `dest:${target.target_type}:${jid}`.slice(0, 64);
                    await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, whatsapp_jid, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
             ON DUPLICATE KEY UPDATE id = id`, [(0, crypto_1.randomUUID)(), campaignId, userId, normalizedBrandId, syntheticLeadId, compactPhone, jid]);
                }
                sets.push("target_count = ?");
                params.push(effectiveDestination.targets.length);
            }
            else {
                const leads = await this.filterLeadsByBrand(userId, effectiveFilter, normalizedBrandId);
                for (const lead of leads) {
                    const phone = normalizePhone(lead.phone);
                    if (!phone)
                        continue;
                    await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, status)
             VALUES (?, ?, ?, ?, ?, ?, 'pending')
             ON DUPLICATE KEY UPDATE id = id`, [(0, crypto_1.randomUUID)(), campaignId, userId, normalizedBrandId, String(lead.id), phone]);
                }
                sets.push("target_count = ?");
                params.push(leads.length);
            }
        }
        if (sets.length === 0) {
            return existing;
        }
        sets.push("updated_at = NOW()");
        const sql = `UPDATE campaign_history SET ${sets.join(", ")} WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`;
        params.push(campaignId, userId);
        if (normalizedBrandId)
            params.push(normalizedBrandId);
        await (0, database_1.update)(sql, params);
        return this.getCampaign(userId, campaignId, normalizedBrandId);
    }
    async getCampaign(userId, campaignId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim();
        const row = await (0, database_1.queryOne)(`SELECT * FROM campaign_history WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"} LIMIT 1`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        if (!row)
            return null;
        return this.mapCampaign(row);
    }
    async listCampaigns(userId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim();
        const rows = await (0, database_1.query)(`SELECT * FROM campaign_history WHERE user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"} ORDER BY created_at DESC LIMIT 50`, normalizedBrandId ? [userId, normalizedBrandId] : [userId]);
        return rows.map(row => this.mapCampaign(row));
    }
    async duplicateCampaign(userId, campaignId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim() || null;
        const existing = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!existing)
            return null;
        const duplicatedName = `${existing.name} (Copia)`;
        return this.createCampaign(userId, {
            name: duplicatedName,
            instanceId: existing.instance_id,
            messageTemplate: existing.message_template || undefined,
            aiPrompt: existing.ai_prompt || undefined,
            useAI: Boolean(existing.use_ai),
            filter: existing.filter_json || {},
            speedControl: existing.speed_json || DEFAULT_SPEED,
            campaignMode: existing.campaign_mode || "educational",
            useInstanceRotation: Boolean(existing.use_instance_rotation),
            rotationMode: existing.rotation_mode || "balanced",
            settings: existing.settings || {},
            initialStatus: "draft",
        }, normalizedBrandId);
    }
    async deleteCampaign(userId, campaignId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim() || null;
        const existing = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!existing) {
            return { ok: false, message: "Campanha nao encontrada" };
        }
        this.activeCampaigns.set(campaignId, false);
        this.activeCampaigns.delete(campaignId);
        await (0, database_1.query)(`DELETE FROM campaign_leads
       WHERE campaign_id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        await (0, database_1.query)(`DELETE FROM campaign_history
       WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        return { ok: true, message: "Campanha removida com sucesso" };
    }
    async getCampaignLeads(userId, campaignId, status, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim();
        const cityCol = await this.getCityColumn();
        const categoryCol = await this.getCategoryColumn();
        let sql = `SELECT cl.*, c.name AS lead_name,
           ${cityCol ? `c.${cityCol} AS lead_city` : "NULL AS lead_city"},
           ${categoryCol ? `c.${categoryCol} AS lead_category` : "NULL AS lead_category"}
               FROM campaign_leads cl
               LEFT JOIN customers c ON c.id = cl.lead_id
           WHERE cl.campaign_id = ? AND cl.user_id = ? AND ${normalizedBrandId ? "cl.brand_id = ?" : "cl.brand_id IS NULL"}`;
        const params = normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId];
        if (status) {
            sql += " AND cl.status = ?";
            params.push(status);
        }
        sql += " ORDER BY cl.created_at ASC";
        const rows = await (0, database_1.query)(sql, params);
        return rows.map(row => this.mapCampaignLead(row));
    }
    async getCampaignMetrics(userId, campaignId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim();
        const history = await (0, database_1.queryOne)(`SELECT sent_count, delivered_count, read_count, replied_count,
              interested_count, neutral_count, negative_count, opted_out_count
       FROM campaign_history
       WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
       LIMIT 1`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        const rows = await (0, database_1.query)(`SELECT status, reply_classification, COUNT(*) AS cnt
       FROM campaign_leads
       WHERE campaign_id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
       GROUP BY status, reply_classification`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        const counts = {};
        let total = 0;
        let interested = 0, neutral = 0, negative = 0, opted_out = 0;
        for (const row of rows) {
            const st = String(row.status || "pending");
            const cnt = Number(row.cnt || 0);
            counts[st] = (counts[st] || 0) + cnt;
            total += cnt;
            if (row.reply_classification === "interested")
                interested += cnt;
            if (row.reply_classification === "neutral")
                neutral += cnt;
            if (row.reply_classification === "negative")
                negative += cnt;
            if (row.reply_classification === "opt_out")
                opted_out += cnt;
        }
        const sentFromLeadStatuses = (counts["sent"] || 0) +
            (counts["delivered"] || 0) +
            (counts["read"] || 0) +
            (counts["replied"] || 0);
        const deliveredFromLeadStatuses = (counts["delivered"] || 0) + (counts["read"] || 0) + (counts["replied"] || 0);
        const readFromLeadStatuses = (counts["read"] || 0) + (counts["replied"] || 0);
        const repliedFromLeadStatuses = counts["replied"] || 0;
        const sent = Math.max(sentFromLeadStatuses, Number(history?.sent_count || 0));
        const delivered = Math.max(deliveredFromLeadStatuses, Number(history?.delivered_count || 0));
        const replied = Math.max(repliedFromLeadStatuses, Number(history?.replied_count || 0));
        const read = Math.max(readFromLeadStatuses, Number(history?.read_count || 0), replied);
        interested = Math.max(interested, Number(history?.interested_count || 0));
        neutral = Math.max(neutral, Number(history?.neutral_count || 0));
        negative = Math.max(negative, Number(history?.negative_count || 0));
        opted_out = Math.max(opted_out, Number(history?.opted_out_count || 0));
        const pending = (counts["pending"] || 0) +
            (counts["validating"] || 0) +
            (counts["ready"] || 0) +
            (counts["sending"] || 0);
        const lastOutboundMessage = await (0, database_1.queryOne)(`SELECT content, status, sent_at, phone
       FROM message_log
       WHERE campaign_id = ? AND user_id = ? AND direction = 'outbound'
       ORDER BY sent_at DESC
       LIMIT 1`, [campaignId, userId]);
        const lastLeadEvent = await (0, database_1.queryOne)(`SELECT status, phone, sent_at, delivered_at, read_at, replied_at, updated_at, created_at
       FROM campaign_leads
       WHERE campaign_id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
       ORDER BY COALESCE(replied_at, read_at, delivered_at, sent_at, updated_at, created_at) DESC
       LIMIT 1`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        const rawMessage = String(lastOutboundMessage?.content || "").trim();
        const truncated = rawMessage.length > 160;
        const messagePreview = truncated ? `${rawMessage.slice(0, 157)}...` : rawMessage;
        const lastMessage = rawMessage || lastLeadEvent
            ? {
                text: messagePreview,
                truncated,
                status: String(lastLeadEvent?.status || lastOutboundMessage?.status || "").trim() || null,
                sentAt: lastOutboundMessage?.sent_at ? String(lastOutboundMessage.sent_at) : null,
                eventAt: (lastLeadEvent?.replied_at ||
                    lastLeadEvent?.read_at ||
                    lastLeadEvent?.delivered_at ||
                    lastLeadEvent?.sent_at ||
                    lastLeadEvent?.updated_at ||
                    lastLeadEvent?.created_at)
                    ? String(lastLeadEvent?.replied_at ||
                        lastLeadEvent?.read_at ||
                        lastLeadEvent?.delivered_at ||
                        lastLeadEvent?.sent_at ||
                        lastLeadEvent?.updated_at ||
                        lastLeadEvent?.created_at)
                    : null,
                phone: String(lastOutboundMessage?.phone || lastLeadEvent?.phone || "").trim() || null,
            }
            : null;
        return {
            total,
            pending,
            sent,
            delivered,
            read,
            replied,
            failed: counts["failed"] || 0,
            skipped: counts["skipped"] || 0,
            interested,
            neutral,
            negative,
            opted_out,
            responseRate: sent > 0 ? Number(((replied / sent) * 100).toFixed(1)) : 0,
            deliveryRate: sent > 0 ? Number(((delivered / sent) * 100).toFixed(1)) : 0,
            interestRate: replied > 0 ? Number(((interested / replied) * 100).toFixed(1)) : 0,
            lastMessage,
        };
    }
    // ─── Campaign execution ────────────────────────────────────────
    async getRunnableQueueCount(userId, campaignId, brandId) {
        const normalizedBrandId = String(brandId || "").trim() || null;
        const row = await (0, database_1.queryOne)(`SELECT COUNT(*) AS total
       FROM campaign_leads
       WHERE campaign_id = ?
         AND user_id = ?
         AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
         AND status IN ('pending','ready')`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        return Number(row?.total || 0);
    }
    async ensureCampaignQueueReady(userId, campaign, brandId) {
        const normalizedBrandId = String(brandId || "").trim() || null;
        const currentQueue = await this.getRunnableQueueCount(userId, campaign.id, normalizedBrandId);
        if (currentQueue > 0)
            return currentQueue;
        const destination = this.normalizeCampaignDestinationSettings(campaign.settings || {});
        if (destination.type !== "lead_list" && destination.targets.length > 0) {
            for (const target of destination.targets) {
                const jid = normalizeJid(target.jid);
                if (!jid)
                    continue;
                const compactPhone = normalizePhone(jid).slice(0, 20) || "0000000000";
                const syntheticLeadId = `dest:${target.target_type}:${jid}`.slice(0, 64);
                await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, whatsapp_jid, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
           ON DUPLICATE KEY UPDATE
             phone = VALUES(phone),
             whatsapp_jid = COALESCE(whatsapp_jid, VALUES(whatsapp_jid)),
             status = CASE
               WHEN status IN ('sent','delivered','read','replied','opted_out') THEN status
               ELSE 'pending'
             END,
             error_message = NULL,
             updated_at = NOW()`, [(0, crypto_1.randomUUID)(), campaign.id, userId, normalizedBrandId, syntheticLeadId, compactPhone, jid]);
            }
            await (0, database_1.update)(`UPDATE campaign_history SET target_count = ? WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId
                ? [destination.targets.length, campaign.id, userId, normalizedBrandId]
                : [destination.targets.length, campaign.id, userId]);
        }
        else {
            const leads = await this.filterLeadsByBrand(userId, campaign.filter_json || {}, normalizedBrandId);
            for (const lead of leads) {
                const phone = normalizePhone(lead.phone);
                if (!phone)
                    continue;
                await (0, database_1.query)(`INSERT INTO campaign_leads (id, campaign_id, user_id, brand_id, lead_id, phone, status)
           VALUES (?, ?, ?, ?, ?, ?, 'pending')
           ON DUPLICATE KEY UPDATE
             phone = VALUES(phone),
             status = CASE
               WHEN status IN ('sent','delivered','read','replied','opted_out') THEN status
               ELSE 'pending'
             END,
             error_message = NULL,
             updated_at = NOW()`, [(0, crypto_1.randomUUID)(), campaign.id, userId, normalizedBrandId, String(lead.id), phone]);
            }
            await (0, database_1.update)(`UPDATE campaign_history SET target_count = ? WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [leads.length, campaign.id, userId, normalizedBrandId] : [leads.length, campaign.id, userId]);
        }
        return this.getRunnableQueueCount(userId, campaign.id, normalizedBrandId);
    }
    async startCampaign(userId, campaignId, brandId) {
        await this.ensureSchema();
        const normalizedBrandId = String(brandId || "").trim() || null;
        const campaign = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!campaign)
            return { ok: false, message: "Campanha nao encontrada" };
        if (campaign.status === "running") {
            if (this.activeCampaigns.get(campaignId)) {
                return { ok: true, message: "Campanha ja esta em execucao" };
            }
            const queueCount = await this.ensureCampaignQueueReady(userId, campaign, normalizedBrandId);
            if (queueCount <= 0) {
                return { ok: false, message: "Campanha sem fila elegivel para disparo (pending/ready = 0)" };
            }
            this.activeCampaigns.set(campaignId, true);
            this.executeCampaign(userId, campaignId, normalizedBrandId).catch((err) => {
                logger_1.logger.error(`Campaign ${campaignId} resume failed: ${err.message}`);
            });
            return { ok: true, message: `Campanha retomada com ${queueCount} leads na fila` };
        }
        if (campaign.status !== "draft" && campaign.status !== "scheduled" && campaign.status !== "paused") {
            return { ok: false, message: `Campanha nao pode ser iniciada (status: ${campaign.status})` };
        }
        let startMessageSuffix = "";
        if (campaign.use_instance_rotation && this.rotationEngine) {
            const selected = await this.rotationEngine.selectInstance(userId, { preferredInstanceId: campaign.instance_id });
            if (!selected) {
                return { ok: false, message: "Nenhuma instancia conectada disponivel para rotacao" };
            }
            if (selected !== campaign.instance_id) {
                await (0, database_1.update)(`UPDATE campaign_history
           SET instance_id = ?, updated_at = NOW()
           WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [selected, campaignId, userId, normalizedBrandId] : [selected, campaignId, userId]);
            }
        }
        else {
            // Verify fixed instance
            const instance = this.instanceManager.getInstance(campaign.instance_id, userId);
            if (!instance || instance.status !== "connected") {
                if (this.rotationEngine) {
                    const selected = await this.rotationEngine.selectInstance(userId, { preferredInstanceId: campaign.instance_id });
                    if (!selected) {
                        return { ok: false, message: "Instancia WhatsApp nao esta conectada" };
                    }
                    await (0, database_1.update)(`UPDATE campaign_history
             SET instance_id = ?, use_instance_rotation = TRUE, updated_at = NOW()
             WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [selected, campaignId, userId, normalizedBrandId] : [selected, campaignId, userId]);
                    startMessageSuffix = ` (failover automatico para instancia ${selected.slice(0, 8)}...)`;
                }
                else {
                    return { ok: false, message: "Instancia WhatsApp nao esta conectada" };
                }
            }
        }
        const queueCount = await this.ensureCampaignQueueReady(userId, campaign, normalizedBrandId);
        if (queueCount <= 0) {
            return { ok: false, message: "Nenhum lead elegivel para disparo inicial" };
        }
        await (0, database_1.update)(`UPDATE campaign_history SET status = 'running', started_at = NOW() WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        this.activeCampaigns.set(campaignId, true);
        // Run in background
        this.executeCampaign(userId, campaignId, normalizedBrandId).catch(err => {
            logger_1.logger.error(`Campaign ${campaignId} execution failed: ${err.message}`);
        });
        return { ok: true, message: `Campanha iniciada com ${queueCount} leads na fila${startMessageSuffix}` };
    }
    async pauseCampaign(userId, campaignId, brandId) {
        this.activeCampaigns.set(campaignId, false);
        const normalizedBrandId = String(brandId || "").trim() || null;
        await (0, database_1.update)(`UPDATE campaign_history SET status = 'paused' WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"} AND status = 'running'`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        return { ok: true, message: "Campanha pausada" };
    }
    async cancelCampaign(userId, campaignId, brandId) {
        this.activeCampaigns.set(campaignId, false);
        const normalizedBrandId = String(brandId || "").trim() || null;
        await (0, database_1.update)(`UPDATE campaign_history SET status = 'cancelled', completed_at = NOW() WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        // Cancel pending leads
        await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped' WHERE campaign_id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"} AND status IN ('pending','validating','ready')`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        return { ok: true, message: "Campanha cancelada" };
    }
    async reExecuteCampaign(userId, campaignId, brandId) {
        const normalizedBrandId = String(brandId || "").trim() || null;
        const campaign = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!campaign)
            return { ok: false, message: "Campanha nao encontrada" };
        if (!["completed", "cancelled", "failed"].includes(campaign.status)) {
            return { ok: false, message: `Campanha nao pode ser reexecutada (status: ${campaign.status})` };
        }
        // Reset campaign status to draft
        await (0, database_1.update)(`UPDATE campaign_history SET status = 'draft', started_at = NULL, completed_at = NULL, sent_count = 0, failed_count = 0, updated_at = NOW() WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        // Reset all leads back to pending
        await (0, database_1.update)(`UPDATE campaign_leads SET status = 'pending', error_message = NULL, sent_at = NULL, whatsapp_valid = NULL, generated_message = NULL WHERE campaign_id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        return { ok: true, message: "Campanha resetada para rascunho. Pronta para reexecucao." };
    }
    async sendCampaignTest(userId, input) {
        const instanceId = String(input.instanceId || "").trim();
        const templatePrompt = String(input.templatePrompt || "").trim();
        if (!instanceId || !templatePrompt) {
            throw new Error("instanceId and templatePrompt are required");
        }
        const instance = await (0, database_1.queryOne)("SELECT id, phone FROM whatsapp_instances WHERE id = ? AND created_by = ? LIMIT 1", [instanceId, userId]);
        if (!instance)
            throw new Error("Instance not found");
        const explicitPhone = normalizePhone(input.testPhone);
        const fallbackPhone = normalizePhone(instance.phone);
        const sentTo = explicitPhone || fallbackPhone;
        if (!sentTo) {
            throw new Error("No test destination number available. Connect this instance first or provide testPhone.");
        }
        const runtimeInstance = this.instanceManager.getInstance(instanceId, userId);
        if (!runtimeInstance || runtimeInstance.status !== "connected") {
            throw new Error("Instance not connected");
        }
        const lead = input.lead || {};
        const leadContext = {
            id: "test-lead",
            name: String(lead.name || "Contato de Teste"),
            phone: sentTo,
            address: String(lead.address || ""),
            city: String(lead.city || ""),
            state: String(lead.state || ""),
            category: String(lead.category || ""),
            status: "new",
            messagesSent: [],
            messagesReceived: [],
            createdAt: new Date(),
        };
        let generated = templatePrompt;
        try {
            generated = await this.gemini.generateMessage(leadContext, templatePrompt);
        }
        catch {
            generated = templatePrompt;
        }
        const hasImage = Boolean(String(input.mediaImagePath || "").trim());
        const useTextAsCaption = Boolean(input.useTextAsCaption);
        const preview = `[TESTE DE CAMPANHA]\n${generated}`;
        if (hasImage) {
            const explicitCaption = String(input.mediaImageCaption || "").trim();
            const resolvedCaption = explicitCaption || (useTextAsCaption ? generated : "");
            const sentMedia = await this.instanceManager.sendMedia(instanceId, sentTo, {
                mediaType: "image",
                filePath: String(input.mediaImagePath || ""),
                caption: resolvedCaption || undefined,
            });
            if (!sentMedia) {
                throw new Error("Failed to send test image");
            }
            return {
                message: "Test image sent successfully",
                sentTo,
                usedDefaultNumber: explicitPhone.length === 0,
                preview: resolvedCaption ? `[TESTE DE CAMPANHA · IMAGEM]\n${resolvedCaption}` : "[TESTE DE CAMPANHA · IMAGEM]",
            };
        }
        const sent = await this.instanceManager.sendMessage(instanceId, sentTo, preview);
        if (!sent) {
            throw new Error("Failed to send test message");
        }
        return {
            message: "Test message sent successfully",
            sentTo,
            usedDefaultNumber: explicitPhone.length === 0,
            preview,
        };
    }
    // ─── Core execution loop ───────────────────────────────────────
    async executeCampaign(userId, campaignId, brandId) {
        logger_1.logger.info(`[Campaign ${campaignId}] Starting execution`);
        const normalizedBrandId = String(brandId || "").trim() || null;
        const campaign = await this.getCampaign(userId, campaignId, normalizedBrandId);
        if (!campaign)
            return;
        const speed = campaign.speed_json || DEFAULT_SPEED;
        const useAI = campaign.use_ai;
        const campaignSettings = parseJsonSafe(campaign.settings);
        const actionWindow = (campaignSettings?.actionWindow || {});
        const schedulerSettings = parseJsonSafe(campaignSettings?.scheduler || {});
        const actionWindowTimeZone = String(schedulerSettings?.timeZone || campaignSettings?.timeZone || "").trim() || undefined;
        const finalActions = (campaignSettings?.finalActions || {});
        let contextPayload = null;
        if (useAI) {
            try {
                contextPayload = await this.contextEngine.getResolvedContext(userId, normalizedBrandId || undefined);
            }
            catch (err) {
                logger_1.logger.warn(`[Campaign ${campaignId}] Context engine failed: ${err.message}`);
            }
        }
        // Get pending leads
        const cityCol = await this.getCityColumn();
        const categoryCol = await this.getCategoryColumn();
        const hasStateCol = await this.hasCustomerColumn("state");
        const hasTagsCol = await this.hasCustomerColumn("tags");
        const hasSourceDetailsCol = await this.hasCustomerColumn("source_details");
        const pendingLeads = await (0, database_1.query)(`SELECT cl.*, c.name AS lead_name, c.phone AS lead_phone, ${cityCol ? `c.${cityCol} AS lead_city` : "NULL AS lead_city"},
              ${categoryCol ? `c.${categoryCol} AS lead_category` : "NULL AS lead_category"},
              ${hasStateCol ? "c.state AS lead_state" : "NULL AS lead_state"},
              ${hasTagsCol ? "c.tags AS lead_tags" : "NULL AS lead_tags"},
              ${hasSourceDetailsCol ? "c.source_details AS source_details" : "NULL AS source_details"}
       FROM campaign_leads cl
       LEFT JOIN customers c ON c.id = cl.lead_id
       WHERE cl.campaign_id = ? AND cl.user_id = ? AND ${normalizedBrandId ? "cl.brand_id = ?" : "cl.brand_id IS NULL"} AND cl.status IN ('pending','ready')
       ORDER BY cl.created_at ASC`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
        let sentThisRun = 0;
        let failedConsecutive = 0;
        const maxConsecutiveFails = 5;
        for (let i = 0; i < pendingLeads.length; i++) {
            const lead = pendingLeads[i];
            // Check if campaign was paused/cancelled
            if (!this.activeCampaigns.get(campaignId)) {
                logger_1.logger.info(`[Campaign ${campaignId}] Stopped by user`);
                break;
            }
            const runtimeStatusRow = await (0, database_1.queryOne)(`SELECT status
         FROM campaign_history
         WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"}
         LIMIT 1`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
            const runtimeStatus = String(runtimeStatusRow?.status || "").trim().toLowerCase();
            if (runtimeStatus && runtimeStatus !== "running") {
                this.activeCampaigns.set(campaignId, false);
                logger_1.logger.info(`[Campaign ${campaignId}] Stopped due to status change (${runtimeStatus})`);
                break;
            }
            // Daily limit check
            if (sentThisRun >= speed.dailyLimit) {
                logger_1.logger.info(`[Campaign ${campaignId}] Daily limit reached: ${sentThisRun}`);
                break;
            }
            if (actionWindow?.enabled &&
                actionWindow.start &&
                actionWindow.end &&
                !isInDailyWindow(new Date(), actionWindow.start, actionWindow.end, actionWindowTimeZone)) {
                await sleep(30000);
                i--;
                continue;
            }
            // Auto-pause on high block rate
            if (sentThisRun > 10 && failedConsecutive >= maxConsecutiveFails) {
                logger_1.logger.warn(`[Campaign ${campaignId}] Auto-paused: ${failedConsecutive} consecutive failures`);
                await this.pauseCampaign(userId, campaignId, normalizedBrandId);
                break;
            }
            const destinationJid = normalizeJid(lead.whatsapp_jid || "");
            const isSyntheticDestination = String(lead.lead_id || "").startsWith("dest:");
            const phone = normalizePhone(lead.phone || lead.lead_phone || destinationJid);
            if (!phone && !destinationJid) {
                await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped', error_message = 'Sem telefone' WHERE id = ?`, [lead.id]);
                continue;
            }
            // Step 0: Re-check current lead status against campaign filter before sending
            if (!isSyntheticDestination) {
                const eligibility = await this.recheckLeadEligibility(userId, String(lead.lead_id || ""), campaign);
                if (!eligibility.ok) {
                    await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped', error_message = ? WHERE id = ?`, [eligibility.reason || "Lead fora do filtro da campanha", lead.id]);
                    continue;
                }
            }
            // Step 1: Validate WhatsApp number
            let jid;
            if (destinationJid) {
                jid = destinationJid;
                await (0, database_1.update)(`UPDATE campaign_leads SET whatsapp_valid = TRUE, whatsapp_jid = ? WHERE id = ?`, [jid, lead.id]);
            }
            else {
                try {
                    const validation = await withTimeout(this.instanceManager.checkWhatsAppNumber(campaign.instance_id, phone), 15000, "Timeout na validacao WhatsApp");
                    if (!validation.exists) {
                        await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped', whatsapp_valid = FALSE, error_message = 'Numero sem WhatsApp' WHERE id = ?`, [lead.id]);
                        // Update the lead's source_details with validation result
                        await this.markLeadWhatsAppInvalid(userId, lead.lead_id);
                        continue;
                    }
                    jid = validation.jid;
                    await (0, database_1.update)(`UPDATE campaign_leads SET whatsapp_valid = TRUE, whatsapp_jid = ? WHERE id = ?`, [jid || null, lead.id]);
                }
                catch (err) {
                    logger_1.logger.warn(`[Campaign ${campaignId}] Validation failed for ${phone}: ${err.message}`);
                    if (isTransientInstanceConnectionError(err)) {
                        logger_1.logger.warn(`[Campaign ${campaignId}] Instance unavailable during validation; keeping queue pending for retry`);
                        break;
                    }
                    await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped', error_message = ? WHERE id = ?`, [`Erro validacao: ${err.message}`, lead.id]);
                    continue;
                }
            }
            // Step 2: Generate or use template message
            let messageText = campaign.message_template || "";
            if (useAI) {
                try {
                    const leadContext = {
                        id: lead.lead_id,
                        name: lead.lead_name || "Lead",
                        phone,
                        address: lead.lead_city || "",
                        category: lead.lead_category || "",
                        city: lead.lead_city || "",
                        state: lead.lead_state || "",
                        status: "new",
                        messagesSent: [],
                        messagesReceived: [],
                        createdAt: new Date(),
                    };
                    const campaignPrompt = this.buildCampaignFirstTouchPrompt(campaign, lead, campaignSettings);
                    const primaryInstruction = campaignPrompt || campaign.ai_prompt || campaign.message_template || "";
                    const contextualBlock = String(contextPayload?.contextBlock || "").trim();
                    // Build AI prompt with strict precedence to campaign instruction
                    const fullPrompt = [
                        "HIERARQUIA DE INSTRUCOES (OBRIGATORIA):",
                        "1) INSTRUCAO DA CAMPANHA (prioridade maxima, cumprir literalmente)",
                        "2) CONTEXTO COMPLEMENTAR (usar apenas para enriquecer sem contrariar a instrucao da campanha)",
                        "",
                        "REGRAS CRITICAS:",
                        "- Nunca invente nome de atendente, empresa, produto, oferta, volume ou condicao comercial.",
                        "- Se a instrucao da campanha definir nome do atendente (ex.: Elenice), use exatamente esse nome.",
                        "- Se a campanha indicar foco comercial/industrial/atacado, nao ofereca produto de varejo/menor volume.",
                        "",
                        `INSTRUCAO DA CAMPANHA:\n${primaryInstruction}`,
                        contextualBlock ? `CONTEXTO COMPLEMENTAR:\n${contextualBlock}` : "",
                    ]
                        .filter(Boolean)
                        .join("\n\n");
                    messageText = await this.gemini.generateMessage(leadContext, fullPrompt);
                }
                catch (err) {
                    logger_1.logger.warn(`[Campaign ${campaignId}] AI generation failed for ${lead.lead_name}: ${err.message}`);
                    // Fall back to template
                    messageText = this.fillTemplate(this.buildFallbackTemplate(campaign, campaignSettings), lead);
                }
            }
            else {
                messageText = this.fillTemplate(this.buildFallbackTemplate(campaign, campaignSettings), lead);
            }
            if (!messageText.trim()) {
                await (0, database_1.update)(`UPDATE campaign_leads SET status = 'skipped', error_message = 'Mensagem vazia' WHERE id = ?`, [lead.id]);
                continue;
            }
            // Step 3: Send message
            await (0, database_1.update)(`UPDATE campaign_leads SET status = 'sending', message_text = ?, ai_generated = ? WHERE id = ?`, [messageText, useAI ? true : false, lead.id]);
            try {
                const sendResult = await withTimeout(jid
                    ? (async () => {
                        const ok = await this.instanceManager.sendMessageByJid(campaign.instance_id, jid, messageText);
                        return {
                            ok,
                            instanceId: campaign.instance_id,
                            error: ok ? undefined : "Envio falhou",
                        };
                    })()
                    : campaign.use_instance_rotation && this.rotationEngine
                        ? this.rotationEngine.sendTextWithFailover({
                            userId,
                            phone,
                            message: messageText,
                            leadId: String(lead.lead_id || ""),
                            campaignId,
                            automationCode: "campaign_v2",
                            preferredInstanceId: campaign.instance_id,
                            maxAttempts: 3,
                        })
                        : (async () => {
                            const ok = await this.instanceManager.sendMessage(campaign.instance_id, phone, messageText);
                            return {
                                ok,
                                instanceId: campaign.instance_id,
                                error: ok ? undefined : "Envio falhou",
                            };
                        })(), 20000, "Timeout no envio da mensagem");
                const sent = sendResult.ok;
                const usedInstanceId = sendResult.instanceId || campaign.instance_id;
                if (sent) {
                    const tagsToAdd = ["campanha_disparada", "primeiro_contato_enviado", "aguardando_resposta"];
                    await (0, database_1.update)(`UPDATE campaign_leads
             SET status = 'sent',
                 sent_at = NOW(),
                 delivered_at = COALESCE(delivered_at, NOW()),
                 tags_added = ?,
                 attempt_count = attempt_count + 1
             WHERE id = ?`, [JSON.stringify(tagsToAdd), lead.id]);
                    // Update campaign counters
                    await (0, database_1.update)(`UPDATE campaign_history
             SET sent_count = sent_count + 1,
                 delivered_count = delivered_count + 1
             WHERE id = ?`, [campaignId]);
                    // Update lead status and tags in customers table
                    if (!isSyntheticDestination) {
                        await this.updateLeadAfterSend(userId, lead.lead_id, campaignId, tagsToAdd);
                        if (finalActions && (finalActions.nextStatus || (finalActions.addTags || []).length)) {
                            await this.applyFinalActionsAfterSend(userId, lead.lead_id, finalActions);
                        }
                        // Log message
                        await this.logMessage(userId, lead.lead_id, campaignId, usedInstanceId, phone, messageText, useAI);
                    }
                    sentThisRun++;
                    failedConsecutive = 0;
                    logger_1.logger.info(`[Campaign ${campaignId}] Sent ${sentThisRun} to ${lead.lead_name || phone}`);
                }
                else {
                    failedConsecutive++;
                    await (0, database_1.update)(`UPDATE campaign_leads SET status = 'failed', error_message = ?, attempt_count = attempt_count + 1 WHERE id = ?`, [sendResult.error || "Envio falhou", lead.id]);
                    await (0, database_1.update)(`UPDATE campaign_history SET failed_count = failed_count + 1 WHERE id = ?`, [campaignId]);
                }
            }
            catch (err) {
                failedConsecutive++;
                await (0, database_1.update)(`UPDATE campaign_leads SET status = 'failed', error_message = ?, attempt_count = attempt_count + 1 WHERE id = ?`, [err.message, lead.id]);
                await (0, database_1.update)(`UPDATE campaign_history SET failed_count = failed_count + 1 WHERE id = ?`, [campaignId]);
            }
            // Anti-blocking delay
            const delay = randomDelay(speed.minIntervalSeconds, speed.maxIntervalSeconds);
            await sleep(delay);
        }
        // Check if campaign completed
        if (this.activeCampaigns.get(campaignId)) {
            const remainingQueue = await this.getRunnableQueueCount(userId, campaignId, normalizedBrandId);
            if (remainingQueue > 0) {
                this.activeCampaigns.delete(campaignId);
                logger_1.logger.info(`[Campaign ${campaignId}] Execution ended with ${remainingQueue} leads still pending/ready`);
                return;
            }
            await (0, database_1.update)(`UPDATE campaign_history SET status = 'completed', completed_at = NOW() WHERE id = ? AND user_id = ? AND ${normalizedBrandId ? "brand_id = ?" : "brand_id IS NULL"} AND status = 'running'`, normalizedBrandId ? [campaignId, userId, normalizedBrandId] : [campaignId, userId]);
            this.activeCampaigns.delete(campaignId);
            logger_1.logger.info(`[Campaign ${campaignId}] Completed. Total sent: ${sentThisRun}`);
        }
    }
    // ─── Post-send updates ─────────────────────────────────────────
    async updateLeadAfterSend(userId, leadId, campaignId, tagsToAdd) {
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const fields = [];
        const values = [];
        // Update status to "contacted"
        if (cols.has("status")) {
            fields.push("status = 'contacted'");
        }
        // Update last_contact_at
        if (cols.has("last_contact_at")) {
            fields.push("last_contact_at = NOW()");
        }
        // Add tags
        if (cols.has("tags")) {
            const currentLead = await (0, database_1.queryOne)(`SELECT tags FROM customers WHERE id = ? LIMIT 1`, [leadId]);
            const currentTags = parseJsonArray(currentLead?.tags);
            const allTags = [...new Set([...currentTags, ...tagsToAdd, `campanha_${campaignId.substring(0, 8)}`])];
            fields.push("tags = ?");
            values.push(JSON.stringify(allTags));
        }
        if (!fields.length)
            return;
        let sql = `UPDATE customers SET ${fields.join(", ")} WHERE id = ?`;
        values.push(leadId);
        if (ownerCol) {
            sql += ` AND ${ownerCol} = ?`;
            values.push(userId);
        }
        await (0, database_1.update)(sql, values);
    }
    async recheckLeadEligibility(userId, leadId, campaign) {
        if (!leadId) {
            return { ok: false, reason: "Lead sem identificacao" };
        }
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const statusCol = cols.has("status") ? "status" : "'new' AS status";
        let sql = `SELECT ${statusCol} FROM customers WHERE id = ?`;
        const params = [leadId];
        if (ownerCol) {
            sql += ` AND ${ownerCol} = ?`;
            params.push(userId);
        }
        if (cols.has("brand_id")) {
            if (campaign.brand_id) {
                sql += " AND brand_id = ?";
                params.push(campaign.brand_id);
            }
            else {
                sql += " AND brand_id IS NULL";
            }
        }
        sql += " LIMIT 1";
        const row = await (0, database_1.queryOne)(sql, params);
        if (!row) {
            return { ok: false, reason: "Lead nao encontrado para esta brand" };
        }
        const campaignFilter = normalizeCampaignFilterInput(campaign.filter_json || {});
        const requiredStatuses = normalizeStatusFilterInput(campaignFilter.statuses);
        const allowedStatuses = new Set(requiredStatuses.length ? requiredStatuses : ["new"]);
        const currentStatus = normalizeLeadStatusValue(row.status || "new");
        if (!allowedStatuses.has(currentStatus)) {
            return {
                ok: false,
                reason: `Status atual (${currentStatus || "desconhecido"}) fora do filtro da campanha`,
            };
        }
        return { ok: true };
    }
    async applyFinalActionsAfterSend(userId, leadId, actions) {
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const fields = [];
        const values = [];
        const nextStatus = String(actions.nextStatus || "").trim();
        if (nextStatus && cols.has("status")) {
            fields.push("status = ?");
            values.push(nextStatus);
        }
        const addTags = parseTagList(actions.addTags);
        if (addTags.length && cols.has("tags")) {
            const currentLead = await (0, database_1.queryOne)(`SELECT tags FROM customers WHERE id = ? LIMIT 1`, [leadId]);
            const currentTags = parseJsonArray(currentLead?.tags);
            const mergedTags = [...new Set([...currentTags, ...addTags])];
            fields.push("tags = ?");
            values.push(JSON.stringify(mergedTags));
        }
        if (!fields.length)
            return;
        let sql = `UPDATE customers SET ${fields.join(", ")} WHERE id = ?`;
        values.push(leadId);
        if (ownerCol) {
            sql += ` AND ${ownerCol} = ?`;
            values.push(userId);
        }
        await (0, database_1.update)(sql, values);
    }
    async markLeadWhatsAppInvalid(userId, leadId) {
        const cols = await this.getCustomerColumns();
        if (!cols.has("source_details"))
            return;
        const row = await (0, database_1.queryOne)(`SELECT source_details FROM customers WHERE id = ? LIMIT 1`, [leadId]);
        const details = parseJsonSafe(row?.source_details);
        details.whatsapp_validation = {
            ...(details.whatsapp_validation || {}),
            has_whatsapp: false,
            status: "invalid",
            checked_at: new Date().toISOString(),
        };
        const ownerCol = await this.getOwnerColumn();
        let sql = `UPDATE customers SET source_details = ? WHERE id = ?`;
        const params = [JSON.stringify(details), leadId];
        if (ownerCol) {
            sql += ` AND ${ownerCol} = ?`;
            params.push(userId);
        }
        await (0, database_1.update)(sql, params);
    }
    async logMessage(userId, leadId, campaignId, instanceId, phone, content, aiGenerated) {
        try {
            await (0, database_1.query)(`INSERT INTO message_log (id, user_id, client_id, campaign_id, instance_id, phone, direction, message_type, content, status, ai_generated, sent_at)
         VALUES (?, ?, ?, ?, ?, ?, 'outbound', 'text', ?, 'sent', ?, NOW())`, [(0, crypto_1.randomUUID)(), userId, leadId, campaignId, instanceId, phone, content, aiGenerated ? true : false]);
        }
        catch (err) {
            logger_1.logger.debug?.(`Message log insert failed: ${err.message}`);
        }
    }
    // ─── Response processing ───────────────────────────────────────
    async processIncomingReply(userId, phone, messageText, timestamp, brandId) {
        const normalizedBrandId = String(brandId || "").trim();
        await this.ensureSchema();
        const normalizedPhone = normalizePhone(phone);
        if (!normalizedPhone)
            return null;
        const phoneCandidates = Array.from(new Set([
            normalizedPhone,
            normalizedPhone.length > 13 ? normalizedPhone.slice(-13) : "",
            normalizedPhone.length > 11 ? normalizedPhone.slice(-11) : "",
            normalizedPhone.length > 10 ? normalizedPhone.slice(-10) : "",
        ].filter((value) => value.length >= 8)));
        const phonePlaceholders = phoneCandidates.map(() => "?").join(", ");
        const findLatestReplyCandidate = async (forceCrossBrand) => {
            const whereBrand = forceCrossBrand
                ? ""
                : normalizedBrandId
                    ? " AND cl.brand_id = ?"
                    : " AND cl.brand_id IS NULL";
            const sql = `SELECT cl.*, ch.id AS campaign_id, ch.ai_prompt
                   FROM campaign_leads cl
                   JOIN campaign_history ch ON ch.id = cl.campaign_id
                   WHERE cl.user_id = ?
                     AND cl.phone IN (${phonePlaceholders})
                     AND cl.status IN ('sent','delivered','read','replied','opted_out')
                     ${whereBrand}
                   ORDER BY
                     CASE WHEN cl.phone = ? THEN 0 ELSE 1 END,
                     COALESCE(cl.replied_at, cl.read_at, cl.delivered_at, cl.sent_at, cl.updated_at, cl.created_at) DESC
                   LIMIT 1`;
            const params = [userId, ...phoneCandidates];
            if (!forceCrossBrand && normalizedBrandId)
                params.push(normalizedBrandId);
            params.push(normalizedPhone);
            return (0, database_1.queryOne)(sql, params);
        };
        let campaignLead = await findLatestReplyCandidate(false);
        if (!campaignLead && normalizedBrandId) {
            campaignLead = await findLatestReplyCandidate(true);
        }
        if (!campaignLead)
            return null;
        // Classify the response
        const classification = this.classifyResponse(messageText);
        const scoreDelta = this.getScoreDelta(classification);
        const previousStatus = String(campaignLead.status || "").trim().toLowerCase();
        const previousClassification = String(campaignLead.reply_classification || "").trim();
        const wasAlreadyReplied = previousStatus === "replied";
        // Update campaign_lead
        await (0, database_1.update)(`UPDATE campaign_leads
       SET status = 'replied',
           replied_at = COALESCE(replied_at, NOW()),
           read_at = COALESCE(read_at, NOW()),
           delivered_at = COALESCE(delivered_at, NOW()),
           reply_text = ?,
           reply_classification = ?,
           score_delta = ?
       WHERE id = ?`, [messageText, classification, scoreDelta, campaignLead.id]);
        // Update campaign counters
        const classificationDelta = {
            interested: 0,
            neutral: 0,
            negative: 0,
            optedOut: 0,
        };
        if (wasAlreadyReplied) {
            if (previousClassification && previousClassification !== classification) {
                if (previousClassification === "interested")
                    classificationDelta.interested -= 1;
                if (previousClassification === "neutral")
                    classificationDelta.neutral -= 1;
                if (previousClassification === "negative")
                    classificationDelta.negative -= 1;
                if (previousClassification === "opt_out")
                    classificationDelta.optedOut -= 1;
                if (classification === "interested")
                    classificationDelta.interested += 1;
                if (classification === "neutral")
                    classificationDelta.neutral += 1;
                if (classification === "negative")
                    classificationDelta.negative += 1;
                if (classification === "opt_out")
                    classificationDelta.optedOut += 1;
            }
        }
        else {
            if (classification === "interested")
                classificationDelta.interested = 1;
            if (classification === "neutral")
                classificationDelta.neutral = 1;
            if (classification === "negative")
                classificationDelta.negative = 1;
            if (classification === "opt_out")
                classificationDelta.optedOut = 1;
        }
        const repliedDelta = wasAlreadyReplied ? 0 : 1;
        const readDelta = !wasAlreadyReplied && (previousStatus === "sent" || previousStatus === "delivered") ? 1 : 0;
        const campaignBrandId = String(campaignLead.brand_id || "").trim();
        await (0, database_1.update)(`UPDATE campaign_history
       SET replied_count = GREATEST(0, replied_count + ?),
           read_count = GREATEST(0, read_count + ?),
           interested_count = GREATEST(0, interested_count + ?),
           neutral_count = GREATEST(0, neutral_count + ?),
           negative_count = GREATEST(0, negative_count + ?),
           opted_out_count = GREATEST(0, opted_out_count + ?)
       WHERE id = ? AND user_id = ? AND ${campaignBrandId ? "brand_id = ?" : "brand_id IS NULL"}`, campaignBrandId
            ? [
                repliedDelta,
                readDelta,
                classificationDelta.interested,
                classificationDelta.neutral,
                classificationDelta.negative,
                classificationDelta.optedOut,
                campaignLead.campaign_id,
                userId,
                campaignBrandId,
            ]
            : [
                repliedDelta,
                readDelta,
                classificationDelta.interested,
                classificationDelta.neutral,
                classificationDelta.negative,
                classificationDelta.optedOut,
                campaignLead.campaign_id,
                userId,
            ]);
        // Update lead tags and score
        await this.updateLeadAfterReply(userId, campaignLead.lead_id, classification, scoreDelta);
        return {
            campaignId: campaignLead.campaign_id,
            classification,
            scoreDelta,
        };
    }
    // ─── Response classification ───────────────────────────────────
    classifyResponse(text) {
        const lower = text.toLowerCase().trim();
        // Opt-out signals
        const optOutPatterns = [
            "nao quero", "para de", "pare de", "nao me", "sair", "remover",
            "cancelar", "desinscrever", "nao tenho interesse", "nao preciso",
            "nao envie mais", "bloquear", "parar", "nao mande mais",
            "spam", "chega", "nao incomode", "me tire", "tire meu numero",
        ];
        if (optOutPatterns.some(p => lower.includes(p)))
            return "opt_out";
        // Negative signals
        const negativePatterns = [
            "nao obrigado", "sem interesse", "nao no momento", "agora nao",
            "nao estou", "estou satisfeito", "ja tenho", "nao preciso",
            "talvez depois", "nao e comigo", "numero errado",
        ];
        if (negativePatterns.some(p => lower.includes(p)))
            return "negative";
        // Interested signals
        const interestedPatterns = [
            "quero", "interesse", "sim", "manda", "envia", "quanto custa",
            "qual o preco", "qual valor", "como funciona", "me conta",
            "pode me", "quero saber", "gostaria", "tenho interesse",
            "falar mais", "mais detalhe", "mais informac", "pode explicar",
            "vamos conversar", "quero ver", "me fala", "whatsapp",
            "liga", "ligar", "agenda", "marcar", "horario", "disponivel",
            "preco", "valor", "orcamento", "proposta", "quando posso",
        ];
        if (interestedPatterns.some(p => lower.includes(p)))
            return "interested";
        // Short positive responses
        if (["sim", "ok", "pode ser", "opa", "bom dia", "boa tarde", "boa noite", "oi", "ola"].includes(lower)) {
            return "interested";
        }
        return "neutral";
    }
    getScoreDelta(classification) {
        switch (classification) {
            case "interested": return 30;
            case "neutral": return 5;
            case "negative": return -15;
            case "opt_out": return -50;
        }
    }
    async updateLeadAfterReply(userId, leadId, classification, scoreDelta) {
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const fields = [];
        const values = [];
        // Tags based on classification
        const tagsToAdd = ["respondeu"];
        let newStatus = null;
        switch (classification) {
            case "interested":
                tagsToAdd.push("interessado", "lead_quente");
                newStatus = "replied";
                break;
            case "neutral":
                tagsToAdd.push("lead_morno");
                break;
            case "negative":
                tagsToAdd.push("sem_interesse");
                newStatus = "lost";
                break;
            case "opt_out":
                tagsToAdd.push("opt_out", "bloqueado");
                newStatus = "lost";
                break;
        }
        // Remove aguardando_resposta tag, add new tags
        if (cols.has("tags")) {
            const currentLead = await (0, database_1.queryOne)(`SELECT tags FROM customers WHERE id = ? LIMIT 1`, [leadId]);
            const currentTags = parseJsonArray(currentLead?.tags);
            const filteredTags = currentTags.filter(t => t.toLowerCase() !== "aguardando_resposta");
            const allTags = [...new Set([...filteredTags, ...tagsToAdd])];
            fields.push("tags = ?");
            values.push(JSON.stringify(allTags));
        }
        // Update status
        if (newStatus && cols.has("status")) {
            fields.push("status = ?");
            values.push(newStatus);
        }
        // Update score
        if (cols.has("lead_score")) {
            fields.push("lead_score = GREATEST(0, lead_score + ?)");
            values.push(scoreDelta);
        }
        // Update last_contact_at
        if (cols.has("last_contact_at")) {
            fields.push("last_contact_at = NOW()");
        }
        if (!fields.length)
            return;
        let sql = `UPDATE customers SET ${fields.join(", ")} WHERE id = ?`;
        values.push(leadId);
        if (ownerCol) {
            sql += ` AND ${ownerCol} = ?`;
            values.push(userId);
        }
        await (0, database_1.update)(sql, values);
    }
    // ─── Template filling ──────────────────────────────────────────
    fillTemplate(template, lead) {
        const values = {
            nome: String(lead.lead_name || lead.name || "").trim() || "Prezado(a)",
            telefone: normalizePhone(lead.phone || lead.lead_phone),
            cidade: String(lead.lead_city || lead.city || "sua cidade").trim(),
            estado: String(lead.lead_state || lead.state || "").trim(),
            segmento: String(lead.lead_category || lead.category || "seu segmento").trim(),
            categoria: String(lead.lead_category || lead.category || "").trim(),
        };
        return template.replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_, key) => values[key.toLowerCase()] || "");
    }
    hashSeed(input) {
        let hash = 0;
        for (let i = 0; i < input.length; i++) {
            hash = (hash * 31 + input.charCodeAt(i)) >>> 0;
        }
        return hash;
    }
    resolveCampaignModeDirective(mode) {
        const normalized = String(mode || "educational").trim().toLowerCase();
        if (normalized === "aggressive") {
            return "Tom comercial direto, objetivo e orientado a conversao, sem ser rude.";
        }
        if (normalized === "relationship") {
            return "Tom consultivo, humano e de relacionamento, priorizando dialogo e confianca.";
        }
        return "Tom educativo, util e objetivo, ajudando o lead a entender valor antes da oferta.";
    }
    buildCampaignFirstTouchPrompt(campaign, lead, campaignSettings) {
        const composer = parseJsonSafe(campaignSettings?.composer || {});
        const triggers = parseJsonSafe(campaignSettings?.triggers || {});
        const intentText = String(composer.intentText || "").trim();
        const baseInstruction = String(campaign.ai_prompt || campaign.message_template || "").trim();
        const personalized = composer.personalizedPerLead !== false;
        const autoVariations = composer.useAutoVariations !== false;
        const isInitialTrigger = Boolean(triggers?.onNewLead ?? true);
        const seed = String(lead?.lead_id || lead?.id || lead?.phone || lead?.lead_phone || campaign.id || "seed");
        const variationIndex = (this.hashSeed(seed) % 3) + 1;
        const leadName = String(lead?.lead_name || lead?.name || "Lead").trim() || "Lead";
        const leadCity = String(lead?.lead_city || lead?.city || "").trim();
        const leadCategory = String(lead?.lead_category || lead?.category || "").trim();
        const objective = intentText || baseInstruction || "Executar primeiro contato comercial com contexto real da campanha.";
        const strictContext = [baseInstruction, intentText].filter(Boolean).join("\n\n");
        const personalizationLine = personalized
            ? `Personalize para este lead quando houver dado real: nome=${leadName}; cidade=${leadCity || "nao informada"}; segmento=${leadCategory || "nao informado"}.`
            : "Nao personalize por lead; use mensagem padronizada consistente para toda a campanha.";
        const variationLine = autoVariations
            ? `Use variacao numero ${variationIndex} (de 3) para evitar repeticao, mantendo o mesmo objetivo.`
            : "Use versao unica e consistente (sem variacoes entre leads).";
        return [
            `OBJETIVO DA CAMPANHA: ${objective}`,
            `MODO DA CAMPANHA: ${this.resolveCampaignModeDirective(campaign.campaign_mode)}`,
            isInitialTrigger
                ? "CONTEXTO DE DISPARO: Esta e uma mensagem inicial de primeiro contato da campanha."
                : "CONTEXTO DE DISPARO: Respeite o gatilho configurado para este envio.",
            "REGRAS OBRIGATORIAS:",
            "- Nao invente fatos, nomes, produtos, promocoes ou condicoes que nao estejam no contexto.",
            "- Nao se apresente com nome proprio se o nome do atendente nao estiver explicitamente definido no contexto base.",
            "- Se o contexto base definir o nome do atendente, use exatamente esse nome, sem trocar.",
            "- Se o contexto base indicar foco comercial/industrial/atacado, priorize volumes comerciais e evite oferta de menor volume/varejo.",
            "- Nao mude o objetivo definido pela composicao da campanha.",
            "- Mensagem curta, clara e coerente com o contexto, com CTA simples no final.",
            personalizationLine,
            variationLine,
            strictContext ? `CONTEXTO BASE DA COMPOSICAO:\n${strictContext}` : "",
        ]
            .filter(Boolean)
            .join("\n\n");
    }
    buildFallbackTemplate(campaign, campaignSettings) {
        const explicitTemplate = String(campaign.message_template || "").trim();
        if (explicitTemplate)
            return explicitTemplate;
        const composer = parseJsonSafe(campaignSettings?.composer || {});
        const intentText = String(composer.intentText || "").trim();
        if (intentText) {
            return `Oi {{nome}}, tudo bem? ${intentText} Podemos falar rapidamente?`;
        }
        const aiPrompt = String(campaign.ai_prompt || "").trim();
        if (aiPrompt)
            return aiPrompt;
        return "Oi {{nome}}, tudo bem? Quero te apresentar uma proposta rapida que pode ajudar seu negocio. Podemos falar?";
    }
    // ─── Map helpers ───────────────────────────────────────────────
    mapCampaign(row) {
        return {
            id: String(row.id),
            user_id: String(row.user_id),
            brand_id: row.brand_id ? String(row.brand_id) : null,
            company_id: row.company_id || null,
            instance_id: String(row.instance_id || ""),
            name: String(row.name || ""),
            message_template: row.message_template || null,
            ai_prompt: row.ai_prompt || null,
            use_ai: Number(row.use_ai || 0) === 1,
            filter_json: parseJsonSafe(row.filter_json),
            speed_json: { ...DEFAULT_SPEED, ...parseJsonSafe(row.speed_json) },
            campaign_mode: String(row.campaign_mode || "educational"),
            settings: parseJsonSafe(row.settings),
            use_instance_rotation: Number(row.use_instance_rotation || 0) === 1,
            rotation_mode: String(row.rotation_mode || "balanced") || "balanced",
            target_count: Number(row.target_count || 0),
            sent_count: Number(row.sent_count || 0),
            delivered_count: Number(row.delivered_count || 0),
            read_count: Number(row.read_count || 0),
            replied_count: Number(row.replied_count || 0),
            failed_count: Number(row.failed_count || 0),
            interested_count: Number(row.interested_count || 0),
            neutral_count: Number(row.neutral_count || 0),
            negative_count: Number(row.negative_count || 0),
            opted_out_count: Number(row.opted_out_count || 0),
            status: String(row.status || "draft"),
            scheduled_at: row.scheduled_at ? new Date(row.scheduled_at).toISOString() : null,
            started_at: row.started_at ? new Date(row.started_at).toISOString() : null,
            completed_at: row.completed_at ? new Date(row.completed_at).toISOString() : null,
            created_at: new Date(row.created_at || Date.now()).toISOString(),
            updated_at: new Date(row.updated_at || Date.now()).toISOString(),
        };
    }
    mapCampaignLead(row) {
        return {
            id: String(row.id),
            campaign_id: String(row.campaign_id),
            lead_id: String(row.lead_id),
            phone: String(row.phone || ""),
            whatsapp_valid: toNullableBoolean(row.whatsapp_valid),
            whatsapp_jid: row.whatsapp_jid || null,
            message_text: row.message_text || null,
            ai_generated: Number(row.ai_generated || 0) === 1,
            status: String(row.status || "pending"),
            sent_at: row.sent_at ? new Date(row.sent_at).toISOString() : null,
            replied_at: row.replied_at ? new Date(row.replied_at).toISOString() : null,
            reply_text: row.reply_text || null,
            reply_classification: row.reply_classification || null,
            score_delta: Number(row.score_delta || 0),
            tags_added: parseJsonArray(row.tags_added),
            error_message: row.error_message || null,
            attempt_count: Number(row.attempt_count || 0),
            lead_name: row.lead_name || undefined,
            lead_city: row.lead_city || undefined,
            lead_category: row.lead_category || undefined,
        };
    }
    // ─── Preview (dry-run) ─────────────────────────────────────────
    async previewCampaign(userId, filter, brandId) {
        const allLeads = await this.filterLeadsByBrand(userId, filter, brandId);
        const mapped = allLeads.slice(0, 100).map(lead => ({
            id: String(lead.id),
            name: String(lead.name || ""),
            phone: String(lead.phone || ""),
            city: String(lead.city || ""),
            category: String(lead.category || ""),
            tags: parseJsonArray(lead.tags),
        }));
        return { count: allLeads.length, leads: mapped };
    }
    // ─── Check for scheduled campaigns ─────────────────────────────
    async processScheduledCampaigns() {
        await this.ensureSchema();
        const due = await (0, database_1.query)(`SELECT id, user_id, brand_id FROM campaign_history
       WHERE status = 'scheduled' AND scheduled_at <= NOW()
       ORDER BY scheduled_at ASC LIMIT 5`);
        for (const row of due) {
            logger_1.logger.info(`[Scheduler] Starting scheduled campaign ${row.id}`);
            await this.startCampaign(row.user_id, row.id, row.brand_id || null);
        }
    }
    async resumeRunningCampaigns() {
        await this.ensureSchema();
        const runningRows = await (0, database_1.query)(`SELECT id, user_id, brand_id
       FROM campaign_history
       WHERE status = 'running'
       ORDER BY started_at DESC
       LIMIT 30`);
        for (const row of runningRows) {
            const campaignId = String(row.id || "").trim();
            const userId = String(row.user_id || "").trim();
            const brandId = String(row.brand_id || "").trim() || null;
            if (!campaignId || !userId)
                continue;
            if (this.activeCampaigns.get(campaignId))
                continue;
            const campaign = await this.getCampaign(userId, campaignId, brandId);
            if (!campaign)
                continue;
            const queueCount = await this.ensureCampaignQueueReady(userId, campaign, brandId);
            if (queueCount <= 0)
                continue;
            this.activeCampaigns.set(campaignId, true);
            this.executeCampaign(userId, campaignId, brandId).catch((err) => {
                logger_1.logger.error(`Campaign ${campaignId} auto-resume failed: ${err.message}`);
            });
            logger_1.logger.info(`[Scheduler] Resumed running campaign ${campaignId} with ${queueCount} pending leads`);
        }
    }
    isCampaignActive(campaignId) {
        return this.activeCampaigns.get(campaignId) === true;
    }
    async filterLeadsByBrand(userId, filter, brandId) {
        await this.ensureSchema();
        const cols = await this.getCustomerColumns();
        const ownerCol = await this.getOwnerColumn();
        const normalizedBrandId = String(brandId || "").trim();
        const conditions = [];
        const params = [];
        if (ownerCol) {
            conditions.push(`${ownerCol} = ?`);
            params.push(userId);
        }
        if (cols.has("brand_id")) {
            if (normalizedBrandId) {
                conditions.push("brand_id = ?");
                params.push(normalizedBrandId);
            }
            else {
                conditions.push("brand_id IS NULL");
            }
        }
        if (cols.has("phone")) {
            conditions.push(`phone IS NOT NULL AND TRIM(phone) != ''`);
        }
        if (filter.statuses?.length) {
            const expandedStatuses = expandStatusFilterVariants(filter.statuses);
            if (expandedStatuses.length > 0) {
                const placeholders = expandedStatuses.map(() => "?").join(",");
                conditions.push(`LOWER(TRIM(COALESCE(status, ''))) IN (${placeholders})`);
                params.push(...expandedStatuses);
            }
        }
        if (filter.cities?.length) {
            const cityCol = cols.has("city") ? "city" : cols.has("address_city") ? "address_city" : null;
            if (cityCol) {
                const placeholders = filter.cities.map(() => "?").join(",");
                conditions.push(`${cityCol} IN (${placeholders})`);
                params.push(...filter.cities);
            }
        }
        if (filter.sources?.length && cols.has("source")) {
            const placeholders = filter.sources.map(() => "?").join(",");
            conditions.push(`source IN (${placeholders})`);
            params.push(...filter.sources);
        }
        if (cols.has("lead_score")) {
            if (typeof filter.scoreMin === "number") {
                conditions.push("lead_score >= ?");
                params.push(filter.scoreMin);
            }
            if (typeof filter.scoreMax === "number") {
                conditions.push("lead_score <= ?");
                params.push(filter.scoreMax);
            }
        }
        if (filter.segments?.length && cols.has("category")) {
            const placeholders = filter.segments.map(() => "?").join(",");
            conditions.push(`category IN (${placeholders})`);
            params.push(...filter.segments);
        }
        const where = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
        const selectCols = [
            "id", "name", "phone",
            cols.has("status") ? "status" : "'new' AS status",
            cols.has("tags") ? "tags" : "NULL AS tags",
            cols.has("city") ? "city" : cols.has("address_city") ? "address_city AS city" : "NULL AS city",
            cols.has("state") ? "state" : "NULL AS state",
            cols.has("category") ? "category" : "NULL AS category",
            cols.has("lead_score") ? "lead_score" : "0 AS lead_score",
            cols.has("source") ? "source" : "'manual' AS source",
            cols.has("source_details") ? "source_details" : "NULL AS source_details",
        ].join(", ");
        let leads = await (0, database_1.query)(`SELECT ${selectCols} FROM customers ${where} ORDER BY id ASC`, params);
        if (filter.tagsInclude?.length) {
            leads = leads.filter(lead => {
                const tags = parseJsonArray(lead.tags);
                const tagsLower = new Set(tags.map(t => t.toLowerCase()));
                return filter.tagsInclude.some(tag => tagsLower.has(tag.toLowerCase()));
            });
        }
        if (filter.tagsExclude?.length) {
            leads = leads.filter(lead => {
                const tags = parseJsonArray(lead.tags);
                const tagsLower = new Set(tags.map(t => t.toLowerCase()));
                return !filter.tagsExclude.some(tag => tagsLower.has(tag.toLowerCase()));
            });
        }
        if (filter.hasWhatsapp === true) {
            leads = leads.filter(lead => {
                const details = parseJsonSafe(lead.source_details);
                const validation = details?.whatsapp_validation || {};
                return validation?.has_whatsapp === true || isTruthyFlag(lead.whatsapp_valid);
            });
        }
        leads = leads.filter(lead => {
            const tags = parseJsonArray(lead.tags);
            const tagsLower = new Set(tags.map(t => t.toLowerCase()));
            return !tagsLower.has("opt_out") && !tagsLower.has("bloqueado");
        });
        return leads;
    }
}
exports.CampaignEngineService = CampaignEngineService;
//# sourceMappingURL=campaignEngine.js.map