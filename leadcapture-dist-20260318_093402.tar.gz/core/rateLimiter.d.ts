export declare class RateLimiter {
    private timestamps;
    private maxPerMinute;
    private maxPerDay;
    private dailyCounts;
    constructor(maxPerMinute?: number, maxPerDay?: number);
    canSend(instanceId: string): boolean;
    recordSend(instanceId: string): void;
    getStatus(instanceId: string): {
        minuteCount: number;
        dailyCount: number;
        canSend: boolean;
    };
}
//# sourceMappingURL=rateLimiter.d.ts.map