import { Router } from "express";
import { CampaignEngineService } from "../services/campaignEngine";
import { InstanceManager } from "../core/instanceManager";
import { InstanceRotationService } from "../services/instanceRotation";
export declare function createCampaignRoutes(instanceManager: InstanceManager, rotationEngine?: InstanceRotationService, campaignEngine?: CampaignEngineService): Router;
export default createCampaignRoutes;
//# sourceMappingURL=campaigns.d.ts.map