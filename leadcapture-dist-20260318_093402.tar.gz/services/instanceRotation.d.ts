import { InstanceManager } from "../core/instanceManager";
export type RotationMode = "balanced" | "conservative" | "aggressive";
type RotationSettings = {
    user_id: string;
    enabled: boolean;
    mode: RotationMode;
    health_min: number;
    risk_max: number;
    global_slowdown_factor: number;
    block_threshold_24h: number;
};
type Candidate = {
    instanceId: string;
    status: string;
    healthScore: number;
    riskScore: number;
    dailyLimit: number;
    hourlyLimit: number;
    perMinuteLimit: number;
    sentToday: number;
    sentLastHour: number;
    sentLastMinute: number;
    failedLastHour: number;
    lastUsedAt: string | null;
    minIntervalSeconds: number;
    secondsSinceLastUse: number;
    priorityWeight: number;
    eligible: boolean;
    reason?: string;
};
export type RotationPoolItem = Candidate & {
    selected: boolean;
};
export type RotationPoolSnapshot = {
    settings: RotationSettings;
    items: RotationPoolItem[];
};
type SelectOptions = {
    leadId?: string;
    preferredInstanceId?: string;
    excludedInstanceIds?: string[];
};
type SendOptions = {
    userId: string;
    phone: string;
    message: string;
    leadId?: string;
    campaignId?: string;
    automationCode?: string;
    preferredInstanceId?: string;
    maxAttempts?: number;
};
type SendResult = {
    ok: boolean;
    instanceId?: string;
    error?: string;
};
export declare class InstanceRotationService {
    private readonly instanceManager;
    private schemaReady;
    constructor(instanceManager: InstanceManager);
    private ensureSchema;
    private modeDefaults;
    private ensureSettings;
    private ensurePoolForConnectedInstances;
    getSettings(userId: string): Promise<RotationSettings>;
    updateSettings(userId: string, patch: Partial<Pick<RotationSettings, "enabled" | "mode" | "health_min" | "risk_max" | "global_slowdown_factor" | "block_threshold_24h">>): Promise<RotationSettings>;
    private getPoolRows;
    private getAffinityInstance;
    private setAffinity;
    recordSendMetric(input: {
        userId: string;
        instanceId: string;
        leadId?: string;
        campaignId?: string;
        automationCode?: string;
        status: "sent" | "failed" | "blocked";
        errorCode?: string;
        responseTimeSeconds?: number;
    }): Promise<void>;
    private candidateMetrics;
    private calcHealthRisk;
    private candidateScore;
    private applyGlobalRiskThrottle;
    getPoolSnapshot(userId: string, leadId?: string): Promise<RotationPoolSnapshot>;
    selectInstance(userId: string, options?: SelectOptions): Promise<string | null>;
    private buildPhoneCandidates;
    sendTextWithFailover(input: SendOptions): Promise<SendResult>;
}
export {};
//# sourceMappingURL=instanceRotation.d.ts.map