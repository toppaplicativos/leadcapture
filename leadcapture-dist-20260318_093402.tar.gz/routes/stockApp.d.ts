declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=stockApp.d.ts.map