"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.attachBrandContext = attachBrandContext;
exports.requireBrandContext = requireBrandContext;
const brandUnits_1 = require("../services/brandUnits");
const brandUnitsService = new brandUnits_1.BrandUnitsService();
function getRequestedBrandId(req) {
    const fromHeader = String(req.headers["x-brand-id"] || "").trim();
    if (fromHeader)
        return fromHeader;
    const fromQuery = String(req.query?.brand_id || "").trim();
    if (fromQuery)
        return fromQuery;
    const body = (req.body || {});
    const fromBody = String(body.brand_id || body.brandId || "").trim();
    if (fromBody)
        return fromBody;
    return null;
}
async function attachBrandContext(req, res, next) {
    try {
        const userId = (req.user?.userId || req.userId);
        if (!userId) {
            res.status(401).json({ error: "Unauthorized" });
            return;
        }
        const requestedBrandId = getRequestedBrandId(req);
        req.brandId = await brandUnitsService.resolveActiveBrandId(userId, requestedBrandId);
        next();
    }
    catch (error) {
        res.status(400).json({ error: error.message || "Invalid brand context" });
    }
}
async function requireBrandContext(req, res, next) {
    await attachBrandContext(req, res, async () => {
        if (!req.brandId) {
            res.status(400).json({ error: "brand_id is required. Create a Brand Unit first." });
            return;
        }
        next();
    });
}
//# sourceMappingURL=brandContext.js.map