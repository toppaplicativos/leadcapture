export type MovementType = "entrada" | "saida" | "ajuste" | "reserva" | "liberacao" | "expedicao";
export type MovementSource = "pedido" | "manual" | "devolucao" | "inventario" | "perda" | "avaria" | "correcao" | "reposicao" | "sistema";
export type StockStatus = "normal" | "baixo" | "zerado";
export interface InventoryRecord {
    id: string;
    product_id: string;
    user_id: string;
    brand_id: string | null;
    stock_current: number;
    stock_reserved: number;
    stock_available: number;
    stock_min: number;
    cost_price: number;
    created_at: string;
    updated_at: string;
}
export interface InventoryMovement {
    id: string;
    product_id: string;
    user_id: string;
    brand_id: string | null;
    type: MovementType;
    quantity: number;
    source: MovementSource;
    reference_id: string | null;
    reason: string | null;
    created_by: string | null;
    created_at: string;
}
export interface StockProduct extends InventoryRecord {
    product_name: string;
    product_sku: string | null;
    product_price: number;
    product_image: string | null;
    product_unit: string;
    product_type: string;
    status: StockStatus;
}
export declare class InventoryService {
    private schemaReady;
    private schemaPromise;
    ensureSchema(): Promise<void>;
    private computeStatus;
    private getOrCreateInventory;
    private recordMovement;
    getOverview(userId: string, brandId: string | null): Promise<Record<string, any>>;
    listStock(userId: string, brandId: string | null, filters?: {
        status?: StockStatus;
        search?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: StockProduct[];
        total: number;
    }>;
    getProductStock(userId: string, brandId: string | null, productId: string): Promise<StockProduct | null>;
    addStock(userId: string, brandId: string | null, productId: string, quantity: number, source?: MovementSource, reason?: string, createdBy?: string, referenceId?: string): Promise<InventoryRecord>;
    removeStock(userId: string, brandId: string | null, productId: string, quantity: number, source?: MovementSource, reason?: string, createdBy?: string, referenceId?: string): Promise<InventoryRecord>;
    adjustStock(userId: string, brandId: string | null, productId: string, newQuantity: number, reason: string, createdBy?: string): Promise<InventoryRecord>;
    reserveStock(userId: string, brandId: string | null, productId: string, quantity: number, orderId: string): Promise<InventoryRecord>;
    releaseStock(userId: string, brandId: string | null, productId: string, quantity: number, orderId: string): Promise<InventoryRecord>;
    confirmStockDeduction(userId: string, brandId: string | null, productId: string, quantity: number, orderId: string): Promise<InventoryRecord>;
    registerExpedition(userId: string, brandId: string | null, orderId: string, createdBy?: string): Promise<{
        movements: InventoryMovement[];
    }>;
    listMovements(userId: string, brandId: string | null, filters?: {
        productId?: string;
        type?: MovementType;
        source?: string;
        dateFrom?: string;
        dateTo?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        items: any[];
        total: number;
    }>;
    getProductHistory(userId: string, brandId: string | null, productId: string, limit?: number): Promise<any[]>;
    getAlerts(userId: string, brandId: string | null): Promise<any[]>;
    getAnalytics(userId: string, brandId: string | null): Promise<Record<string, any>>;
    getReports(userId: string, brandId: string | null, dateFrom?: string, dateTo?: string): Promise<Record<string, any>>;
    listExpeditions(userId: string, brandId: string | null, filters?: {
        page?: number;
        limit?: number;
    }): Promise<{
        items: any[];
        total: number;
    }>;
    updateSettings(userId: string, brandId: string | null, productId: string, settings: {
        stock_min?: number;
        cost_price?: number;
    }): Promise<InventoryRecord>;
    syncFromCommerceProducts(userId: string, brandId: string | null): Promise<{
        synced: number;
    }>;
    handleOrderCreated(userId: string, brandId: string | null, orderId: string, items: Array<{
        product_id: string;
        quantity: number;
    }>): Promise<void>;
    handleOrderPaid(userId: string, brandId: string | null, orderId: string, items: Array<{
        product_id: string;
        quantity: number;
    }>): Promise<void>;
    handleOrderCancelled(userId: string, brandId: string | null, orderId: string, items: Array<{
        product_id: string;
        quantity: number;
    }>): Promise<void>;
}
//# sourceMappingURL=inventory.d.ts.map