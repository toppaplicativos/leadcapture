"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const logger_1 = require("../utils/logger");
const database_1 = require("../config/database");
const pool = (0, database_1.getPool)();
class ProductsService {
    constructor() {
        this.imageColumnReady = null;
        this.metadataColumnReady = null;
        this.coverSchemaReady = false;
        this.coverSchemaPromise = null;
        this.ownershipSchemaReady = false;
        this.ownershipSchemaReadyPromise = null;
        this.tableColumnsCache = {};
    }
    normalizeBrandId(brandId) {
        const normalized = String(brandId || "").trim();
        return normalized || null;
    }
    async getTableColumns(table) {
        if (this.tableColumnsCache[table])
            return this.tableColumnsCache[table];
        const [rows] = await pool.query(`SHOW COLUMNS FROM ${table}`);
        const cols = new Set(rows
            .map((row) => String(row.Field || "").trim())
            .filter(Boolean));
        this.tableColumnsCache[table] = cols;
        return cols;
    }
    async indexExists(table, indexName) {
        try {
            const [rows] = await pool.query(`SELECT COUNT(*) AS total
         FROM pg_indexes
         WHERE tablename = ? AND indexname = ?`, [table, indexName]);
            const first = Array.isArray(rows) ? rows[0] : null;
            return Number(first?.total || 0) > 0;
        }
        catch {
            try {
                const [rows] = await pool.query(`SELECT COUNT(*) AS total
           FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`, [table, indexName]);
                const first = Array.isArray(rows) ? rows[0] : null;
                return Number(first?.total || 0) > 0;
            }
            catch {
                try {
                    const [rows] = await pool.query(`SHOW INDEX FROM ${table} WHERE Key_name = ?`, [indexName]);
                    return Array.isArray(rows) && rows.length > 0;
                }
                catch {
                    return false;
                }
            }
        }
    }
    async ensureColumnIfMissing(table, column, definition) {
        const cols = await this.getTableColumns(table);
        if (!cols.has(column)) {
            await pool.query(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
            this.tableColumnsCache = {};
        }
    }
    async ensureIndexIfMissing(table, indexName, column) {
        const exists = await this.indexExists(table, indexName);
        if (!exists) {
            await pool.query(`CREATE INDEX ${indexName} ON ${table} (${column})`);
        }
    }
    async ensureOwnershipSchema() {
        if (this.ownershipSchemaReady)
            return;
        if (this.ownershipSchemaReadyPromise) {
            await this.ownershipSchemaReadyPromise;
            return;
        }
        this.ownershipSchemaReadyPromise = (async () => {
            await pool.query(`
        CREATE TABLE IF NOT EXISTS categories (
          id VARCHAR(36) PRIMARY KEY,
          name VARCHAR(120) NOT NULL,
          description TEXT NULL,
          color VARCHAR(20) NULL,
          cover_image TEXT NULL,
          user_id VARCHAR(36) NULL,
          brand_id VARCHAR(36) NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            // Ensure cover_image column exists on older schemas
            try {
                const [cols] = await pool.query("SHOW COLUMNS FROM categories LIKE 'cover_image'");
                if (cols.length === 0) {
                    await pool.query("ALTER TABLE categories ADD COLUMN cover_image TEXT NULL");
                    logger_1.logger.info("Added cover_image column to categories");
                }
            }
            catch (_) { /* table may not exist yet */ }
            await pool.query(`
        CREATE TABLE IF NOT EXISTS products (
          id VARCHAR(36) PRIMARY KEY,
          name VARCHAR(180) NOT NULL,
          description TEXT NULL,
          category VARCHAR(36) NULL,
          price DECIMAL(12,2) NOT NULL DEFAULT 0,
          promo_price DECIMAL(12,2) NULL,
          unit VARCHAR(40) NOT NULL DEFAULT 'unidade',
          features JSONB NULL,
          image_url TEXT NULL,
          active BOOLEAN NOT NULL DEFAULT TRUE,
          user_id VARCHAR(36) NULL,
          brand_id VARCHAR(36) NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            await pool.query(`
        CREATE TABLE IF NOT EXISTS price_tables (
          id VARCHAR(36) PRIMARY KEY,
          name VARCHAR(140) NOT NULL,
          description TEXT NULL,
          valid_from TIMESTAMP NULL,
          valid_until TIMESTAMP NULL,
          active BOOLEAN NOT NULL DEFAULT TRUE,
          user_id VARCHAR(36) NULL,
          brand_id VARCHAR(36) NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            await pool.query(`
        CREATE TABLE IF NOT EXISTS price_table_items (
          id BIGSERIAL PRIMARY KEY,
          price_table_id VARCHAR(36) NOT NULL,
          product_id VARCHAR(36) NOT NULL,
          custom_price DECIMAL(12,2) NULL,
          custom_promo_price DECIMAL(12,2) NULL,
          include_in_campaign BOOLEAN NOT NULL DEFAULT TRUE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
            await this.ensureColumnIfMissing("products", "brand_id", "VARCHAR(36) NULL");
            await this.ensureColumnIfMissing("categories", "brand_id", "VARCHAR(36) NULL");
            await this.ensureColumnIfMissing("price_tables", "brand_id", "VARCHAR(36) NULL");
            await this.ensureIndexIfMissing("products", "idx_products_brand", "brand_id");
            await this.ensureIndexIfMissing("categories", "idx_categories_brand", "brand_id");
            await this.ensureIndexIfMissing("price_tables", "idx_price_tables_brand", "brand_id");
            this.tableColumnsCache = {};
            this.ownershipSchemaReady = true;
        })().finally(() => {
            this.ownershipSchemaReadyPromise = null;
        });
        await this.ownershipSchemaReadyPromise;
    }
    hasUserColumn(columns) {
        return columns.has("user_id") || columns.has("created_by");
    }
    userColumn(columns) {
        if (columns.has("user_id"))
            return "user_id";
        if (columns.has("created_by"))
            return "created_by";
        return "";
    }
    appendOwnershipWhere(columns, userId, brandId, alias) {
        const where = [];
        const params = [];
        const prefix = alias ? `${alias}.` : "";
        if (userId && this.hasUserColumn(columns)) {
            where.push(`${prefix}${this.userColumn(columns)} = ?`);
            params.push(userId);
        }
        if (columns.has("brand_id")) {
            const normalizedBrandId = this.normalizeBrandId(brandId);
            if (normalizedBrandId) {
                where.push(`(${prefix}brand_id = ? OR ${prefix}brand_id IS NULL OR ${prefix}brand_id = '')`);
                params.push(normalizedBrandId);
            }
            else {
                where.push(`(${prefix}brand_id IS NULL OR ${prefix}brand_id = '')`);
            }
        }
        return {
            sql: where.length ? ` WHERE ${where.join(" AND ")}` : "",
            params,
        };
    }
    async resolveCategoryId(rawCategory, userId, brandId) {
        const value = String(rawCategory || "").trim();
        if (!value)
            return null;
        const categoryColumns = await this.getTableColumns("categories");
        const scope = this.appendOwnershipWhere(categoryColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [byIdRows] = await pool.query(`SELECT id FROM categories WHERE id = ?${andScope} LIMIT 1`, [value, ...scope.params]);
        if (Array.isArray(byIdRows) && byIdRows.length > 0) {
            return String(byIdRows[0].id);
        }
        const [byNameRows] = await pool.query(`SELECT id FROM categories WHERE LOWER(name) = LOWER(?)${andScope} LIMIT 1`, [value, ...scope.params]);
        if (Array.isArray(byNameRows) && byNameRows.length > 0) {
            return String(byNameRows[0].id);
        }
        const createdId = `cat-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        const insertColumns = ["id", "name", "description", "color"];
        const insertValues = [createdId, value, "", "#3b82f6"];
        if (categoryColumns.has("user_id") && userId) {
            insertColumns.push("user_id");
            insertValues.push(userId);
        }
        else if (categoryColumns.has("created_by") && userId) {
            insertColumns.push("created_by");
            insertValues.push(userId);
        }
        if (categoryColumns.has("brand_id")) {
            insertColumns.push("brand_id");
            insertValues.push(this.normalizeBrandId(brandId));
        }
        await pool.query(`INSERT INTO categories (${insertColumns.join(", ")}) VALUES (${insertColumns.map(() => "?").join(", ")})`, insertValues);
        return createdId;
    }
    async ensureImageColumn() {
        if (this.imageColumnReady !== null)
            return this.imageColumnReady;
        try {
            const [rows] = await pool.query("SHOW COLUMNS FROM products LIKE 'image_url'");
            if (Array.isArray(rows) && rows.length > 0) {
                this.imageColumnReady = true;
                return true;
            }
            await pool.query("ALTER TABLE products ADD COLUMN image_url TEXT NULL");
            this.imageColumnReady = true;
            return true;
        }
        catch (error) {
            if (String(error?.message || "").toLowerCase().includes("duplicate column")) {
                this.imageColumnReady = true;
                return true;
            }
            logger_1.logger.warn(`Product image column unavailable: ${error?.message || error}`);
            this.imageColumnReady = false;
            return false;
        }
    }
    async ensureMetadataColumn() {
        if (this.metadataColumnReady !== null)
            return this.metadataColumnReady;
        try {
            const [rows] = await pool.query("SHOW COLUMNS FROM products LIKE 'metadata_json'");
            if (Array.isArray(rows) && rows.length > 0) {
                this.metadataColumnReady = true;
                return true;
            }
            await pool.query("ALTER TABLE products ADD COLUMN metadata_json JSON NULL");
            this.tableColumnsCache = {};
            this.metadataColumnReady = true;
            return true;
        }
        catch (error) {
            if (String(error?.message || "").toLowerCase().includes("duplicate column")) {
                this.metadataColumnReady = true;
                return true;
            }
            logger_1.logger.warn(`Product metadata column unavailable: ${error?.message || error}`);
            this.metadataColumnReady = false;
            return false;
        }
    }
    parseTagsInput(value) {
        if (!value)
            return [];
        if (Array.isArray(value)) {
            return [...new Set(value.map((item) => String(item || "").trim().toLowerCase()).filter(Boolean))];
        }
        const raw = String(value || "").trim();
        if (!raw)
            return [];
        try {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) {
                return [...new Set(parsed.map((item) => String(item || "").trim().toLowerCase()).filter(Boolean))];
            }
        }
        catch {
            // noop
        }
        return [...new Set(raw.split(",").map((item) => item.trim().toLowerCase()).filter(Boolean))];
    }
    parseJsonValue(value, fallback) {
        if (value === undefined || value === null || value === "")
            return fallback;
        if (typeof value === "object")
            return value;
        try {
            return JSON.parse(String(value));
        }
        catch {
            return fallback;
        }
    }
    normalizeImageList(value) {
        let list = [];
        if (Array.isArray(value)) {
            list = value;
        }
        else if (typeof value === "string") {
            const raw = String(value || "").trim();
            if (!raw)
                return [];
            try {
                const parsed = JSON.parse(raw);
                list = Array.isArray(parsed) ? parsed : raw.split(",");
            }
            catch {
                list = raw.split(",");
            }
        }
        return [...new Set(list.map((item) => String(item || "").trim()).filter(Boolean))];
    }
    extractGalleryImages(metadata) {
        if (!metadata || typeof metadata !== "object")
            return [];
        const media = metadata.media && typeof metadata.media === "object" ? metadata.media : {};
        return this.normalizeImageList(metadata.gallery_images ?? metadata.galleryImages ?? media.gallery ?? metadata.images ?? []);
    }
    buildNextMetadataWithGallery(metadata, images) {
        const media = metadata.media && typeof metadata.media === "object" ? metadata.media : {};
        return {
            ...metadata,
            gallery_images: images,
            galleryImages: images,
            media: {
                ...media,
                gallery: images,
                gallery_count: images.length,
                updated_at: new Date().toISOString(),
            },
        };
    }
    async ensureDynamicCoverSchema() {
        if (this.coverSchemaReady)
            return;
        if (this.coverSchemaPromise) {
            await this.coverSchemaPromise;
            return;
        }
        this.coverSchemaPromise = (async () => {
            await pool.query(`
        CREATE TABLE IF NOT EXISTS product_dynamic_covers (
          id VARCHAR(36) PRIMARY KEY,
          product_id VARCHAR(36) NOT NULL,
          user_id VARCHAR(36) DEFAULT NULL,
          brand_id VARCHAR(36) DEFAULT NULL,
          title VARCHAR(140) DEFAULT NULL,
          image_url TEXT NOT NULL,
          tags_json JSON,
          priority INT NOT NULL DEFAULT 100,
          active TINYINT(1) NOT NULL DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          KEY idx_pdc_product (product_id),
          KEY idx_pdc_user (user_id),
          KEY idx_pdc_brand (brand_id),
          KEY idx_pdc_active_priority (active, priority)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
      `);
            this.coverSchemaReady = true;
        })().finally(() => {
            this.coverSchemaPromise = null;
        });
        await this.coverSchemaPromise;
    }
    async listDynamicCovers(productId, userId, brandId) {
        await this.ensureOwnershipSchema();
        await this.ensureDynamicCoverSchema();
        const product = await this.getProduct(productId, userId, brandId);
        if (!product)
            return [];
        const normalizedBrand = this.normalizeBrandId(brandId);
        const where = ["product_id = ?"];
        const params = [productId];
        if (userId) {
            where.push("(user_id = ? OR user_id IS NULL)");
            params.push(userId);
        }
        if (normalizedBrand) {
            where.push("(brand_id = ? OR brand_id IS NULL)");
            params.push(normalizedBrand);
        }
        else {
            where.push("brand_id IS NULL");
        }
        const [rows] = await pool.query(`SELECT * FROM product_dynamic_covers WHERE ${where.join(" AND ")} ORDER BY priority ASC, created_at DESC`, params);
        return rows.map((row) => ({
            id: String(row.id),
            product_id: String(row.product_id),
            title: row.title ? String(row.title) : null,
            image_url: String(row.image_url || ""),
            tags: this.parseTagsInput(row.tags_json),
            priority: Number(row.priority || 100),
            active: Boolean(row.active),
            created_at: row.created_at,
            updated_at: row.updated_at,
        }));
    }
    async createDynamicCover(productId, input, userId, brandId) {
        await this.ensureOwnershipSchema();
        await this.ensureDynamicCoverSchema();
        const product = await this.getProduct(productId, userId, brandId);
        if (!product)
            return null;
        const id = `pdc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        const tags = this.parseTagsInput(input.tags || []);
        const normalizedBrand = this.normalizeBrandId(brandId);
        await pool.query(`INSERT INTO product_dynamic_covers
       (id, product_id, user_id, brand_id, title, image_url, tags_json, priority, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            id,
            productId,
            userId || null,
            normalizedBrand,
            input.title ? String(input.title).trim() : null,
            String(input.imageUrl).trim(),
            JSON.stringify(tags),
            Number(input.priority ?? 100),
            input.active === false ? 0 : 1,
        ]);
        const created = await this.listDynamicCovers(productId, userId, brandId);
        return created.find((item) => item.id === id) || null;
    }
    async updateDynamicCover(productId, coverId, input, userId, brandId) {
        await this.ensureOwnershipSchema();
        await this.ensureDynamicCoverSchema();
        const product = await this.getProduct(productId, userId, brandId);
        if (!product)
            return null;
        const fields = [];
        const params = [];
        if (input.title !== undefined) {
            fields.push("title = ?");
            params.push(String(input.title || "").trim() || null);
        }
        if (input.imageUrl !== undefined) {
            fields.push("image_url = ?");
            params.push(String(input.imageUrl || "").trim());
        }
        if (input.tags !== undefined) {
            fields.push("tags_json = ?");
            params.push(JSON.stringify(this.parseTagsInput(input.tags)));
        }
        if (input.priority !== undefined) {
            fields.push("priority = ?");
            params.push(Number(input.priority || 100));
        }
        if (input.active !== undefined) {
            fields.push("active = ?");
            params.push(input.active ? 1 : 0);
        }
        if (!fields.length) {
            const list = await this.listDynamicCovers(productId, userId, brandId);
            return list.find((item) => item.id === coverId) || null;
        }
        const normalizedBrand = this.normalizeBrandId(brandId);
        const where = ["id = ?", "product_id = ?"];
        const whereParams = [coverId, productId];
        if (userId) {
            where.push("(user_id = ? OR user_id IS NULL)");
            whereParams.push(userId);
        }
        if (normalizedBrand) {
            where.push("(brand_id = ? OR brand_id IS NULL)");
            whereParams.push(normalizedBrand);
        }
        else {
            where.push("brand_id IS NULL");
        }
        await pool.query(`UPDATE product_dynamic_covers SET ${fields.join(", ")}, updated_at = NOW() WHERE ${where.join(" AND ")}`, [...params, ...whereParams]);
        const list = await this.listDynamicCovers(productId, userId, brandId);
        return list.find((item) => item.id === coverId) || null;
    }
    async deleteDynamicCover(productId, coverId, userId, brandId) {
        await this.ensureOwnershipSchema();
        await this.ensureDynamicCoverSchema();
        const product = await this.getProduct(productId, userId, brandId);
        if (!product)
            return false;
        const normalizedBrand = this.normalizeBrandId(brandId);
        const where = ["id = ?", "product_id = ?"];
        const params = [coverId, productId];
        if (userId) {
            where.push("(user_id = ? OR user_id IS NULL)");
            params.push(userId);
        }
        if (normalizedBrand) {
            where.push("(brand_id = ? OR brand_id IS NULL)");
            params.push(normalizedBrand);
        }
        else {
            where.push("brand_id IS NULL");
        }
        const [result] = await pool.query(`DELETE FROM product_dynamic_covers WHERE ${where.join(" AND ")}`, params);
        return Number(result?.affectedRows || 0) > 0;
    }
    async getProductGalleryImages(productId, userId, brandId) {
        const product = await this.getProduct(productId, userId, brandId);
        if (!product)
            return null;
        return Array.isArray(product.galleryImages) ? product.galleryImages : [];
    }
    async replaceProductGalleryImages(productId, images, userId, brandId) {
        await this.ensureOwnershipSchema();
        const existing = await this.getProduct(productId, userId, brandId);
        if (!existing)
            return null;
        const canPersistMetadata = await this.ensureMetadataColumn();
        if (!canPersistMetadata)
            return existing;
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [rows] = await pool.query(`SELECT metadata_json FROM products WHERE id = ?${andScope} LIMIT 1`, [productId, ...scope.params]);
        const row = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
        const metadata = this.parseJsonValue(row?.metadata_json, {});
        const normalizedImages = this.normalizeImageList(images);
        const nextMetadata = this.buildNextMetadataWithGallery(metadata, normalizedImages);
        await pool.query(`UPDATE products SET metadata_json = ?, updated_at = ? WHERE id = ?${andScope}`, [JSON.stringify(nextMetadata), new Date(), productId, ...scope.params]);
        return (await this.getProduct(productId, userId, brandId));
    }
    async appendProductGalleryImages(productId, images, userId, brandId) {
        const existing = await this.getProduct(productId, userId, brandId);
        if (!existing)
            return null;
        const nextImages = this.normalizeImageList([...(existing.galleryImages || []), ...images]);
        return this.replaceProductGalleryImages(productId, nextImages, userId, brandId);
    }
    async removeProductGalleryImage(productId, index, userId, brandId) {
        const existing = await this.getProduct(productId, userId, brandId);
        if (!existing)
            return null;
        const nextImages = [...(existing.galleryImages || [])];
        if (index < 0 || index >= nextImages.length)
            return existing;
        nextImages.splice(index, 1);
        return this.replaceProductGalleryImages(productId, nextImages, userId, brandId);
    }
    async resolveDynamicCover(productId, input, userId, brandId) {
        const covers = await this.listDynamicCovers(productId, userId, brandId);
        const activeCovers = covers.filter((cover) => cover.active);
        if (!activeCovers.length)
            return null;
        const targetTags = new Set(this.parseTagsInput(input.tags || []));
        let best = null;
        let bestScore = -1;
        for (const cover of activeCovers) {
            const coverTags = this.parseTagsInput(cover.tags || []);
            if (coverTags.length === 0) {
                if (bestScore < 0) {
                    best = cover;
                    bestScore = 0;
                }
                continue;
            }
            let score = 0;
            for (const tag of coverTags) {
                if (targetTags.has(tag))
                    score += 1;
            }
            if (score > bestScore) {
                best = cover;
                bestScore = score;
            }
            else if (score === bestScore && best && Number(cover.priority || 100) < Number(best.priority || 100)) {
                best = cover;
            }
        }
        if (!best)
            return null;
        if (bestScore <= 0 && this.parseTagsInput(best.tags || []).length > 0)
            return null;
        return best;
    }
    // ==================== PRODUCTS ====================
    async getProducts(userId, brandId) {
        await this.ensureOwnershipSchema();
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId, "p");
        const [rows] = await pool.query(`SELECT p.*, c.name AS category_name
       FROM products p
       LEFT JOIN categories c ON c.id = p.category
       ${scope.sql}
       ORDER BY p.created_at DESC`, scope.params);
        return rows.map((row) => this.mapProduct(row));
    }
    async getProduct(id, userId, brandId) {
        await this.ensureOwnershipSchema();
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId, "p");
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [rows] = await pool.query(`SELECT p.*, c.name AS category_name
       FROM products p
       LEFT JOIN categories c ON c.id = p.category
       WHERE p.id = ?${andScope}`, [id, ...scope.params]);
        const arr = rows;
        return arr.length > 0 ? this.mapProduct(arr[0]) : undefined;
    }
    async getProductsByCategory(category, userId, brandId) {
        await this.ensureOwnershipSchema();
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId, "p");
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [rows] = await pool.query(`SELECT p.*, c.name AS category_name
       FROM products p
       LEFT JOIN categories c ON c.id = p.category
       WHERE (p.category = ? OR LOWER(c.name) = LOWER(?))${andScope}`, [category, category, ...scope.params]);
        return rows.map((row) => this.mapProduct(row));
    }
    async getActiveProducts(userId, brandId) {
        await this.ensureOwnershipSchema();
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId);
        const where = ["active = true"];
        if (scope.sql)
            where.push(scope.sql.replace(/^\s*WHERE\s+/i, ""));
        const [rows] = await pool.query(`SELECT * FROM products WHERE ${where.join(" AND ")} ORDER BY created_at DESC`, scope.params);
        return rows.map((row) => this.mapProduct(row));
    }
    async createProduct(data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const id = `prod-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
        const now = new Date();
        const features = Array.isArray(data.features) ? JSON.stringify(data.features) : "[]";
        const categoryId = await this.resolveCategoryId(data.category, userId, brandId);
        const productColumns = await this.getTableColumns("products");
        const insertColumns = ["id", "name", "description", "category", "price", "promo_price", "unit", "features", "active", "created_at", "updated_at"];
        const insertValues = [
            id,
            data.name,
            data.description || "",
            categoryId,
            data.price || 0,
            data.promoPrice || null,
            data.unit || "unidade",
            features,
            data.active !== false,
            now,
            now,
        ];
        if (productColumns.has("user_id") && userId) {
            insertColumns.push("user_id");
            insertValues.push(userId);
        }
        else if (productColumns.has("created_by") && userId) {
            insertColumns.push("created_by");
            insertValues.push(userId);
        }
        if (productColumns.has("brand_id")) {
            insertColumns.push("brand_id");
            insertValues.push(this.normalizeBrandId(brandId));
        }
        await pool.query(`INSERT INTO products (${insertColumns.join(", ")}) VALUES (${insertColumns.map(() => "?").join(", ")})`, insertValues);
        logger_1.logger.info(`Product created: ${data.name} (${id})`);
        return (await this.getProduct(id, userId, brandId));
    }
    async updateProduct(id, data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const existing = await this.getProduct(id, userId, brandId);
        if (!existing)
            return null;
        const fields = [];
        const values = [];
        if (data.name !== undefined) {
            fields.push("name = ?");
            values.push(data.name);
        }
        if (data.description !== undefined) {
            fields.push("description = ?");
            values.push(data.description);
        }
        if (data.category !== undefined) {
            const categoryId = await this.resolveCategoryId(data.category, userId, brandId);
            fields.push("category = ?");
            values.push(categoryId);
        }
        if (data.price !== undefined) {
            fields.push("price = ?");
            values.push(data.price);
        }
        if (data.promoPrice !== undefined) {
            fields.push("promo_price = ?");
            values.push(data.promoPrice);
        }
        if (data.unit !== undefined) {
            fields.push("unit = ?");
            values.push(data.unit);
        }
        if (data.features !== undefined) {
            fields.push("features = ?");
            values.push(JSON.stringify(data.features));
        }
        if (data.active !== undefined) {
            fields.push("active = ?");
            values.push(data.active);
        }
        if (data.imageUrl !== undefined || data.image !== undefined) {
            const canPersistImage = await this.ensureImageColumn();
            if (canPersistImage) {
                const imageUrl = data.imageUrl !== undefined ? data.imageUrl : data.image;
                fields.push("image_url = ?");
                values.push(imageUrl || null);
            }
        }
        if (fields.length === 0)
            return existing;
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        fields.push("updated_at = ?");
        values.push(new Date());
        values.push(id, ...scope.params);
        await pool.query(`UPDATE products SET ${fields.join(", ")} WHERE id = ?${andScope}`, values);
        logger_1.logger.info(`Product updated: ${data.name || existing.name} (${id})`);
        return (await this.getProduct(id, userId, brandId));
    }
    async deleteProduct(id, userId, brandId) {
        await this.ensureOwnershipSchema();
        const productColumns = await this.getTableColumns("products");
        const scope = this.appendOwnershipWhere(productColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [result] = await pool.query(`DELETE FROM products WHERE id = ?${andScope}`, [id, ...scope.params]);
        const deleted = result.affectedRows > 0;
        if (deleted)
            logger_1.logger.info(`Product deleted: ${id}`);
        return deleted;
    }
    mapProduct(row) {
        const metadata = this.parseJsonValue(row.metadata_json, {});
        const galleryImages = this.extractGalleryImages(metadata);
        const imageUrl = row.image_url || row.image || galleryImages[0] || undefined;
        const images = this.normalizeImageList([imageUrl, ...galleryImages]);
        return {
            id: row.id,
            name: row.name,
            description: row.description || "",
            category: row.category_name || row.category || "",
            price: parseFloat(row.price) || 0,
            promoPrice: row.promo_price ? parseFloat(row.promo_price) : undefined,
            unit: row.unit || "unidade",
            features: typeof row.features === "string" ? JSON.parse(row.features) : (row.features || []),
            imageUrl,
            image: imageUrl,
            images,
            galleryImages,
            metadata,
            active: Boolean(row.active),
            is_active: Boolean(row.active),
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        };
    }
    // ==================== CATEGORIES ====================
    async getCategories(userId, brandId) {
        await this.ensureOwnershipSchema();
        const categoryColumns = await this.getTableColumns("categories");
        const scope = this.appendOwnershipWhere(categoryColumns, userId, brandId);
        const [rows] = await pool.query(`SELECT * FROM categories${scope.sql} ORDER BY created_at DESC`, scope.params);
        return rows.map((r) => ({ id: r.id, name: r.name, description: r.description || "", color: r.color || "#3b82f6", coverImage: r.cover_image || "" }));
    }
    async createCategory(data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const id = `cat-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
        const categoryColumns = await this.getTableColumns("categories");
        const insertColumns = ["id", "name", "description", "color", "cover_image"];
        const insertValues = [id, data.name, data.description || "", data.color || "#3b82f6", data.coverImage || ""];
        if (categoryColumns.has("user_id") && userId) {
            insertColumns.push("user_id");
            insertValues.push(userId);
        }
        else if (categoryColumns.has("created_by") && userId) {
            insertColumns.push("created_by");
            insertValues.push(userId);
        }
        if (categoryColumns.has("brand_id")) {
            insertColumns.push("brand_id");
            insertValues.push(this.normalizeBrandId(brandId));
        }
        await pool.query(`INSERT INTO categories (${insertColumns.join(", ")}) VALUES (${insertColumns.map(() => "?").join(", ")})`, insertValues);
        logger_1.logger.info(`Category created: ${data.name}`);
        return { id, name: data.name, description: data.description, color: data.color || "#3b82f6", coverImage: data.coverImage || "" };
    }
    async updateCategory(id, data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const categoryColumns = await this.getTableColumns("categories");
        const scope = this.appendOwnershipWhere(categoryColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [existing] = await pool.query(`SELECT * FROM categories WHERE id = ?${andScope}`, [id, ...scope.params]);
        if (existing.length === 0)
            return null;
        const fields = [];
        const values = [];
        if (data.name !== undefined) {
            fields.push("name = ?");
            values.push(data.name);
        }
        if (data.description !== undefined) {
            fields.push("description = ?");
            values.push(data.description);
        }
        if (data.color !== undefined) {
            fields.push("color = ?");
            values.push(data.color);
        }
        if (data.coverImage !== undefined) {
            fields.push("cover_image = ?");
            values.push(data.coverImage);
        }
        if (fields.length === 0)
            return existing[0];
        values.push(id, ...scope.params);
        await pool.query(`UPDATE categories SET ${fields.join(", ")} WHERE id = ?${andScope}`, values);
        const [updated] = await pool.query(`SELECT * FROM categories WHERE id = ?${andScope}`, [id, ...scope.params]);
        const r = updated[0];
        return { id: r.id, name: r.name, description: r.description, color: r.color, coverImage: r.cover_image || "" };
    }
    async deleteCategory(id, userId, brandId) {
        await this.ensureOwnershipSchema();
        const categoryColumns = await this.getTableColumns("categories");
        const scope = this.appendOwnershipWhere(categoryColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [result] = await pool.query(`DELETE FROM categories WHERE id = ?${andScope}`, [id, ...scope.params]);
        return result.affectedRows > 0;
    }
    // ==================== PRICE TABLES ====================
    async getPriceTables(userId, brandId) {
        await this.ensureOwnershipSchema();
        const priceTableColumns = await this.getTableColumns("price_tables");
        const scope = this.appendOwnershipWhere(priceTableColumns, userId, brandId);
        const [rows] = await pool.query(`SELECT * FROM price_tables${scope.sql} ORDER BY created_at DESC`, scope.params);
        const tables = [];
        for (const row of rows) {
            const [items] = await pool.query("SELECT * FROM price_table_items WHERE price_table_id = ?", [row.id]);
            tables.push(this.mapPriceTable(row, items));
        }
        return tables;
    }
    async getPriceTable(id, userId, brandId) {
        await this.ensureOwnershipSchema();
        const priceTableColumns = await this.getTableColumns("price_tables");
        const scope = this.appendOwnershipWhere(priceTableColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [rows] = await pool.query(`SELECT * FROM price_tables WHERE id = ?${andScope}`, [id, ...scope.params]);
        if (rows.length === 0)
            return undefined;
        const [items] = await pool.query("SELECT * FROM price_table_items WHERE price_table_id = ?", [id]);
        return this.mapPriceTable(rows[0], items);
    }
    async createPriceTable(data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const id = `pt-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
        const now = new Date();
        const priceTableColumns = await this.getTableColumns("price_tables");
        const insertColumns = ["id", "name", "description", "valid_from", "valid_until", "active", "created_at"];
        const insertValues = [id, data.name, data.description || "", data.validFrom || null, data.validUntil || null, data.active !== false, now];
        if (priceTableColumns.has("user_id") && userId) {
            insertColumns.push("user_id");
            insertValues.push(userId);
        }
        else if (priceTableColumns.has("created_by") && userId) {
            insertColumns.push("created_by");
            insertValues.push(userId);
        }
        if (priceTableColumns.has("brand_id")) {
            insertColumns.push("brand_id");
            insertValues.push(this.normalizeBrandId(brandId));
        }
        await pool.query(`INSERT INTO price_tables (${insertColumns.join(", ")}) VALUES (${insertColumns.map(() => "?").join(", ")})`, insertValues);
        if (data.products && data.products.length > 0) {
            for (const p of data.products) {
                await pool.query("INSERT INTO price_table_items (price_table_id, product_id, custom_price, custom_promo_price, include_in_campaign) VALUES (?, ?, ?, ?, ?)", [id, p.productId, p.customPrice || null, p.customPromoPrice || null, p.includeInCampaign !== false]);
            }
        }
        logger_1.logger.info(`Price table created: ${data.name}`);
        return (await this.getPriceTable(id, userId, brandId));
    }
    async updatePriceTable(id, data, userId, brandId) {
        await this.ensureOwnershipSchema();
        const existing = await this.getPriceTable(id, userId, brandId);
        if (!existing)
            return null;
        const priceTableColumns = await this.getTableColumns("price_tables");
        const scope = this.appendOwnershipWhere(priceTableColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const fields = [];
        const values = [];
        if (data.name !== undefined) {
            fields.push("name = ?");
            values.push(data.name);
        }
        if (data.description !== undefined) {
            fields.push("description = ?");
            values.push(data.description);
        }
        if (data.validFrom !== undefined) {
            fields.push("valid_from = ?");
            values.push(data.validFrom);
        }
        if (data.validUntil !== undefined) {
            fields.push("valid_until = ?");
            values.push(data.validUntil);
        }
        if (data.active !== undefined) {
            fields.push("active = ?");
            values.push(data.active);
        }
        if (fields.length > 0) {
            values.push(id, ...scope.params);
            await pool.query(`UPDATE price_tables SET ${fields.join(", ")} WHERE id = ?${andScope}`, values);
        }
        if (data.products !== undefined) {
            await pool.query("DELETE FROM price_table_items WHERE price_table_id = ?", [id]);
            for (const p of data.products) {
                await pool.query("INSERT INTO price_table_items (price_table_id, product_id, custom_price, custom_promo_price, include_in_campaign) VALUES (?, ?, ?, ?, ?)", [id, p.productId, p.customPrice || null, p.customPromoPrice || null, p.includeInCampaign !== false]);
            }
        }
        return (await this.getPriceTable(id, userId, brandId));
    }
    async deletePriceTable(id, userId, brandId) {
        await this.ensureOwnershipSchema();
        const priceTableColumns = await this.getTableColumns("price_tables");
        const scope = this.appendOwnershipWhere(priceTableColumns, userId, brandId);
        const andScope = scope.sql ? ` AND ${scope.sql.replace(/^\s*WHERE\s+/i, "")}` : "";
        const [result] = await pool.query(`DELETE FROM price_tables WHERE id = ?${andScope}`, [id, ...scope.params]);
        return result.affectedRows > 0;
    }
    mapPriceTable(row, items) {
        return {
            id: row.id,
            name: row.name,
            description: row.description || "",
            validFrom: row.valid_from,
            validUntil: row.valid_until,
            active: Boolean(row.active),
            is_active: Boolean(row.active),
            createdAt: row.created_at,
            products: items.map((i) => ({
                productId: i.product_id,
                customPrice: i.custom_price ? parseFloat(i.custom_price) : undefined,
                customPromoPrice: i.custom_promo_price ? parseFloat(i.custom_promo_price) : undefined,
                includeInCampaign: Boolean(i.include_in_campaign),
            })),
        };
    }
    // ==================== CAMPAIGN HELPERS ====================
    async getProductsForCampaign(priceTableId, userId, brandId) {
        const products = await this.getActiveProducts(userId, brandId);
        if (!priceTableId) {
            return products.map((p) => ({
                id: p.id, name: p.name, description: p.description, category: p.category,
                price: p.price, promoPrice: p.promoPrice, unit: p.unit, features: p.features,
            }));
        }
        const table = await this.getPriceTable(priceTableId, userId, brandId);
        if (!table)
            return [];
        return table.products
            .filter((entry) => entry.includeInCampaign)
            .map((entry) => {
            const product = products.find((p) => p.id === entry.productId);
            if (!product)
                return null;
            return {
                id: product.id, name: product.name, description: product.description, category: product.category,
                price: entry.customPrice || product.price, promoPrice: entry.customPromoPrice || product.promoPrice,
                unit: product.unit, features: product.features,
            };
        })
            .filter(Boolean);
    }
    async formatProductsForPrompt(priceTableId, userId, brandId) {
        const products = await this.getProductsForCampaign(priceTableId, userId, brandId);
        if (products.length === 0)
            return "Nenhum produto cadastrado.";
        return products
            .map((p) => {
            let line = `- ${p.name} (${p.category}): R$ ${p.price.toFixed(2)}`;
            if (p.promoPrice)
                line += ` | Promo: R$ ${p.promoPrice.toFixed(2)}`;
            line += ` / ${p.unit}`;
            if (p.description)
                line += `\n  ${p.description}`;
            if (p.features && p.features.length > 0)
                line += `\n  Destaques: ${p.features.join(", ")}`;
            return line;
        })
            .join("\n");
    }
}
exports.ProductsService = ProductsService;
//# sourceMappingURL=products.js.map