"use strict";
/**
 * LOGGER - Sistema de Logging Estruturado
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
class Logger {
    constructor() {
        this.prefix = '[Lead System]';
    }
    log(level, message, data) {
        const timestamp = new Date().toISOString();
        const logMessage = `${timestamp} [${level.toUpperCase()}] ${this.prefix} ${message}`;
        if (data) {
            console.log(logMessage, data);
        }
        else {
            console.log(logMessage);
        }
    }
    info(message, data) {
        this.log('info', message, data);
    }
    warn(message, data) {
        this.log('warn', message, data);
    }
    error(message, data) {
        this.log('error', message, data);
    }
    debug(message, data) {
        this.log('debug', message, data);
    }
}
exports.logger = new Logger();
//# sourceMappingURL=logger.js.map