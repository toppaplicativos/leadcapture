export declare function unwrapMessageContent(message: any): any;
export declare function extractIncomingMessageData(message: any): {
    body: string;
    messageType: string;
};
//# sourceMappingURL=whatsappMessage.d.ts.map