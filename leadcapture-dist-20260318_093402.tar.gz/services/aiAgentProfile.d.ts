type AIAgentTone = "formal" | "casual" | "friendly" | "professional";
type AIAgentProfile = {
    user_id: string;
    company_id?: string;
    brand_id?: string;
    agent_name: string;
    tone: AIAgentTone;
    language: string;
    include_emojis: boolean;
    max_length: number;
    objective?: string;
    business_context?: string;
    communication_rules?: string;
    training_notes?: string;
    forbidden_terms: string[];
    preferred_terms: string[];
    created_at?: Date | string;
    updated_at?: Date | string;
};
type AIAgentProfileUpdateDTO = Partial<Pick<AIAgentProfile, "company_id" | "brand_id" | "agent_name" | "tone" | "language" | "include_emojis" | "max_length" | "objective" | "business_context" | "communication_rules" | "training_notes" | "forbidden_terms" | "preferred_terms">>;
export declare class AIAgentProfileService {
    private schemaReady;
    private schemaReadyPromise;
    private columnExists;
    private indexExists;
    private ensureSchema;
    private normalizeScopeId;
    private defaultProfile;
    private toProfile;
    getByUserId(userId: string, companyId?: string): Promise<AIAgentProfile>;
    upsertByUserId(userId: string, payload: AIAgentProfileUpdateDTO): Promise<AIAgentProfile>;
    buildBehaviorBlock(profile: AIAgentProfile): string;
}
export {};
//# sourceMappingURL=aiAgentProfile.d.ts.map