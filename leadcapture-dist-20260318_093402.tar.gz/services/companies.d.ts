export interface Company {
    id: string;
    user_id: string;
    name: string;
    cnpj?: string;
    phone?: string;
    email?: string;
    address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    logo_url?: string;
    website?: string;
    industry?: string;
    description?: string;
    is_active: boolean;
    created_at: Date;
    updated_at: Date;
}
export interface CompanyCreateDTO {
    name: string;
    cnpj?: string;
    phone?: string;
    email?: string;
    address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    logo_url?: string;
    website?: string;
    industry?: string;
    description?: string;
}
export declare class CompaniesService {
    private brandColumnChecked;
    private hasBrandColumn;
    private ensureBrandColumn;
    create(userId: string, data: CompanyCreateDTO, brandId?: string | null): Promise<Company>;
    getById(id: string, userId: string, brandId?: string | null): Promise<Company | null>;
    getAll(userId: string, brandId?: string | null): Promise<Company[]>;
    update(id: string, userId: string, data: Partial<CompanyCreateDTO>, brandId?: string | null): Promise<Company | null>;
    delete(id: string, userId: string, brandId?: string | null): Promise<boolean>;
}
//# sourceMappingURL=companies.d.ts.map