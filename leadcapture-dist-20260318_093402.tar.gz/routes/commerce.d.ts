declare const router: import("express-serve-static-core").Router;
declare const publicRouter: import("express-serve-static-core").Router;
export default router;
export { publicRouter as commercePublicRoutes };
//# sourceMappingURL=commerce.d.ts.map