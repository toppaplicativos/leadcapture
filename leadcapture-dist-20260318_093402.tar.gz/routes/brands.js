"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const brandUnits_1 = require("../services/brandUnits");
const storefront_1 = require("../services/storefront");
const router = (0, express_1.Router)();
const brandUnitsService = new brandUnits_1.BrandUnitsService();
const storefrontService = new storefront_1.StorefrontService();
function resolveBrandErrorStatus(message) {
    const normalized = String(message || "").toLowerCase();
    if (normalized.includes("required") ||
        normalized.includes("invalid") ||
        normalized.includes("must")) {
        return 400;
    }
    if (normalized.includes("duplicate") ||
        normalized.includes("already exists") ||
        normalized.includes("unique")) {
        return 409;
    }
    return 500;
}
router.get("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brands = await brandUnitsService.list(userId);
        const activeBrandId = await brandUnitsService.getActiveBrandId(userId);
        res.json({ success: true, brands, active_brand_id: activeBrandId });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brand = await brandUnitsService.create(userId, req.body || {});
        await storefrontService.synchronizeBrandStructure(userId, String(brand.id), { syncProducts: true });
        const activeBrandId = await brandUnitsService.getActiveBrandId(userId);
        res.status(201).json({ success: true, brand, active_brand_id: activeBrandId });
    }
    catch (error) {
        const message = String(error?.message || "");
        if (message.includes("required") || message.includes("invalid")) {
            return res.status(400).json({ error: message });
        }
        res.status(500).json({ error: message || "Failed to create brand" });
    }
});
const updateBrandHandler = async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brand = await brandUnitsService.update(userId, String(req.params.id), req.body || {});
        if (!brand)
            return res.status(404).json({ error: "Brand not found" });
        await storefrontService.synchronizeBrandStructure(userId, String(brand.id), { syncProducts: true });
        const activeBrandId = await brandUnitsService.getActiveBrandId(userId);
        res.json({ success: true, brand, active_brand_id: activeBrandId });
    }
    catch (error) {
        const message = String(error?.message || "Failed to update brand");
        res.status(resolveBrandErrorStatus(message)).json({ error: message });
    }
};
router.put("/:id", updateBrandHandler);
router.patch("/:id", updateBrandHandler);
router.post("/:id/activate", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const ok = await brandUnitsService.setActiveBrand(userId, String(req.params.id));
        if (!ok)
            return res.status(404).json({ error: "Brand not found" });
        await storefrontService.synchronizeBrandStructure(userId, String(req.params.id), { syncProducts: true });
        res.json({ success: true, active_brand_id: String(req.params.id) });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=brands.js.map