/**
 * MIDDLEWARE DE AUTENTICAÇÃO - Validação de JWT
 */
import { Request, Response, NextFunction } from 'express';
export interface AuthRequest extends Request {
    userId?: string;
    user?: any;
}
/**
 * Middleware para autenticar requisições usando JWT
 * Valida o token no header Authorization: Bearer <token>
 */
export declare function authenticateToken(req: AuthRequest, res: Response, next: NextFunction): void;
/**
 * Alias para authenticateToken (compatibilidade com código existente)
 */
export declare const authMiddleware: typeof authenticateToken;
/**
 * Middleware para verificar role do usuário
 */
export declare function requireRole(roles: string[]): (req: AuthRequest, res: Response, next: NextFunction) => void;
/**
 * Verifica se um token é válido
 */
export declare function verifyToken(token: string): any;
//# sourceMappingURL=auth.d.ts.map