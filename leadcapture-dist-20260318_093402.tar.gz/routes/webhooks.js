"use strict";
/**
 * ROTAS DE WEBHOOKS - Recebimento de Eventos do WhatsApp
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const logger_1 = require("../core/logger");
const router = (0, express_1.Router)();
/**
 * POST /api/webhooks/whatsapp
 * Recebe eventos do WhatsApp (mensagens, status, etc)
 */
router.post('/whatsapp', async (req, res) => {
    try {
        const { event, data } = req.body;
        logger_1.logger.info(`Webhook recebido: ${event}`, data);
        // Emitir evento via Socket.io se disponível
        const io = req.io;
        if (io && data.userId) {
            if (event === 'message:received') {
                io.to(`user:${data.userId}`).emit('message:new', {
                    conversationId: data.conversationId,
                    message: data.message,
                });
            }
            else if (event === 'instance:status') {
                io.to(`user:${data.userId}`).emit('instance:status', {
                    instanceId: data.instanceId,
                    status: data.status,
                });
            }
            else if (event === 'qrcode:generated') {
                io.to(`user:${data.userId}`).emit('instance:qrcode', {
                    instanceId: data.instanceId,
                    qrCode: data.qrCode,
                });
            }
        }
        res.json({ success: true, message: 'Webhook processado' });
    }
    catch (error) {
        logger_1.logger.error('Erro ao processar webhook:', error);
        res.status(500).json({ error: 'Erro ao processar webhook' });
    }
});
/**
 * GET /api/webhooks/health
 * Verifica saúde do webhook
 */
router.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});
exports.default = router;
//# sourceMappingURL=webhooks.js.map