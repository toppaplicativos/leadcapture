export type PaymentMethodType = "pix" | "card" | "boleto" | "wallet";
export type InterestType = "none" | "merchant" | "customer";
export type PaymentSettings = {
    id: string;
    account_id: string;
    default_currency: string;
    auto_approve_orders: boolean;
    allow_pix: boolean;
    allow_card: boolean;
    allow_boleto: boolean;
    allow_wallet: boolean;
    created_at: string;
    updated_at: string;
};
export type PaymentGatewayRow = {
    id: string;
    account_id: string;
    gateway_name: string;
    public_key?: string | null;
    secret_key_encrypted?: string | null;
    webhook_secret?: string | null;
    environment: "sandbox" | "production";
    active: boolean;
    gateway_priority: number;
    created_at: string;
    updated_at: string;
};
export type PaymentMethodConfig = {
    id: string;
    account_id: string;
    method_type: PaymentMethodType;
    enabled: boolean;
    max_installments: number;
    min_installment_value: number;
    interest_type: InterestType;
    interest_percentage: number;
    fee_fixed: number;
    fee_percentage: number;
    created_at: string;
    updated_at: string;
};
export type PixKeyType = "cpf" | "cnpj" | "email" | "phone" | "random";
export type PixSettings = {
    id: string;
    account_id: string;
    provider: "manual" | "mercado_pago" | "efi" | "asaas" | "openpix";
    enabled: boolean;
    is_production: boolean;
    pix_key_type: PixKeyType;
    pix_key_value?: string | null;
    receiver_name: string;
    receiver_city: string;
    txid_prefix: string;
    default_description?: string | null;
    created_at: string;
    updated_at: string;
};
export type PixGenerateInput = {
    amount: number;
    description?: string;
    txid?: string;
};
export type PixGenerateResult = {
    copy_paste: string;
    qr_code_data_url: string;
    txid: string;
    amount: number;
    provider: string;
    mode: "test" | "production";
};
export type CouponRow = {
    id: string;
    account_id: string;
    code: string;
    discount_type: "percentage" | "fixed";
    value: number;
    expiration_date?: string | null;
    usage_limit?: number | null;
    used_count: number;
    active: boolean;
    created_at: string;
    updated_at: string;
};
export type ProductPaymentOverride = {
    id: string;
    account_id: string;
    product_id: string;
    allow_pix?: boolean | null;
    allow_card?: boolean | null;
    allow_boleto?: boolean | null;
    allow_wallet?: boolean | null;
    max_installments?: number | null;
    gateway_name?: string | null;
    created_at: string;
    updated_at: string;
};
export type PaymentCalculationInput = {
    account_id: string;
    method_type: PaymentMethodType;
    amount: number;
    installments?: number;
    coupon_code?: string;
    product_id?: string;
};
export type PaymentCalculationResult = {
    currency: string;
    method_type: PaymentMethodType;
    base_amount: number;
    coupon_discount: number;
    promo_discount: number;
    fee_fixed: number;
    fee_percentage_amount: number;
    interest_amount: number;
    final_amount: number;
    installments: number;
    installment_amount: number;
    interest_type: InterestType;
    interest_percentage: number;
    applied_coupon?: {
        id: string;
        code: string;
        discount_type: string;
        value: number;
    } | null;
    notes: string[];
};
export type PaymentTransactionRow = {
    id: string;
    account_id: string;
    order_id: string;
    gateway_name: string;
    provider_payment_id: string;
    method_type: PaymentMethodType;
    amount: number;
    currency: string;
    status: "pending" | "paid" | "failed" | "canceled";
    payment_url?: string | null;
    raw_response?: string | null;
    created_at: string;
    updated_at: string;
};
export declare class PaymentConfigService {
    private schemaReady;
    private schemaReadyPromise;
    private getEncryptionKey;
    private encryptSecret;
    decryptSecret(value?: string | null): string | null;
    private parseBool;
    private sanitizeCurrency;
    private toNumber;
    ensureSchema(): Promise<void>;
    private ensureDefaultMethodRows;
    getSettings(accountId: string): Promise<PaymentSettings>;
    updateSettings(accountId: string, payload: Partial<PaymentSettings>): Promise<PaymentSettings>;
    listGateways(accountId: string, includeSecrets?: boolean): Promise<Array<PaymentGatewayRow & {
        secret_key?: string | null;
    }>>;
    saveGateway(accountId: string, payload: Partial<PaymentGatewayRow> & {
        gateway_name: string;
    }): Promise<PaymentGatewayRow>;
    getGatewayByName(accountId: string, gatewayName: string): Promise<(PaymentGatewayRow & {
        secret_key?: string | null;
    }) | null>;
    listActiveGateways(accountId: string): Promise<Array<PaymentGatewayRow & {
        secret_key?: string | null;
    }>>;
    testGateway(accountId: string, gatewayId: string): Promise<{
        ok: boolean;
        reason?: string;
    }>;
    listMethodConfigs(accountId: string): Promise<PaymentMethodConfig[]>;
    getPixSettings(accountId: string): Promise<PixSettings>;
    updatePixSettings(accountId: string, payload: Partial<PixSettings>): Promise<PixSettings>;
    generatePixCharge(accountId: string, input: PixGenerateInput): Promise<PixGenerateResult>;
    private normalizePixText;
    private normalizePixMerchantName;
    private normalizePixMerchantCity;
    private normalizePixTxidPrefix;
    private normalizePixTxid;
    private emvField;
    private crc16Ccitt;
    private buildPixPayload;
    upsertMethodConfig(accountId: string, methodType: PaymentMethodType, payload: Partial<PaymentMethodConfig>): Promise<PaymentMethodConfig>;
    listCoupons(accountId: string): Promise<CouponRow[]>;
    saveCoupon(accountId: string, payload: Partial<CouponRow> & {
        code: string;
        discount_type: "percentage" | "fixed";
        value: number;
    }): Promise<CouponRow>;
    disableCoupon(accountId: string, couponId: string): Promise<boolean>;
    getValidCoupon(accountId: string, code?: string): Promise<CouponRow | null>;
    consumeCoupon(accountId: string, couponId: string): Promise<void>;
    getProductOverride(accountId: string, productId: string): Promise<ProductPaymentOverride | null>;
    upsertProductOverride(accountId: string, productId: string, payload: Partial<ProductPaymentOverride>): Promise<ProductPaymentOverride>;
    private isMethodAllowedBySettings;
    private isMethodAllowedByOverride;
    calculateFinalAmount(input: PaymentCalculationInput): Promise<PaymentCalculationResult>;
    getCheckoutOptions(accountId: string, input: {
        amount: number;
        product_id?: string;
        coupon_code?: string;
    }): Promise<{
        settings: PaymentSettings;
        methods: PaymentMethodConfig[];
        override: ProductPaymentOverride | null;
        previews: {
            method_type: PaymentMethodType;
            label: string;
            max_installments: number;
            estimate: PaymentCalculationResult;
        }[];
    }>;
    resolveGatewayForPayment(accountId: string, options?: {
        gatewayName?: string;
        productId?: string;
    }): Promise<(PaymentGatewayRow & {
        secret_key?: string | null;
    }) | null>;
    savePaymentTransaction(input: {
        id?: string;
        account_id: string;
        order_id: string;
        gateway_name: string;
        provider_payment_id: string;
        method_type: PaymentMethodType;
        amount: number;
        currency: string;
        status?: "pending" | "paid" | "failed" | "canceled";
        payment_url?: string | null;
        raw_response?: Record<string, any> | null;
    }): Promise<PaymentTransactionRow>;
    getTransactionByProviderPaymentId(providerPaymentId: string): Promise<PaymentTransactionRow | null>;
    updateTransactionStatus(providerPaymentId: string, status: "pending" | "paid" | "failed" | "canceled", rawResponse?: Record<string, any>): Promise<void>;
    writePaymentLog(input: {
        account_id: string;
        order_id?: string | null;
        gateway: string;
        request_payload?: Record<string, any>;
        response_payload?: Record<string, any>;
        status: string;
    }): Promise<void>;
    listPaymentLogs(accountId: string, orderId?: string): Promise<any[]>;
}
//# sourceMappingURL=paymentConfig.d.ts.map