import { AIAgentProfileService } from "./aiAgentProfile";
type GenerateWhatsAppReplyInput = {
    userId: string;
    brandId?: string | null;
    incomingMessage: string;
    conversationHistory?: string[];
    maxHistoryLines?: number;
};
type GenerateWhatsAppReplyResult = {
    text: string;
    profile: Awaited<ReturnType<AIAgentProfileService["getByUserId"]>>;
    knowledgeApplied: boolean;
    catalogApplied: boolean;
};
export declare class WhatsAppAgentService {
    private readonly aiService;
    private readonly aiAgentProfileService;
    private readonly knowledgeBaseService;
    private readonly productsService;
    private productsUserScopeReady;
    private normalizeBrandId;
    private ensureProductsUserScope;
    private buildCatalogContext;
    private getCatalogContext;
    private buildWhatsAppOperatingBlock;
    generateReply(input: GenerateWhatsAppReplyInput): Promise<GenerateWhatsAppReplyResult>;
}
export {};
//# sourceMappingURL=whatsappAgent.d.ts.map