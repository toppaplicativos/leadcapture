"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreativeStudioService = void 0;
const axios_1 = __importDefault(require("axios"));
const crypto_1 = require("crypto");
const fs_1 = require("fs");
const path_1 = __importDefault(require("path"));
const config_1 = require("../config");
const database_1 = require("../config/database");
const logger_1 = require("../utils/logger");
class CreativeStudioService {
    constructor() {
        this.baseUrl = "https://generativelanguage.googleapis.com/v1beta";
        this.videoJobs = new Map();
        this.assetsTableReady = false;
        this.creditsTableReady = false;
    }
    normalizeBrandId(brandId) {
        const normalized = String(brandId || "").trim();
        return normalized || null;
    }
    creditsAccountId(userId, brandId) {
        const normalizedBrandId = this.normalizeBrandId(brandId);
        return `${userId}::${normalizedBrandId || "__default__"}`;
    }
    extractAssetBrandId(metadata) {
        if (!metadata || typeof metadata !== "object")
            return null;
        const a = String(metadata.brandId || "").trim();
        const b = String(metadata.brand_id || "").trim();
        return a || b || null;
    }
    belongsToBrand(metadata, brandId) {
        const normalizedBrandId = this.normalizeBrandId(brandId);
        const assetBrandId = this.extractAssetBrandId(metadata);
        if (normalizedBrandId)
            return assetBrandId === normalizedBrandId;
        return !assetBrandId;
    }
    isGalleryGeneratedAsset(metadata) {
        const source = String(metadata?.source || "").trim().toLowerCase();
        if (!source)
            return true;
        if (source === "upload" || source === "studio-upload")
            return false;
        return !source.includes("upload");
    }
    getApiKey() {
        const apiKey = config_1.config.geminiApiKey;
        if (!apiKey)
            throw new Error("GEMINI_API_KEY is not configured");
        return apiKey;
    }
    sanitizePathPart(value) {
        return value.replace(/[^a-zA-Z0-9_-]/g, "_");
    }
    async ensureDir(dirPath) {
        await fs_1.promises.mkdir(dirPath, { recursive: true });
    }
    extractTextFromCandidate(candidate) {
        const parts = candidate?.content?.parts;
        if (!Array.isArray(parts))
            return "";
        const textPart = parts.find((part) => typeof part?.text === "string");
        return textPart?.text?.trim() || "";
    }
    parseJsonSafely(value) {
        if (!value)
            return undefined;
        if (typeof value === "object")
            return value;
        if (typeof value !== "string")
            return undefined;
        try {
            return JSON.parse(value);
        }
        catch {
            return undefined;
        }
    }
    toFormatFromAspect(aspectRatio) {
        if (aspectRatio === "9:16" || aspectRatio === "4:5")
            return "portrait";
        if (aspectRatio === "16:9")
            return "landscape";
        return "square";
    }
    currentMonthRef() {
        const now = new Date();
        const year = now.getUTCFullYear();
        const month = String(now.getUTCMonth() + 1).padStart(2, "0");
        return `${year}-${month}`;
    }
    normalizeTagList(tags) {
        if (!Array.isArray(tags))
            return [];
        return Array.from(new Set(tags
            .map((item) => String(item || "").trim().toLowerCase())
            .filter(Boolean))).slice(0, 24);
    }
    buildProductStudioPrompt(input, includeText = true) {
        const text = input.textOverlay || {};
        const pieces = [
            "Create a professional commercial product photo using the uploaded product image as the main object.",
            input.style ? `Style: ${input.style}.` : "Style: premium commercial.",
            input.scene ? `Scene: ${input.scene}.` : "Scene: clean studio setup.",
            input.lighting ? `Lighting: ${input.lighting}.` : "Lighting: soft daylight with realistic shadows.",
            input.targetAudience ? `Audience: ${input.targetAudience}.` : "Audience: conversion-focused marketing.",
            input.predominantColors ? `Predominant colors: ${input.predominantColors}.` : "",
            "Use realistic materials, accurate product proportions, high detail and premium ad composition.",
            input.transparentBackground
                ? "Prefer transparent or isolated product-friendly background where feasible."
                : "",
            includeText && (text.headline || text.subheadline || text.cta)
                ? [
                    "Integrate the following text in a clean commercial layout:",
                    text.headline ? `Headline: \"${text.headline}\"` : "",
                    text.subheadline ? `Subheadline: \"${text.subheadline}\"` : "",
                    text.cta ? `CTA: \"${text.cta}\"` : "",
                    text.position ? `Text position: ${text.position}.` : "",
                    text.style ? `Text style: ${text.style}.` : ""
                ]
                    .filter(Boolean)
                    .join("\n")
                : "Do not add any textual overlay.",
            "No watermark. Keep typography readable if text is included."
        ];
        return pieces.filter(Boolean).join("\n");
    }
    async loadAssetAsInlineData(userId, assetId) {
        const asset = await this.getAssetById(userId, assetId);
        if (!asset || asset.type !== "image" || !asset.fileUrl) {
            throw new Error(`Image asset not found: ${assetId}`);
        }
        const absolute = this.buildFileAbsolutePath(asset.fileUrl);
        const buffer = await fs_1.promises.readFile(absolute);
        return {
            mimeType: this.getMimeTypeFromPath(absolute),
            data: buffer.toString("base64"),
            fileUrl: asset.fileUrl
        };
    }
    async requestImageFromParts(userId, model, prompt, imageInlineParts) {
        const apiKey = this.getApiKey();
        const response = await axios_1.default.post(`${this.baseUrl}/models/${model}:generateContent`, {
            contents: [
                {
                    parts: [
                        { text: prompt },
                        ...imageInlineParts.map((part) => ({
                            inlineData: {
                                mimeType: part.mimeType,
                                data: part.data
                            }
                        }))
                    ]
                }
            ]
        }, {
            params: { key: apiKey },
            timeout: 120000
        });
        const candidate = response.data?.candidates?.[0];
        const parts = candidate?.content?.parts || [];
        const imagePart = parts.find((part) => part?.inlineData?.data || part?.inline_data?.data);
        const caption = this.extractTextFromCandidate(candidate);
        const base64Image = imagePart?.inlineData?.data || imagePart?.inline_data?.data;
        if (!base64Image) {
            throw new Error("Image generation returned no inline image data");
        }
        const safeUserId = this.sanitizePathPart(userId);
        const fileName = `${Date.now()}-${(0, crypto_1.randomUUID)()}-studio.png`;
        const absoluteDir = path_1.default.resolve(process.cwd(), "uploads", "creatives", "images", safeUserId);
        await this.ensureDir(absoluteDir);
        const filePath = path_1.default.join(absoluteDir, fileName);
        await fs_1.promises.writeFile(filePath, Buffer.from(base64Image, "base64"));
        return {
            imageUrl: `/uploads/creatives/images/${safeUserId}/${fileName}`,
            caption
        };
    }
    buildFileAbsolutePath(fileUrl) {
        const normalized = fileUrl.replace(/\\/g, "/");
        const uploadsRoot = path_1.default.resolve(process.cwd(), "uploads");
        const relative = normalized.startsWith("/uploads/") ? normalized.slice("/uploads/".length) : normalized;
        const candidate = path_1.default.resolve(uploadsRoot, relative);
        if (!candidate.startsWith(uploadsRoot)) {
            throw new Error("Invalid file path");
        }
        return candidate;
    }
    getMimeTypeFromPath(filePath) {
        const ext = path_1.default.extname(filePath).toLowerCase();
        if (ext === ".jpg" || ext === ".jpeg")
            return "image/jpeg";
        if (ext === ".webp")
            return "image/webp";
        return "image/png";
    }
    mapAssetRow(row) {
        return {
            id: String(row.id),
            type: row.asset_type,
            prompt: row.prompt || undefined,
            model: row.model || undefined,
            status: row.status,
            text: row.text_content || undefined,
            fileUrl: row.file_url || undefined,
            parentAssetId: row.parent_asset_id || undefined,
            metadata: this.parseJsonSafely(row.metadata),
            error: row.error_message || undefined,
            createdAt: new Date(row.created_at).toISOString(),
            updatedAt: new Date(row.updated_at).toISOString()
        };
    }
    async ensureAssetsTable() {
        if (this.assetsTableReady)
            return;
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS creative_assets (
        id VARCHAR(36) NOT NULL PRIMARY KEY,
        user_id VARCHAR(36) NOT NULL,
        asset_type ENUM('text','image','video') NOT NULL,
        prompt TEXT NULL,
        model VARCHAR(120) NULL,
        status ENUM('processing','completed','failed') NOT NULL DEFAULT 'completed',
        text_content TEXT NULL,
        file_url TEXT NULL,
        parent_asset_id VARCHAR(36) NULL,
        operation_name VARCHAR(255) NULL,
        error_message TEXT NULL,
        metadata JSON NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_creative_assets_user_created (user_id, created_at),
        INDEX idx_creative_assets_user_type (user_id, asset_type),
        INDEX idx_creative_assets_parent (parent_asset_id)
      )
    `);
        this.assetsTableReady = true;
    }
    async ensureCreditsTable() {
        if (this.creditsTableReady)
            return;
        await (0, database_1.query)(`
      CREATE TABLE IF NOT EXISTS creative_account_credits (
        account_id VARCHAR(120) NOT NULL PRIMARY KEY,
        images_generated_month INT NOT NULL DEFAULT 0,
        credits_remaining INT NOT NULL DEFAULT 200,
        monthly_limit INT NOT NULL DEFAULT 200,
        month_ref VARCHAR(7) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
        await (0, database_1.query)("ALTER TABLE creative_account_credits ALTER COLUMN account_id TYPE VARCHAR(120)").catch(() => undefined);
        this.creditsTableReady = true;
    }
    async ensureCreditsRow(userId, brandId) {
        await this.ensureCreditsTable();
        const accountId = this.creditsAccountId(userId, brandId);
        const monthRef = this.currentMonthRef();
        await (0, database_1.query)(`INSERT INTO creative_account_credits (account_id, images_generated_month, credits_remaining, monthly_limit, month_ref)
       VALUES (?, 0, 200, 200, ?)
       ON CONFLICT (account_id) DO NOTHING`, [accountId, monthRef]);
        const row = await (0, database_1.queryOne)(`SELECT account_id, images_generated_month, credits_remaining, monthly_limit, month_ref
       FROM creative_account_credits
       WHERE account_id = ? LIMIT 1`, [accountId]);
        if (!row)
            return;
        if (String(row.month_ref || "") !== monthRef) {
            await (0, database_1.update)(`UPDATE creative_account_credits
         SET images_generated_month = 0,
             credits_remaining = monthly_limit,
             month_ref = ?
         WHERE account_id = ?`, [monthRef, accountId]);
        }
    }
    async getProductStudioCredits(userId, brandId) {
        await this.ensureCreditsRow(userId, brandId);
        const accountId = this.creditsAccountId(userId, brandId);
        const row = await (0, database_1.queryOne)(`SELECT account_id, images_generated_month, credits_remaining, monthly_limit, month_ref
       FROM creative_account_credits
       WHERE account_id = ? LIMIT 1`, [accountId]);
        return {
            accountId: String(row?.account_id || accountId),
            imagesGeneratedMonth: Number(row?.images_generated_month || 0),
            creditsRemaining: Number(row?.credits_remaining || 0),
            monthlyLimit: Number(row?.monthly_limit || 0),
            monthRef: String(row?.month_ref || this.currentMonthRef())
        };
    }
    async consumeProductStudioCredits(userId, amount = 1, brandId) {
        await this.ensureCreditsRow(userId, brandId);
        const accountId = this.creditsAccountId(userId, brandId);
        const toConsume = Math.max(1, Math.floor(amount));
        const credits = await this.getProductStudioCredits(userId, brandId);
        if (credits.creditsRemaining < toConsume) {
            throw new Error("Insufficient credits for image generation");
        }
        await (0, database_1.update)(`UPDATE creative_account_credits
       SET credits_remaining = credits_remaining - ?,
           images_generated_month = images_generated_month + ?
       WHERE account_id = ?`, [toConsume, toConsume, accountId]);
        return this.getProductStudioCredits(userId, brandId);
    }
    async saveAsset(input) {
        await this.ensureAssetsTable();
        const id = (0, crypto_1.randomUUID)();
        const mergedMetadata = {
            ...(input.metadata || {}),
            brandId: this.normalizeBrandId(input.brandId),
        };
        await (0, database_1.query)(`INSERT INTO creative_assets
       (id, user_id, asset_type, prompt, model, status, text_content, file_url, parent_asset_id, operation_name, error_message, metadata)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            id,
            input.userId,
            input.type,
            input.prompt || null,
            input.model || null,
            input.status || "completed",
            input.text || null,
            input.fileUrl || null,
            input.parentAssetId || null,
            input.operationName || null,
            input.error || null,
            JSON.stringify(mergedMetadata)
        ]);
        const created = await (0, database_1.queryOne)("SELECT * FROM creative_assets WHERE id = ?", [id]);
        if (!created)
            throw new Error("Failed to persist creative asset");
        return this.mapAssetRow(created);
    }
    async updateAssetById(userId, id, patch, brandId) {
        await this.ensureAssetsTable();
        const fields = [];
        const values = [];
        if (patch.status) {
            fields.push("status = ?");
            values.push(patch.status);
        }
        if (patch.fileUrl !== undefined) {
            fields.push("file_url = ?");
            values.push(patch.fileUrl || null);
        }
        if (patch.error !== undefined) {
            fields.push("error_message = ?");
            values.push(patch.error || null);
        }
        if (patch.metadata !== undefined) {
            fields.push("metadata = ?");
            values.push(JSON.stringify(patch.metadata || {}));
        }
        if (fields.length > 0) {
            values.push(id, userId);
            await (0, database_1.update)(`UPDATE creative_assets SET ${fields.join(", ")} WHERE id = ? AND user_id = ?`, values);
        }
        const row = await (0, database_1.queryOne)("SELECT * FROM creative_assets WHERE id = ? AND user_id = ?", [id, userId]);
        if (!row)
            return null;
        const mapped = this.mapAssetRow(row);
        if (!this.belongsToBrand(mapped.metadata, brandId))
            return null;
        return mapped;
    }
    async listAssets(userId, filters, brandId) {
        await this.ensureAssetsTable();
        let where = "WHERE user_id = ?";
        const params = [userId];
        if (filters?.type) {
            where += " AND asset_type = ?";
            params.push(filters.type);
        }
        if (filters?.search) {
            where += " AND (prompt LIKE ? OR text_content LIKE ?)";
            const s = `%${filters.search}%`;
            params.push(s, s);
        }
        const limit = Math.max(1, Math.min(100, filters?.limit || 30));
        const offset = Math.max(0, filters?.offset || 0);
        const rows = await (0, database_1.query)(`SELECT * FROM creative_assets ${where} ORDER BY created_at DESC`, params);
        const includeUploads = Boolean(filters?.includeUploads);
        const allAssets = rows
            .map((row) => this.mapAssetRow(row))
            .filter((asset) => this.belongsToBrand(asset.metadata, brandId))
            .filter((asset) => (includeUploads ? true : this.isGalleryGeneratedAsset(asset.metadata)));
        const total = allAssets.length;
        const assets = allAssets.slice(offset, offset + limit);
        return { assets, total };
    }
    async getAssetById(userId, assetId, brandId) {
        await this.ensureAssetsTable();
        const row = await (0, database_1.queryOne)("SELECT * FROM creative_assets WHERE id = ? AND user_id = ? LIMIT 1", [assetId, userId]);
        if (!row)
            return null;
        const mapped = this.mapAssetRow(row);
        if (!this.belongsToBrand(mapped.metadata, brandId))
            return null;
        return mapped;
    }
    async registerUploadedImage(userId, input, brandId) {
        await this.ensureAssetsTable();
        const imageUrl = String(input.fileUrl || "").trim();
        if (!imageUrl) {
            throw new Error("Image file URL is required");
        }
        const caption = String(input.caption || "").trim();
        const prompt = String(input.prompt || caption || input.originalName || "Upload manual de imagem").trim();
        const model = "upload-manual";
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "image",
            prompt,
            model,
            status: "completed",
            fileUrl: imageUrl,
            metadata: {
                caption,
                source: "upload",
                originalName: input.originalName || null
            }
        });
        return {
            imageUrl,
            caption,
            model,
            asset
        };
    }
    async registerStudioImage(userId, input, brandId) {
        const imageType = input.imageType || "product";
        const tags = this.normalizeTagList(input.tags);
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "image",
            prompt: input.caption || `Upload ${imageType}`,
            model: "upload-manual",
            status: "completed",
            fileUrl: input.fileUrl,
            metadata: {
                studio: {
                    imageType,
                    productId: input.productId || null,
                    tags,
                    usedInCampaign: false,
                    version: 1
                },
                caption: input.caption || "",
                source: "studio-upload",
                originalName: input.originalName || null
            }
        });
        return asset;
    }
    async generateText(userId, input, brandId) {
        const model = config_1.config.creatives.textModel;
        const apiKey = this.getApiKey();
        const instruction = [
            "Voce e um especialista em marketing de performance para campanhas de WhatsApp.",
            "Responda em portugues, direto ao ponto, com alta conversao.",
            input.tone ? `Tom desejado: ${input.tone}.` : "",
            input.objective ? `Objetivo da peca: ${input.objective}.` : "",
            input.audience ? `Publico alvo: ${input.audience}.` : "",
            input.maxCharacters ? `Limite maximo de ${input.maxCharacters} caracteres.` : "",
            "Entregue somente o texto final, sem markdown."
        ]
            .filter(Boolean)
            .join("\n");
        const response = await axios_1.default.post(`${this.baseUrl}/models/${model}:generateContent`, {
            contents: [
                {
                    parts: [
                        {
                            text: `${instruction}\n\nPedido:\n${input.prompt}`
                        }
                    ]
                }
            ]
        }, {
            params: { key: apiKey },
            timeout: 30000
        });
        const text = this.extractTextFromCandidate(response.data?.candidates?.[0]);
        if (!text)
            throw new Error("Model did not return text content");
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "text",
            prompt: input.prompt,
            model,
            status: "completed",
            text,
            metadata: {
                tone: input.tone || null,
                objective: input.objective || null,
                audience: input.audience || null,
                maxCharacters: input.maxCharacters || null
            }
        });
        return { text, model, asset };
    }
    async generateImage(userId, input, brandId) {
        const model = config_1.config.creatives.imageModel;
        const apiKey = this.getApiKey();
        const formatHint = input.format === "portrait"
            ? "Formato vertical 9:16."
            : input.format === "landscape"
                ? "Formato horizontal 16:9."
                : "Formato quadrado 1:1.";
        const prompt = [input.prompt, input.style ? `Estilo visual: ${input.style}.` : "", formatHint, "Nao incluir marcas d'agua."]
            .filter(Boolean)
            .join("\n");
        const response = await axios_1.default.post(`${this.baseUrl}/models/${model}:generateContent`, { contents: [{ parts: [{ text: prompt }] }] }, { params: { key: apiKey }, timeout: 60000 });
        const candidate = response.data?.candidates?.[0];
        const parts = candidate?.content?.parts || [];
        const imagePart = parts.find((part) => part?.inlineData?.data || part?.inline_data?.data);
        const caption = this.extractTextFromCandidate(candidate);
        const base64Image = imagePart?.inlineData?.data || imagePart?.inline_data?.data;
        if (!base64Image)
            throw new Error("Image generation returned no inline image data");
        const safeUserId = this.sanitizePathPart(userId);
        const fileName = `${Date.now()}-${(0, crypto_1.randomUUID)()}.png`;
        const absoluteDir = path_1.default.resolve(process.cwd(), "uploads", "creatives", "images", safeUserId);
        await this.ensureDir(absoluteDir);
        const filePath = path_1.default.join(absoluteDir, fileName);
        await fs_1.promises.writeFile(filePath, Buffer.from(base64Image, "base64"));
        const imageUrl = `/uploads/creatives/images/${safeUserId}/${fileName}`;
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "image",
            prompt: input.prompt,
            model,
            status: "completed",
            fileUrl: imageUrl,
            metadata: {
                caption,
                style: input.style || null,
                format: input.format || "square",
            },
        });
        return { imageUrl, caption, model, asset };
    }
    async remixImage(userId, input, brandId) {
        const model = config_1.config.creatives.imageModel;
        const apiKey = this.getApiKey();
        await this.ensureAssetsTable();
        let parentAssetId;
        let sourceUrl = input.sourceUrl;
        if (input.sourceAssetId) {
            const sourceAsset = await this.getAssetById(userId, input.sourceAssetId, brandId);
            if (!sourceAsset || sourceAsset.type !== "image" || !sourceAsset.fileUrl) {
                throw new Error("Source image asset not found");
            }
            sourceUrl = sourceAsset.fileUrl;
            parentAssetId = sourceAsset.id;
        }
        if (!sourceUrl) {
            throw new Error("sourceAssetId or sourceUrl is required");
        }
        const sourcePath = this.buildFileAbsolutePath(sourceUrl);
        const sourceBuffer = await fs_1.promises.readFile(sourcePath);
        const sourceBase64 = sourceBuffer.toString("base64");
        const mimeType = this.getMimeTypeFromPath(sourcePath);
        const formatHint = input.format === "portrait"
            ? "Formato de saida vertical 9:16."
            : input.format === "landscape"
                ? "Formato de saida horizontal 16:9."
                : "Formato de saida quadrado 1:1.";
        const prompt = [
            "Edite/remixe a imagem enviada mantendo qualidade comercial.",
            input.instructions,
            input.style ? `Estilo desejado: ${input.style}.` : "",
            formatHint,
            "Nao incluir texto ilegivel nem marca d'agua.",
        ]
            .filter(Boolean)
            .join("\n");
        const response = await axios_1.default.post(`${this.baseUrl}/models/${model}:generateContent`, {
            contents: [
                {
                    parts: [
                        { text: prompt },
                        { inlineData: { mimeType, data: sourceBase64 } },
                    ],
                },
            ],
        }, { params: { key: apiKey }, timeout: 90000 });
        const candidate = response.data?.candidates?.[0];
        const parts = candidate?.content?.parts || [];
        const imagePart = parts.find((part) => part?.inlineData?.data || part?.inline_data?.data);
        const caption = this.extractTextFromCandidate(candidate);
        const base64Image = imagePart?.inlineData?.data || imagePart?.inline_data?.data;
        if (!base64Image)
            throw new Error("Image remix returned no inline image data");
        const safeUserId = this.sanitizePathPart(userId);
        const fileName = `${Date.now()}-${(0, crypto_1.randomUUID)()}-remix.png`;
        const absoluteDir = path_1.default.resolve(process.cwd(), "uploads", "creatives", "images", safeUserId);
        await this.ensureDir(absoluteDir);
        const filePath = path_1.default.join(absoluteDir, fileName);
        await fs_1.promises.writeFile(filePath, Buffer.from(base64Image, "base64"));
        const imageUrl = `/uploads/creatives/images/${safeUserId}/${fileName}`;
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "image",
            prompt: input.instructions,
            model,
            status: "completed",
            fileUrl: imageUrl,
            parentAssetId,
            metadata: {
                caption,
                style: input.style || null,
                format: input.format || "square",
                sourceUrl,
            },
        });
        return { imageUrl, caption, model, asset };
    }
    async generateProductStudioImages(userId, input, brandId) {
        const model = config_1.config.creatives.imageModel;
        await this.ensureAssetsTable();
        const formatsRaw = Array.isArray(input.formats) && input.formats.length > 0 ? input.formats : [input.aspectRatio || "1:1"];
        const formats = formatsRaw.slice(0, 4);
        const variations = Math.max(1, Math.min(4, Math.floor(input.variations || 1)));
        const withAndWithoutText = !!input.withAndWithoutText;
        const promptVersions = withAndWithoutText ? [true, false] : [true];
        const jobsCount = formats.length * variations * promptVersions.length;
        await this.consumeProductStudioCredits(userId, jobsCount, brandId);
        const sourceAssetIds = [];
        if (input.productAssetId)
            sourceAssetIds.push(input.productAssetId);
        if (input.backgroundAssetId)
            sourceAssetIds.push(input.backgroundAssetId);
        if (Array.isArray(input.referenceAssetIds))
            sourceAssetIds.push(...input.referenceAssetIds.filter(Boolean));
        const uniqueSourceIds = Array.from(new Set(sourceAssetIds)).slice(0, 6);
        const inlineRefs = await Promise.all(uniqueSourceIds.map(async (assetId) => this.loadAssetAsInlineData(userId, assetId)));
        const createdAssets = [];
        const tags = this.normalizeTagList(input.tags);
        for (const format of formats) {
            const normalizedFormat = this.toFormatFromAspect(format);
            for (let i = 0; i < variations; i += 1) {
                for (const includeText of promptVersions) {
                    const prompt = this.buildProductStudioPrompt({ ...input, aspectRatio: format }, includeText);
                    const result = await this.requestImageFromParts(userId, model, `${prompt}\n\nOutput ratio target: ${format}.`, inlineRefs.map((item) => ({ mimeType: item.mimeType, data: item.data })));
                    const asset = await this.saveAsset({
                        userId,
                        brandId,
                        type: "image",
                        prompt,
                        model,
                        status: "completed",
                        fileUrl: result.imageUrl,
                        metadata: {
                            caption: result.caption,
                            studio: {
                                module: "product-ai-studio",
                                productId: input.productId || null,
                                sourceAssetIds: uniqueSourceIds,
                                format,
                                normalizedFormat,
                                variationIndex: i + 1,
                                textIncluded: includeText,
                                quality: input.quality || "high",
                                tags,
                                usedInCampaign: false,
                                version: 1,
                            },
                        },
                    });
                    createdAssets.push(asset);
                }
            }
        }
        const credits = await this.getProductStudioCredits(userId, brandId);
        return { assets: createdAssets, model, credits };
    }
    async editProductStudioImage(userId, input, brandId) {
        const sourceAsset = await this.getAssetById(userId, input.sourceAssetId, brandId);
        if (!sourceAsset || sourceAsset.type !== "image" || !sourceAsset.fileUrl) {
            throw new Error("Source image asset not found");
        }
        await this.consumeProductStudioCredits(userId, 1, brandId);
        const sourceInline = await this.loadAssetAsInlineData(userId, input.sourceAssetId);
        const model = config_1.config.creatives.imageModel;
        const prompt = [
            "Modify the existing image according to the instruction while preserving commercial realism.",
            input.preserveProduct !== false ? "Keep the product unchanged." : "",
            input.style ? `Target style: ${input.style}.` : "",
            input.aspectRatio ? `Output ratio target: ${input.aspectRatio}.` : "",
            `Instruction: ${input.instruction}`,
            "No watermark.",
        ]
            .filter(Boolean)
            .join("\n");
        const result = await this.requestImageFromParts(userId, model, prompt, [{ mimeType: sourceInline.mimeType, data: sourceInline.data }]);
        const tags = this.normalizeTagList(input.tags);
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "image",
            prompt,
            model,
            status: "completed",
            fileUrl: result.imageUrl,
            parentAssetId: sourceAsset.id,
            metadata: {
                caption: result.caption,
                studio: {
                    module: "product-ai-studio",
                    editMode: true,
                    sourceAssetIds: [sourceAsset.id],
                    tags,
                    usedInCampaign: false,
                    version: Number(sourceAsset.metadata?.studio?.version || 1) + 1,
                    aspectRatio: input.aspectRatio || null,
                },
            },
        });
        const credits = await this.getProductStudioCredits(userId, brandId);
        return { asset, model, credits };
    }
    async listProductStudioGallery(userId, filters, brandId) {
        const list = await this.listAssets(userId, {
            type: "image",
            limit: Math.max(1, Math.min(200, filters?.limit || 60)),
            offset: Math.max(0, filters?.offset || 0),
            includeUploads: true,
        }, brandId);
        const filtered = list.assets.filter((asset) => {
            const studio = asset.metadata?.studio;
            if (!studio)
                return false;
            if (filters?.productId && String(studio.productId || "") !== String(filters.productId))
                return false;
            if (filters?.format && String(studio.format || "") !== String(filters.format))
                return false;
            if (typeof filters?.usedInCampaign === "boolean" && Boolean(studio.usedInCampaign) !== filters.usedInCampaign)
                return false;
            if (filters?.tag) {
                const tags = Array.isArray(studio.tags) ? studio.tags.map((item) => String(item)) : [];
                if (!tags.includes(String(filters.tag).toLowerCase()))
                    return false;
            }
            return true;
        });
        return { assets: filtered, total: filtered.length };
    }
    async markAssetUsedInCampaign(userId, assetId, campaignId, brandId) {
        const asset = await this.getAssetById(userId, assetId, brandId);
        if (!asset)
            return null;
        const metadata = {
            ...(asset.metadata || {}),
            studio: {
                ...(asset.metadata?.studio || {}),
                usedInCampaign: true,
                usedInCampaignAt: new Date().toISOString(),
                campaignId: campaignId || null,
            },
        };
        return this.updateAssetById(userId, assetId, { metadata }, brandId);
    }
    async startVideoGeneration(userId, input, brandId) {
        const model = config_1.config.creatives.videoModel;
        const apiKey = this.getApiKey();
        const body = { instances: [{ prompt: input.prompt }] };
        if (input.aspectRatio)
            body.parameters = { aspectRatio: input.aspectRatio };
        const response = await axios_1.default.post(`${this.baseUrl}/models/${model}:predictLongRunning`, body, {
            params: { key: apiKey },
            timeout: 30000,
        });
        const operationName = response.data?.name;
        if (!operationName)
            throw new Error("Video generation operation was not created");
        const asset = await this.saveAsset({
            userId,
            brandId,
            type: "video",
            prompt: input.prompt,
            model,
            status: "processing",
            operationName,
            metadata: { aspectRatio: input.aspectRatio || "16:9" },
        });
        const job = {
            id: asset.id,
            userId,
            prompt: input.prompt,
            operationName,
            status: "processing",
            model,
            createdAt: asset.createdAt,
        };
        this.videoJobs.set(job.id, job);
        return job;
    }
    async getVideoJob(userId, jobId, brandId) {
        await this.ensureAssetsTable();
        let job = this.videoJobs.get(jobId);
        if (!job || job.userId !== userId) {
            const row = await (0, database_1.queryOne)("SELECT * FROM creative_assets WHERE id = ? AND user_id = ? AND asset_type = 'video' LIMIT 1", [jobId, userId]);
            if (!row)
                return null;
            const mapped = this.mapAssetRow(row);
            if (!this.belongsToBrand(mapped.metadata, brandId))
                return null;
            job = {
                id: String(row.id),
                userId: String(row.user_id),
                prompt: row.prompt || "",
                operationName: row.operation_name || "",
                status: row.status,
                model: row.model || config_1.config.creatives.videoModel,
                createdAt: new Date(row.created_at).toISOString(),
                error: row.error_message || undefined,
                videoUrl: row.file_url || undefined,
            };
            this.videoJobs.set(job.id, job);
        }
        if (job.status === "completed" || job.status === "failed")
            return job;
        const apiKey = this.getApiKey();
        try {
            const operationResponse = await axios_1.default.get(`${this.baseUrl}/${job.operationName}`, {
                params: { key: apiKey },
                timeout: 20000,
            });
            const op = operationResponse.data;
            if (!op?.done)
                return job;
            if (op?.error) {
                job.status = "failed";
                job.error = op.error?.message || "Video generation failed";
                await this.updateAssetById(userId, job.id, { status: "failed", error: job.error }, brandId);
                return job;
            }
            const videoUri = op?.response?.generateVideoResponse?.generatedSamples?.[0]?.video?.uri ||
                op?.response?.generatedSamples?.[0]?.video?.uri;
            if (!videoUri) {
                job.status = "failed";
                job.error = "Video operation completed without downloadable URI";
                await this.updateAssetById(userId, job.id, { status: "failed", error: job.error }, brandId);
                return job;
            }
            const safeUserId = this.sanitizePathPart(userId);
            const fileName = `${Date.now()}-${(0, crypto_1.randomUUID)()}.mp4`;
            const absoluteDir = path_1.default.resolve(process.cwd(), "uploads", "creatives", "videos", safeUserId);
            await this.ensureDir(absoluteDir);
            const filePath = path_1.default.join(absoluteDir, fileName);
            const fileResponse = await axios_1.default.get(videoUri, {
                headers: { "x-goog-api-key": apiKey },
                responseType: "arraybuffer",
                timeout: 180000,
            });
            await fs_1.promises.writeFile(filePath, Buffer.from(fileResponse.data));
            job.status = "completed";
            job.videoUrl = `/uploads/creatives/videos/${safeUserId}/${fileName}`;
            await this.updateAssetById(userId, job.id, {
                status: "completed",
                fileUrl: job.videoUrl,
                error: "",
                metadata: {
                    ...(await this.getAssetById(userId, job.id, brandId))?.metadata,
                    sourceVideoUri: videoUri,
                },
            }, brandId);
            return job;
        }
        catch (error) {
            logger_1.logger.error(`Video status check failed: ${error.message}`);
            job.status = "failed";
            job.error = error.message || "Unexpected error while checking video job";
            await this.updateAssetById(userId, job.id, { status: "failed", error: job.error }, brandId);
            return job;
        }
    }
}
exports.CreativeStudioService = CreativeStudioService;
//# sourceMappingURL=creativeStudio.js.map