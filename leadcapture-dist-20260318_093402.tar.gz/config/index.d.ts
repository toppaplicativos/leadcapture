export declare const config: {
    port: number;
    googlePlacesApiKey: string;
    geminiApiKey: string;
    nodeEnv: string;
    authDir: string;
    mysql: {
        host: string;
        port: number;
        user: string;
        password: string;
        database: string;
        connectionLimit: number;
    };
    postgres: {
        connectionString: string;
        host: string;
        port: number;
        user: string;
        password: string;
        database: string;
        ssl: boolean;
        max: number;
    };
    jwtSecret: string;
    jwtExpiresIn: string;
    rapidApi: {
        key: string;
        host: string;
        baseUrl: string;
    };
    creatives: {
        textModel: string;
        imageModel: string;
        videoModel: string;
    };
};
//# sourceMappingURL=index.d.ts.map