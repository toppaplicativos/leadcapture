export interface Client {
    id: string;
    user_id: string;
    company_id?: string;
    name: string;
    phone?: string;
    email?: string;
    cpf?: string;
    birth_date?: Date;
    address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    tags?: string[];
    notes?: string;
    source: string;
    lead_score: number;
    status: string;
    last_contact_at?: Date;
    custom_fields?: Record<string, any>;
    is_active: boolean;
    created_at: Date;
    updated_at: Date;
}
export interface ClientCreateDTO {
    name: string;
    company_id?: string;
    phone?: string;
    email?: string;
    cpf?: string;
    birth_date?: string;
    address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    tags?: string[];
    notes?: string;
    source?: string;
    lead_score?: number;
    status?: string;
    custom_fields?: Record<string, any>;
}
export interface ClientFilters {
    status?: string;
    source?: string;
    company_id?: string;
    brand_id?: string;
    search?: string;
    page?: number;
    limit?: number;
}
export declare class ClientsService {
    private columnsCache;
    private normalizePhone;
    private getClientColumns;
    private findExistingImportedClient;
    create(userId: string, data: ClientCreateDTO, brandId?: string | null): Promise<Client>;
    getById(id: string, userId: string, brandId?: string | null): Promise<Client | null>;
    getAll(userId: string, filters?: ClientFilters): Promise<{
        clients: Client[];
        total: number;
    }>;
    update(id: string, userId: string, data: Partial<ClientCreateDTO>, brandId?: string | null): Promise<Client | null>;
    updateStatus(id: string, userId: string, status: string, brandId?: string | null): Promise<Client | null>;
    delete(id: string, userId: string, brandId?: string | null): Promise<boolean>;
    importFromLeads(userId: string, leads: any[], source?: string, brandId?: string | null): Promise<number>;
}
//# sourceMappingURL=clients.d.ts.map