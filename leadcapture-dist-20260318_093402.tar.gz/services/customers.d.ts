import { Customer, CustomerCreateDTO } from "../types";
export type LeadCaptureContext = {
    query: string;
    location: string;
    radius?: number;
};
export type CapturedGeoPoint = {
    id: string | number;
    name: string;
    latitude: number;
    longitude: number;
    status: string;
    category?: string;
    queryLabels: string[];
};
export type LeadStats = {
    total: number;
    today_count: number;
    week_count: number;
    month_count: number;
    with_whatsapp: number;
    without_whatsapp: number;
    whatsapp_validated_count: number;
};
export type WhatsAppValidationUpdateInput = {
    hasWhatsApp: boolean;
    checkedAt?: string;
    instanceId?: string;
    normalizedPhone?: string;
    jid?: string;
    status?: "valid" | "invalid" | "error";
};
export declare class CustomersService {
    private columnsCache;
    private schemaEnsured;
    private schemaEnsurePromise;
    private ensureIsolationSchema;
    private getColumns;
    private hasColumn;
    private resolveOwnerColumn;
    private requireOwnerColumn;
    private appendOwnerClause;
    private resolveBrandColumn;
    private appendBrandClause;
    private normalizeColumnValue;
    private insertDynamicCustomer;
    private normalizePhone;
    private normalizeQueryLabel;
    private extractAddress;
    private extractCityState;
    private parseSourceDetails;
    private parseTags;
    private resolveHasWhatsAppExpression;
    private resolveWithoutWhatsAppExpression;
    private resolveWhatsAppValidatedExpression;
    private updateCaptureMetadata;
    private findExistingByPlaceOrPhone;
    create(dto: CustomerCreateDTO, ownerUserId?: string, brandId?: string | null): Promise<Customer>;
    bulkCreateFromPlaces(places: any[], ownerUserId?: string, captureContext?: LeadCaptureContext, brandId?: string | null): Promise<{
        created: number;
        skipped: number;
        createdPlaceIds: string[];
        createdLeadIds: string[];
        existingPlaceIds: string[];
    }>;
    getCapturedGeoPoints(ownerUserId?: string, limit?: number, brandId?: string | null): Promise<CapturedGeoPoint[]>;
    getById(id: string | number, ownerUserId?: string, brandId?: string | null): Promise<Customer | null>;
    getAll(filters?: {
        status?: string;
        source?: string;
        category?: string;
        city?: string;
        search?: string;
        limit?: number;
        offset?: number;
        ownerUserId?: string;
        brandId?: string | null;
        whatsappFilter?: "pending" | "confirmed" | "unconfirmed";
    }): Promise<{
        customers: Customer[];
        total: number;
    }>;
    updateCustomer(id: string | number, data: Partial<CustomerCreateDTO>, ownerUserId?: string, brandId?: string | null): Promise<Customer | null>;
    updateStatus(id: string | number, status: string, ownerUserId?: string, brandId?: string | null): Promise<boolean>;
    delete(id: string | number, ownerUserId?: string, brandId?: string | null): Promise<boolean>;
    getLeadStats(ownerUserId?: string, brandId?: string | null): Promise<LeadStats>;
    updateWhatsAppValidation(id: string | number, payload: WhatsAppValidationUpdateInput, ownerUserId?: string, brandId?: string | null): Promise<Customer | null>;
    getStats(ownerUserId?: string, brandId?: string | null): Promise<any>;
}
//# sourceMappingURL=customers.d.ts.map