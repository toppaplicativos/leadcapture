"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const http_1 = require("http");
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
// Importar rotas
const auth_1 = __importDefault(require("./routes/auth"));
const inbox_1 = __importDefault(require("./routes/inbox"));
const instances_1 = __importDefault(require("./routes/instances"));
const webhooks_1 = __importDefault(require("./routes/webhooks"));
const ai_1 = __importDefault(require("./routes/ai"));
const messages_1 = __importDefault(require("./routes/messages"));
const leads_1 = __importDefault(require("./routes/leads"));
const products_1 = __importDefault(require("./routes/products"));
// Carregar variáveis de ambiente
dotenv_1.default.config();
// ============================================
// INICIALIZAÇÃO
// ============================================
const app = (0, express_1.default)();
const httpServer = (0, http_1.createServer)(app);
// Porta
const PORT = process.env.PORT || 3001;
const NODE_ENV = process.env.NODE_ENV || 'development';
// ============================================
// MIDDLEWARE GLOBAL
// ============================================
// CORS
app.use((0, cors_1.default)({
    origin: process.env.NEXT_PUBLIC_APP_URL || true,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'x-brand-id'],
}));
// Body parser
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ limit: '10mb', extended: true }));
// Servir arquivos estáticos
app.use(express_1.default.static(path_1.default.join(__dirname, '../public')));
app.use('/uploads', express_1.default.static(path_1.default.join(__dirname, '../uploads')));
// Logging de requisições
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        console.log();
    });
    next();
});
// ============================================
// ROTAS PÚBLICAS
// ============================================
// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: NODE_ENV,
    });
});
// ============================================
// REGISTRAR ROTAS
// ============================================
app.use('/api/auth', auth_1.default);
app.use('/api/inbox', inbox_1.default);
app.use('/api/instances', instances_1.default);
app.use('/api/webhooks', webhooks_1.default);
app.use('/api/ai', ai_1.default);
app.use('/api/messages', messages_1.default);
app.use('/api/leads', leads_1.default);
app.use('/api/products', products_1.default);
// Rota raiz - servir index.html
app.get('/', (req, res) => {
    res.sendFile(path_1.default.join(__dirname, '../public/index.html'));
});
// ============================================
// INICIAR SERVIDOR
// ============================================
const server = httpServer.listen(parseInt(PORT), '0.0.0.0', () => {
    console.log();
    console.log();
    console.log();
});
// Tratamento de erros
server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        console.error();
    }
    else {
        console.error('❌ Erro no servidor:', error);
    }
    process.exit(1);
});
// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('📴 SIGTERM recebido, encerrando servidor...');
    server.close(() => {
        console.log('✅ Servidor encerrado');
        process.exit(0);
    });
});
exports.default = app;
//# sourceMappingURL=server.js.map