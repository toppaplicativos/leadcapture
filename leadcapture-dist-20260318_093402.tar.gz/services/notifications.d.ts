export type NotificationType = "system" | "user" | "support";
export type NotificationPriority = "low" | "medium" | "high" | "critical";
export type NotificationChannel = "in_app" | "email" | "whatsapp" | "push" | "webhook";
export type NotificationPayload = {
    notification_id: string;
    type: NotificationType;
    event: string;
    title: string;
    message: string;
    priority: NotificationPriority;
    channels: NotificationChannel[];
    read: boolean;
    user_id: string;
    store_id?: string | null;
    created_at: string;
    metadata: Record<string, any>;
};
export type CreateNotificationInput = {
    type: NotificationType;
    event: string;
    title: string;
    message: string;
    priority?: NotificationPriority;
    channels?: NotificationChannel[];
    user_id: string;
    store_id?: string | null;
    metadata?: Record<string, any>;
};
export type NotificationListFilters = {
    user_id: string;
    type?: NotificationType;
    priority?: NotificationPriority;
    read?: boolean;
    store_id?: string;
    q?: string;
    limit?: number;
    offset?: number;
};
export declare class NotificationService {
    private schemaReady;
    ensureSchema(): Promise<void>;
    private normalizeChannels;
    private parseJson;
    getPreferences(userId: string): Promise<Record<string, NotificationChannel[]>>;
    updatePreferences(userId: string, preferences: Record<string, NotificationChannel[]>): Promise<Record<string, NotificationChannel[]>>;
    private resolveChannelsForUser;
    private recordDelivery;
    private dispatchChannel;
    createNotification(input: CreateNotificationInput): Promise<NotificationPayload>;
    private mapRow;
    listNotifications(filters: NotificationListFilters): Promise<{
        notifications: NotificationPayload[];
        total: number;
    }>;
    getUnreadCount(userId: string): Promise<number>;
    markAsRead(userId: string, notificationId: string): Promise<boolean>;
    markAllAsRead(userId: string): Promise<number>;
    getAnalytics(userId: string): Promise<Record<string, any>>;
}
export declare function getNotificationService(): NotificationService;
//# sourceMappingURL=notifications.d.ts.map