"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RateLimiter = void 0;
class RateLimiter {
    constructor(maxPerMinute = 3, maxPerDay = 200) {
        this.timestamps = new Map();
        this.dailyCounts = new Map();
        this.maxPerMinute = maxPerMinute;
        this.maxPerDay = maxPerDay;
    }
    canSend(instanceId) {
        const now = Date.now();
        const today = new Date().toISOString().split("T")[0];
        // Check daily limit
        const daily = this.dailyCounts.get(instanceId);
        if (daily && daily.date === today && daily.count >= this.maxPerDay) {
            return false;
        }
        // Check per-minute limit
        const times = this.timestamps.get(instanceId) || [];
        const recentTimes = times.filter((t) => now - t < 60000);
        if (recentTimes.length >= this.maxPerMinute) {
            return false;
        }
        return true;
    }
    recordSend(instanceId) {
        const now = Date.now();
        const today = new Date().toISOString().split("T")[0];
        // Update per-minute
        const times = this.timestamps.get(instanceId) || [];
        times.push(now);
        this.timestamps.set(instanceId, times.filter((t) => now - t < 60000));
        // Update daily
        const daily = this.dailyCounts.get(instanceId);
        if (daily && daily.date === today) {
            daily.count++;
        }
        else {
            this.dailyCounts.set(instanceId, { count: 1, date: today });
        }
    }
    getStatus(instanceId) {
        const now = Date.now();
        const today = new Date().toISOString().split("T")[0];
        const times = this.timestamps.get(instanceId) || [];
        const recentTimes = times.filter((t) => now - t < 60000);
        const daily = this.dailyCounts.get(instanceId);
        const dailyCount = daily && daily.date === today ? daily.count : 0;
        return {
            minuteCount: recentTimes.length,
            dailyCount,
            canSend: this.canSend(instanceId),
        };
    }
}
exports.RateLimiter = RateLimiter;
//# sourceMappingURL=rateLimiter.js.map