type VideoJobStatus = "processing" | "completed" | "failed";
export type VideoJob = {
    id: string;
    userId: string;
    prompt: string;
    operationName: string;
    status: VideoJobStatus;
    model: string;
    createdAt: string;
    error?: string;
    videoUrl?: string;
};
export type CreativeAssetType = "text" | "image" | "video";
export type StudioImageType = "product" | "reference" | "background";
export type StudioAspectRatio = "1:1" | "4:5" | "9:16" | "16:9";
export type StudioQuality = "fast" | "high";
export type ProductStudioTextOverlay = {
    headline?: string;
    subheadline?: string;
    cta?: string;
    position?: "top" | "center" | "bottom";
    style?: "modern" | "elegant" | "bold" | "clean";
};
export type ProductStudioGenerateInput = {
    productId?: string;
    productAssetId?: string;
    referenceAssetIds?: string[];
    backgroundAssetId?: string;
    style?: string;
    scene?: string;
    lighting?: string;
    targetAudience?: string;
    predominantColors?: string;
    aspectRatio?: StudioAspectRatio;
    formats?: StudioAspectRatio[];
    textOverlay?: ProductStudioTextOverlay;
    variations?: number;
    quality?: StudioQuality;
    withAndWithoutText?: boolean;
    transparentBackground?: boolean;
    tags?: string[];
};
export type ProductStudioEditInput = {
    sourceAssetId: string;
    instruction: string;
    preserveProduct?: boolean;
    style?: string;
    aspectRatio?: StudioAspectRatio;
    tags?: string[];
};
export type ProductStudioCredits = {
    accountId: string;
    imagesGeneratedMonth: number;
    creditsRemaining: number;
    monthlyLimit: number;
    monthRef: string;
};
export type CreativeAsset = {
    id: string;
    type: CreativeAssetType;
    prompt?: string;
    model?: string;
    status: VideoJobStatus;
    text?: string;
    fileUrl?: string;
    parentAssetId?: string;
    metadata?: Record<string, any>;
    error?: string;
    createdAt: string;
    updatedAt: string;
};
type GenerateTextInput = {
    prompt: string;
    tone?: string;
    objective?: string;
    audience?: string;
    maxCharacters?: number;
};
type GenerateImageInput = {
    prompt: string;
    style?: string;
    format?: "square" | "portrait" | "landscape";
};
type GenerateVideoInput = {
    prompt: string;
    aspectRatio?: "16:9" | "9:16" | "1:1";
};
type RemixImageInput = {
    sourceAssetId?: string;
    sourceUrl?: string;
    instructions: string;
    style?: string;
    format?: "square" | "portrait" | "landscape";
};
export declare class CreativeStudioService {
    private readonly baseUrl;
    private readonly videoJobs;
    private assetsTableReady;
    private creditsTableReady;
    private normalizeBrandId;
    private creditsAccountId;
    private extractAssetBrandId;
    private belongsToBrand;
    private isGalleryGeneratedAsset;
    private getApiKey;
    private sanitizePathPart;
    private ensureDir;
    private extractTextFromCandidate;
    private parseJsonSafely;
    private toFormatFromAspect;
    private currentMonthRef;
    private normalizeTagList;
    private buildProductStudioPrompt;
    private loadAssetAsInlineData;
    private requestImageFromParts;
    private buildFileAbsolutePath;
    private getMimeTypeFromPath;
    private mapAssetRow;
    private ensureAssetsTable;
    private ensureCreditsTable;
    private ensureCreditsRow;
    getProductStudioCredits(userId: string, brandId?: string | null): Promise<ProductStudioCredits>;
    consumeProductStudioCredits(userId: string, amount?: number, brandId?: string | null): Promise<ProductStudioCredits>;
    private saveAsset;
    private updateAssetById;
    listAssets(userId: string, filters?: {
        type?: CreativeAssetType;
        search?: string;
        limit?: number;
        offset?: number;
        includeUploads?: boolean;
    }, brandId?: string | null): Promise<{
        assets: CreativeAsset[];
        total: number;
    }>;
    getAssetById(userId: string, assetId: string, brandId?: string | null): Promise<CreativeAsset | null>;
    registerUploadedImage(userId: string, input: {
        fileUrl: string;
        originalName?: string;
        caption?: string;
        prompt?: string;
    }, brandId?: string | null): Promise<{
        imageUrl: string;
        caption: string;
        model: string;
        asset: CreativeAsset;
    }>;
    registerStudioImage(userId: string, input: {
        fileUrl: string;
        imageType?: StudioImageType;
        productId?: string;
        originalName?: string;
        caption?: string;
        tags?: string[];
    }, brandId?: string | null): Promise<CreativeAsset>;
    generateText(userId: string, input: GenerateTextInput, brandId?: string | null): Promise<{
        text: string;
        model: string;
        asset: CreativeAsset;
    }>;
    generateImage(userId: string, input: GenerateImageInput, brandId?: string | null): Promise<{
        imageUrl: string;
        caption: string;
        model: string;
        asset: CreativeAsset;
    }>;
    remixImage(userId: string, input: RemixImageInput, brandId?: string | null): Promise<{
        imageUrl: string;
        caption: string;
        model: string;
        asset: CreativeAsset;
    }>;
    generateProductStudioImages(userId: string, input: ProductStudioGenerateInput, brandId?: string | null): Promise<{
        assets: CreativeAsset[];
        model: string;
        credits: ProductStudioCredits;
    }>;
    editProductStudioImage(userId: string, input: ProductStudioEditInput, brandId?: string | null): Promise<{
        asset: CreativeAsset;
        model: string;
        credits: ProductStudioCredits;
    }>;
    listProductStudioGallery(userId: string, filters?: {
        productId?: string;
        tag?: string;
        format?: StudioAspectRatio;
        usedInCampaign?: boolean;
        limit?: number;
        offset?: number;
    }, brandId?: string | null): Promise<{
        assets: CreativeAsset[];
        total: number;
    }>;
    markAssetUsedInCampaign(userId: string, assetId: string, campaignId?: string, brandId?: string | null): Promise<CreativeAsset | null>;
    startVideoGeneration(userId: string, input: GenerateVideoInput, brandId?: string | null): Promise<VideoJob>;
    getVideoJob(userId: string, jobId: string, brandId?: string | null): Promise<VideoJob | null>;
}
export {};
//# sourceMappingURL=creativeStudio.d.ts.map