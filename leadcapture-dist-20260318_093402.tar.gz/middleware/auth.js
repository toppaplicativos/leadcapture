"use strict";
/**
 * MIDDLEWARE DE AUTENTICAÇÃO - Validação de JWT
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authMiddleware = void 0;
exports.authenticateToken = authenticateToken;
exports.requireRole = requireRole;
exports.verifyToken = verifyToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const config_1 = require("../config");
const JWT_SECRET = config_1.config.jwtSecret;
/**
 * Middleware para autenticar requisições usando JWT
 * Valida o token no header Authorization: Bearer <token>
 */
function authenticateToken(req, res, next) {
    try {
        // Extrair token do header Authorization
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];
        if (!token) {
            res.status(401).json({ error: 'Token não fornecido' });
            return;
        }
        // Verificar e decodificar token
        jsonwebtoken_1.default.verify(token, JWT_SECRET, (err, decoded) => {
            if (err) {
                res.status(403).json({ error: 'Token inválido ou expirado' });
                return;
            }
            // Adicionar userId ao request
            req.userId = decoded.userId || decoded.sub;
            req.user = decoded;
            next();
        });
    }
    catch (error) {
        res.status(500).json({ error: 'Erro ao autenticar' });
    }
}
/**
 * Alias para authenticateToken (compatibilidade com código existente)
 */
exports.authMiddleware = authenticateToken;
/**
 * Middleware para verificar role do usuário
 */
function requireRole(roles) {
    return (req, res, next) => {
        const userRole = req.user?.role || 'user';
        if (!roles.includes(userRole)) {
            res.status(403).json({ error: 'Acesso negado' });
            return;
        }
        next();
    };
}
/**
 * Verifica se um token é válido
 */
function verifyToken(token) {
    try {
        return jsonwebtoken_1.default.verify(token, JWT_SECRET);
    }
    catch (error) {
        return null;
    }
}
//# sourceMappingURL=auth.js.map