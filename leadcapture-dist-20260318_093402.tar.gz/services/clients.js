"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsService = void 0;
const uuid_1 = require("uuid");
const database_1 = require("../config/database");
const logger_1 = require("../utils/logger");
class ClientsService {
    constructor() {
        this.columnsCache = null;
    }
    normalizePhone(value) {
        return String(value || "").replace(/\D/g, "");
    }
    async getClientColumns() {
        if (!this.columnsCache) {
            const pool = (0, database_1.getPool)();
            const [rows] = await pool.query("SHOW COLUMNS FROM clients");
            this.columnsCache = new Set(rows.map((row) => String(row.Field || "")));
        }
        return this.columnsCache;
    }
    async findExistingImportedClient(userId, lead, brandId) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = cols.has("brand_id")
            ? normalizedBrandId
                ? " AND brand_id = ?"
                : " AND brand_id IS NULL"
            : "";
        const normalizedPhone = this.normalizePhone(lead?.nationalPhoneNumber || lead?.phone);
        if (normalizedPhone) {
            const phoneParams = [userId, `%${normalizedPhone}`];
            if (cols.has("brand_id") && normalizedBrandId)
                phoneParams.push(normalizedBrandId);
            const [rows] = await pool.query(`SELECT *
         FROM clients
         WHERE user_id = ?
           AND is_active = TRUE
           AND REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(phone, ''), ' ', ''), '-', ''), '+', ''), '(', ''), ')', '') LIKE ?${brandClause}
         LIMIT 1`, phoneParams);
            if (rows[0]) {
                const client = rows[0];
                if (typeof client.tags === "string")
                    client.tags = JSON.parse(client.tags);
                if (typeof client.custom_fields === "string")
                    client.custom_fields = JSON.parse(client.custom_fields);
                return client;
            }
        }
        const email = String(lead?.email || "").trim().toLowerCase();
        if (email) {
            const emailParams = [userId, email];
            if (cols.has("brand_id") && normalizedBrandId)
                emailParams.push(normalizedBrandId);
            const [rows] = await pool.query(`SELECT *
         FROM clients
         WHERE user_id = ?
           AND is_active = TRUE
           AND LOWER(COALESCE(email, '')) = ?${brandClause}
         LIMIT 1`, emailParams);
            if (rows[0]) {
                const client = rows[0];
                if (typeof client.tags === "string")
                    client.tags = JSON.parse(client.tags);
                if (typeof client.custom_fields === "string")
                    client.custom_fields = JSON.parse(client.custom_fields);
                return client;
            }
        }
        return null;
    }
    async create(userId, data, brandId) {
        const pool = (0, database_1.getPool)();
        const id = (0, uuid_1.v4)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        if (cols.has("brand_id")) {
            await pool.execute(`INSERT INTO clients (id, user_id, brand_id, company_id, name, phone, email, cpf, birth_date, address, city, state, zip_code, tags, notes, source, lead_score, status, custom_fields)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [id, userId, normalizedBrandId || null, data.company_id || null, data.name, data.phone || null, data.email || null,
                data.cpf || null, data.birth_date || null, data.address || null, data.city || null,
                data.state || null, data.zip_code || null, data.tags ? JSON.stringify(data.tags) : null,
                data.notes || null, data.source || "manual", data.lead_score || 0,
                data.status || "new", data.custom_fields ? JSON.stringify(data.custom_fields) : null]);
        }
        else {
            await pool.execute(`INSERT INTO clients (id, user_id, company_id, name, phone, email, cpf, birth_date, address, city, state, zip_code, tags, notes, source, lead_score, status, custom_fields)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [id, userId, data.company_id || null, data.name, data.phone || null, data.email || null,
                data.cpf || null, data.birth_date || null, data.address || null, data.city || null,
                data.state || null, data.zip_code || null, data.tags ? JSON.stringify(data.tags) : null,
                data.notes || null, data.source || "manual", data.lead_score || 0,
                data.status || "new", data.custom_fields ? JSON.stringify(data.custom_fields) : null]);
        }
        return this.getById(id, userId, brandId);
    }
    async getById(id, userId, brandId) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = cols.has("brand_id") ? (normalizedBrandId ? " AND brand_id = ?" : " AND brand_id IS NULL") : "";
        const params = cols.has("brand_id") && normalizedBrandId ? [id, userId, normalizedBrandId] : [id, userId];
        const [rows] = await pool.query(`SELECT * FROM clients WHERE id = ? AND user_id = ?${brandClause} AND is_active = TRUE`, params);
        if (!rows[0])
            return null;
        const client = rows[0];
        if (typeof client.tags === "string")
            client.tags = JSON.parse(client.tags);
        if (typeof client.custom_fields === "string")
            client.custom_fields = JSON.parse(client.custom_fields);
        return client;
    }
    async getAll(userId, filters = {}) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const { status, source, company_id, brand_id, search, page = 1, limit = 50 } = filters;
        let where = "user_id = ? AND is_active = TRUE";
        const params = [userId];
        const normalizedBrandId = String(brand_id || "").trim();
        if (cols.has("brand_id")) {
            if (normalizedBrandId) {
                where += " AND brand_id = ?";
                params.push(normalizedBrandId);
            }
            else {
                where += " AND brand_id IS NULL";
            }
        }
        if (status) {
            where += " AND status = ?";
            params.push(status);
        }
        if (source) {
            where += " AND source = ?";
            params.push(source);
        }
        if (company_id) {
            where += " AND company_id = ?";
            params.push(company_id);
        }
        if (search) {
            where += " AND (name LIKE ? OR phone LIKE ? OR email LIKE ?)";
            params.push(`%${search}%`, `%${search}%`, `%${search}%`);
        }
        const [countRows] = await pool.query(`SELECT COUNT(*) as total FROM clients WHERE ${where}`, params);
        const total = countRows[0].total;
        const offset = (page - 1) * limit;
        const [rows] = await pool.query(`SELECT * FROM clients WHERE ${where} ORDER BY created_at DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`, params);
        const clients = rows.map(c => {
            if (typeof c.tags === "string")
                c.tags = JSON.parse(c.tags);
            if (typeof c.custom_fields === "string")
                c.custom_fields = JSON.parse(c.custom_fields);
            return c;
        });
        return { clients: clients, total };
    }
    async update(id, userId, data, brandId) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = cols.has("brand_id") ? (normalizedBrandId ? " AND brand_id = ?" : " AND brand_id IS NULL") : "";
        const fields = [];
        const values = [];
        for (const [key, value] of Object.entries(data)) {
            if (value !== undefined) {
                fields.push(`${key} = ?`);
                values.push(key === "tags" || key === "custom_fields" ? JSON.stringify(value) : value);
            }
        }
        if (fields.length === 0)
            return this.getById(id, userId, brandId);
        values.push(id, userId);
        if (cols.has("brand_id") && normalizedBrandId)
            values.push(normalizedBrandId);
        await pool.execute(`UPDATE clients SET ${fields.join(", ")} WHERE id = ? AND user_id = ?${brandClause}`, values);
        return this.getById(id, userId, brandId);
    }
    async updateStatus(id, userId, status, brandId) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = cols.has("brand_id") ? (normalizedBrandId ? " AND brand_id = ?" : " AND brand_id IS NULL") : "";
        const params = cols.has("brand_id") && normalizedBrandId ? [status, id, userId, normalizedBrandId] : [status, id, userId];
        await pool.execute(`UPDATE clients SET status = ? WHERE id = ? AND user_id = ?${brandClause}`, params);
        return this.getById(id, userId, brandId);
    }
    async delete(id, userId, brandId) {
        const pool = (0, database_1.getPool)();
        const cols = await this.getClientColumns();
        const normalizedBrandId = String(brandId || "").trim();
        const brandClause = cols.has("brand_id") ? (normalizedBrandId ? " AND brand_id = ?" : " AND brand_id IS NULL") : "";
        const params = cols.has("brand_id") && normalizedBrandId ? [id, userId, normalizedBrandId] : [id, userId];
        const [result] = await pool.execute(`UPDATE clients SET is_active = FALSE WHERE id = ? AND user_id = ?${brandClause}`, params);
        return result.affectedRows > 0;
    }
    async importFromLeads(userId, leads, source = "google_places", brandId) {
        let imported = 0;
        for (const lead of leads) {
            try {
                const existing = await this.findExistingImportedClient(userId, lead, brandId);
                if (existing)
                    continue;
                await this.create(userId, {
                    name: lead.displayName || lead.name || "Sem nome",
                    phone: lead.nationalPhoneNumber || lead.phone || null,
                    address: lead.formattedAddress || lead.address || null,
                    source,
                    notes: `Rating: ${lead.rating || "N/A"} | Website: ${lead.websiteUri || "N/A"}`,
                    tags: lead.types || [],
                    custom_fields: { google_place_id: lead.id, rating: lead.rating, website: lead.websiteUri }
                }, brandId);
                imported++;
            }
            catch (err) {
                logger_1.logger.error(err, `Erro ao importar lead: ${lead.displayName}`);
            }
        }
        return imported;
    }
}
exports.ClientsService = ClientsService;
//# sourceMappingURL=clients.js.map