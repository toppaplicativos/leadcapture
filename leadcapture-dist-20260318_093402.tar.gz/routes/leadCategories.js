"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const uuid_1 = require("uuid");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const router = (0, express_1.Router)();
router.use(auth_1.authMiddleware);
function resolveUserId(req) {
    return req.user?.userId || req.user?.id;
}
// GET /api/lead-categories
router.get("/", async (req, res) => {
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query("SELECT * FROM lead_categories WHERE user_id = ? AND is_active = TRUE ORDER BY name ASC", [userId]);
        return res.json({ success: true, categories: rows });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// POST /api/lead-categories
router.post("/", async (req, res) => {
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { name, color = "#3b82f6", description } = req.body || {};
        if (!name || String(name).trim().length === 0) {
            return res.status(400).json({ error: "name is required" });
        }
        const colorVal = String(color || "#3b82f6");
        if (!/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(colorVal)) {
            return res.status(400).json({ error: "Invalid color format (use #RGB or #RRGGBB)" });
        }
        const id = (0, uuid_1.v4)();
        const pool = (0, database_1.getPool)();
        await pool.execute("INSERT INTO lead_categories (id, user_id, name, color, description) VALUES (?, ?, ?, ?, ?)", [id, userId, String(name).trim(), colorVal, description ? String(description).trim() : null]);
        const [rows] = await pool.query("SELECT * FROM lead_categories WHERE id = ? LIMIT 1", [id]);
        return res.json({ success: true, category: rows[0] });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// PUT /api/lead-categories/:id
router.put("/:id", async (req, res) => {
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const id = String(req.params.id || "");
        const { name, color, description } = req.body || {};
        if (color && !/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(String(color))) {
            return res.status(400).json({ error: "Invalid color format" });
        }
        const pool = (0, database_1.getPool)();
        const [existing] = await pool.query("SELECT id FROM lead_categories WHERE id = ? AND user_id = ? LIMIT 1", [id, userId]);
        if (!existing[0])
            return res.status(404).json({ error: "Category not found" });
        const sets = [];
        const vals = [];
        if (name !== undefined) {
            sets.push("name = ?");
            vals.push(String(name).trim());
        }
        if (color !== undefined) {
            sets.push("color = ?");
            vals.push(String(color));
        }
        if (description !== undefined) {
            sets.push("description = ?");
            vals.push(String(description).trim() || null);
        }
        if (sets.length > 0) {
            vals.push(id, userId);
            await pool.execute(`UPDATE lead_categories SET ${sets.join(", ")} WHERE id = ? AND user_id = ?`, vals);
        }
        const [rows] = await pool.query("SELECT * FROM lead_categories WHERE id = ? LIMIT 1", [id]);
        return res.json({ success: true, category: rows[0] });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// DELETE /api/lead-categories/:id
router.delete("/:id", async (req, res) => {
    try {
        const userId = resolveUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const id = String(req.params.id || "");
        const pool = (0, database_1.getPool)();
        const [result] = await pool.execute("UPDATE lead_categories SET is_active = FALSE WHERE id = ? AND user_id = ?", [id, userId]);
        if (result.affectedRows === 0)
            return res.status(404).json({ error: "Category not found" });
        return res.json({ success: true });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
exports.default = router;
//# sourceMappingURL=leadCategories.js.map