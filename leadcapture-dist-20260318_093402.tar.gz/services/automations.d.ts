export type AutomationTemplate = {
    code: string;
    name: string;
    trigger: string;
    send_only_whatsapp_confirmed: boolean;
    tags: string[];
    status_from: string;
    status_to: string;
    timing_steps: string[];
    copy_messages: string[];
    objective: string;
    sort_order: number;
};
export type AutomationRule = AutomationTemplate & {
    id: string;
    user_id: string;
    is_custom?: boolean;
    is_active: boolean;
    created_at?: string;
    updated_at?: string;
};
export type ScoringEvent = {
    key: string;
    label: string;
    points: number;
};
export type AutomationScoring = {
    threshold: number;
    events: ScoringEvent[];
};
export type OutboundEventType = "message_sent" | "message_replied" | "lead_engaged" | "lead_client";
export type OutboundEventInput = {
    lead_id?: string | number;
    message_key?: string;
    event_type: OutboundEventType;
    response_time_seconds?: number;
    metadata?: Record<string, unknown>;
    automation_code?: string;
};
export type OutboundMetrics = {
    total_outbound_leads: number;
    replied_leads: number;
    engaged_leads: number;
    client_leads: number;
    response_rate: number;
    engaged_rate: number;
    client_rate: number;
    avg_response_time_minutes: number | null;
    best_message: {
        message_key: string;
        sent_count: number;
        responses_count: number;
        response_rate: number;
    } | null;
};
export declare class AutomationsService {
    private initialized;
    private customerColumnsCache;
    private normalizeBrandId;
    private buildBrandFilter;
    private buildRuleScopeFilter;
    private ensureBrandColumns;
    private ensureSchema;
    private getCustomerColumns;
    private hasCustomerColumn;
    private resolveCustomersOwnerColumn;
    private ensureDefaultsForUser;
    private mapRule;
    createRule(userId: string, brandId: string | null | undefined, payload: Partial<{
        name: string;
        trigger: string;
        send_only_whatsapp_confirmed: boolean;
        tags: string[];
        status_from: string;
        status_to: string;
        timing_steps: string[];
        copy_messages: string[];
        objective: string;
        is_active: boolean;
    }>): Promise<AutomationRule>;
    private extractTagSet;
    private isOutboundLeadRow;
    private isRepliedLeadRow;
    private isEngagedLeadRow;
    private isClientLeadRow;
    listRules(userId: string, brandId?: string | null): Promise<{
        funnel_statuses: string[];
        rules: AutomationRule[];
        scoring: AutomationScoring;
    }>;
    updateRule(userId: string, brandId: string | null | undefined, code: string, payload: Partial<{
        name: string;
        trigger: string;
        send_only_whatsapp_confirmed: boolean;
        tags: string[];
        status_from: string;
        status_to: string;
        timing_steps: string[];
        copy_messages: string[];
        objective: string;
        is_active: boolean;
    }>): Promise<AutomationRule | null>;
    resetRule(userId: string, brandId: string | null | undefined, code: string): Promise<AutomationRule | null>;
    updateScoring(userId: string, brandId: string | null | undefined, payload: Partial<{
        threshold: number;
        events: ScoringEvent[];
    }>): Promise<AutomationScoring>;
    recordOutboundEvent(userId: string, payload: OutboundEventInput, brandId?: string | null): Promise<{
        ok: true;
    }>;
    getOutboundMetrics(userId: string, brandId?: string | null): Promise<OutboundMetrics>;
}
//# sourceMappingURL=automations.d.ts.map