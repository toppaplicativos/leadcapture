type MediaDownloadResult = {
    buffer: Buffer;
    mimeType?: string;
    fileName?: string;
    mediaType: "image" | "video" | "audio" | "document";
};
export declare class InboxService {
    private mediaDownloader?;
    private messageSender?;
    private senderNameColumnExists;
    private aiColumnsChecked;
    private readonly whatsappAgentService;
    private normalizeAIMode;
    private parseBool;
    private parseFromMeFlag;
    private shouldEscalateToHuman;
    private ensureAIColumns;
    private isGlobalAIEnabled;
    private logAIDecision;
    private tryAutonomousReply;
    private normalizeDigits;
    private extractPhoneFromJid;
    private isSamePhone;
    private getInstancePhone;
    private isSelfDirectConversation;
    private ensureSenderNameColumn;
    setMediaDownloader(downloader: (instanceId: string, msg: any) => Promise<MediaDownloadResult | null>): void;
    setMessageSender(sender: (instanceId: string, jid: string, message: string) => Promise<boolean>): void;
    private getFileExtension;
    private persistIncomingMedia;
    private getConversationPreview;
    handleIncomingMessage(instanceId: string, msg: any): Promise<void>;
}
export {};
//# sourceMappingURL=inbox.d.ts.map