declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=pricetables.d.ts.map