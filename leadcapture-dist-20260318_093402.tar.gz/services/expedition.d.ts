export type ExpeditionDispatcher = {
    id: string;
    user_id: string;
    company_id?: string;
    name: string;
    phone: string;
    notes?: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
};
export type ExpeditionOrderItem = {
    productId?: string;
    name: string;
    quantity: number;
    unitPrice: number;
    total: number;
    notes?: string;
};
export type ExpeditionOrder = {
    id: string;
    user_id: string;
    company_id?: string;
    dispatcher_id: string;
    whatsapp_instance_id: string;
    customer_name: string;
    customer_phone?: string;
    delivery_address?: string;
    items_json: string;
    subtotal: number;
    discount: number;
    shipping_fee: number;
    total: number;
    notes?: string;
    status: "created" | "sent" | "confirmed" | "shipped" | "delivered" | "cancelled";
    whatsapp_status: "pending" | "sent" | "failed";
    sent_at?: string;
    created_at: string;
    updated_at: string;
};
export type ExpeditionEventType = "order_created" | "order_paid" | "order_updated" | "order_cancelled";
export type LogisticStatus = "aguardando_separacao" | "em_separacao" | "pronto_para_envio" | "em_rota" | "entregue" | "falha_entrega";
export type DispatchStatusRow = {
    order_id: string;
    user_id: string;
    brand_id?: string | null;
    logistic_status: LogisticStatus;
    assigned_to?: string | null;
    estimated_delivery?: string | null;
    route_id?: string | null;
    route_link?: string | null;
    updated_at: string;
};
export type DispatchMessageLogRow = {
    id: string;
    order_id: string;
    user_id: string;
    brand_id?: string | null;
    message_type: "customer" | "internal" | "courier";
    event_type?: string | null;
    sent_to?: string | null;
    instance_id?: string | null;
    status: "queued" | "sent" | "skipped" | "failed";
    payload_json?: string | null;
    created_at: string;
};
export declare class ExpeditionService {
    private schemaChecked;
    private ensureBrandColumns;
    private sanitizePhone;
    private mapsLinkByAddress;
    private defaultTemplates;
    private applyTemplate;
    private parseItems;
    private formatMoney;
    private upsertDispatchStatus;
    private logDispatchMessage;
    getOrderById(userId: string, orderId: string, brandId?: string | null): Promise<ExpeditionOrder | null>;
    private buildBrandWhere;
    listDispatchers(userId: string, brandId?: string | null): Promise<ExpeditionDispatcher[]>;
    createDispatcher(userId: string, data: {
        company_id?: string;
        name: string;
        phone: string;
        notes?: string;
    }, brandId?: string | null): Promise<ExpeditionDispatcher>;
    updateDispatcher(userId: string, dispatcherId: string, data: Partial<{
        company_id: string;
        name: string;
        phone: string;
        notes: string;
        is_active: boolean;
    }>, brandId?: string | null): Promise<ExpeditionDispatcher | null>;
    deleteDispatcher(userId: string, dispatcherId: string, brandId?: string | null): Promise<boolean>;
    getDispatcherById(userId: string, dispatcherId: string, brandId?: string | null): Promise<ExpeditionDispatcher | null>;
    listOrders(userId: string, brandId?: string | null): Promise<(ExpeditionOrder & {
        dispatcher_name: string;
        dispatcher_phone: string;
    })[]>;
    getDispatchStatus(userId: string, orderId: string, brandId?: string | null): Promise<DispatchStatusRow | null>;
    getDispatchDashboard(userId: string, brandId?: string | null): Promise<{
        pending: number;
        separacao: number;
        em_rota: number;
        entregues_hoje: number;
        sla_medio_horas: number | null;
        tempo_medio_entrega_horas: number | null;
    }>;
    processOrderEvent(userId: string, brandId: string | null | undefined, orderId: string, event: ExpeditionEventType): Promise<{
        order: ExpeditionOrder;
        dispatch_status: DispatchStatusRow | null;
        message_preview: {
            customer: string;
            internal: string;
            courier: string;
        };
    }>;
    updateLogisticStatus(userId: string, brandId: string | null | undefined, orderId: string, payload: Partial<{
        logistic_status: LogisticStatus;
        assigned_to: string;
        estimated_delivery: string;
        route_id: string;
        route_link: string;
        lat: number;
        lng: number;
    }>): Promise<DispatchStatusRow>;
    renderOrderMessages(userId: string, orderId: string, brandId?: string | null): Promise<{
        customer: string;
        internal: string;
        courier: string;
    }>;
    createOrder(userId: string, input: {
        brand_id?: string;
        company_id?: string;
        dispatcher_id: string;
        whatsapp_instance_id: string;
        customer_name: string;
        customer_phone?: string;
        delivery_address?: string;
        items: ExpeditionOrderItem[];
        discount?: number;
        shipping_fee?: number;
        notes?: string;
        status?: ExpeditionOrder["status"];
        whatsapp_status?: ExpeditionOrder["whatsapp_status"];
        sent_at?: string | null;
    }): Promise<ExpeditionOrder>;
}
//# sourceMappingURL=expedition.d.ts.map