import { WASocket } from "@whiskeysockets/baileys";
import { WhatsAppInstance } from "../types";
export type PollDeliveryMode = "auto" | "native_only" | "text_only";
export type PollSendResult = {
    ok: boolean;
    mode: "native_poll" | "text_fallback";
    error?: string;
    nativeError?: string;
};
export type ConnectedDestinationTarget = {
    jid: string;
    name: string;
    instance_id: string;
    instance_name?: string;
    target_type: "group" | "contact" | "channel";
    last_message_at?: string | null;
};
export declare class InstanceManager {
    private instances;
    private instanceOwners;
    private sockets;
    private connectPromises;
    private messageHandlers;
    private globalMessageHandlers;
    private retryCount;
    private reconnectTimers;
    private connectedSince;
    private preconditionCloseCount;
    private intentionalDisconnects;
    private mediaLogger;
    private static MAX_RETRIES;
    private static BASE_DELAY;
    private static MAX_DELAY;
    private static COOLDOWN_DELAY;
    private static MAX_RETRIES_BEFORE_COOLDOWN;
    private static STABLE_CONNECTION_MS;
    private static MAX_428_CLOSES;
    private ensureInstanceLoaded;
    private normalizeDirectJid;
    private resolveSendTargetJid;
    constructor();
    restoreAllSessions(): Promise<void>;
    private safeConnect;
    private invalidateAuthState;
    private syncInstanceToDB;
    createInstance(name: string, ownerUserId?: string): Promise<WhatsAppInstance>;
    connectInstance(id: string): Promise<string | null>;
    private connectInstanceInternal;
    private cleanupSocket;
    sendMessage(instanceId: string, phone: string, message: string): Promise<boolean>;
    checkWhatsAppNumber(instanceId: string, phone: string): Promise<{
        exists: boolean;
        jid?: string;
        normalizedPhone: string;
    }>;
    sendMessageByJid(instanceId: string, jid: string, message: string): Promise<boolean>;
    getProfilePictureUrl(instanceId: string, jid: string): Promise<string | null>;
    sendMediaByJid(instanceId: string, jid: string, input: {
        mediaType: "image" | "video" | "audio" | "document";
        filePath: string;
        caption?: string;
        mimeType?: string;
        fileName?: string;
        voiceNote?: boolean;
    }): Promise<boolean>;
    sendMedia(instanceId: string, phone: string, input: {
        mediaType: "image" | "video" | "audio" | "document";
        filePath: string;
        caption?: string;
        mimeType?: string;
        fileName?: string;
        voiceNote?: boolean;
    }): Promise<boolean>;
    sendPollByJid(instanceId: string, jid: string, input: {
        question: string;
        options: string[];
        selectableCount?: number;
        deliveryMode?: PollDeliveryMode;
    }): Promise<PollSendResult>;
    downloadIncomingMedia(instanceId: string, msg: any): Promise<{
        buffer: Buffer;
        mimeType?: string;
        fileName?: string;
        mediaType: "image" | "video" | "audio" | "document";
    } | null>;
    disconnectInstance(id: string): Promise<void>;
    deleteInstance(id: string): Promise<void>;
    onMessage(instanceId: string, handler: (msg: any) => void): void;
    onGlobalMessage(handler: (instanceId: string, msg: any) => void): void;
    getInstance(id: string, ownerUserId?: string): WhatsAppInstance | undefined;
    getSocket(id: string): WASocket | undefined;
    listConnectedDestinationTargets(instanceId: string, input?: {
        search?: string;
        targetType?: "group" | "contact" | "channel" | "all";
        limit?: number;
    }): Promise<ConnectedDestinationTarget[]>;
    enrichConnectedChannelTargets(instanceId: string, channels: ConnectedDestinationTarget[]): Promise<ConnectedDestinationTarget[]>;
    getAllInstances(ownerUserId?: string): WhatsAppInstance[];
    getInstanceQR(id: string, ownerUserId?: string): string | undefined;
}
//# sourceMappingURL=instanceManager.d.ts.map