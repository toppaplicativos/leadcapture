import { InventoryService } from "../services/inventory";
declare const router: import("express-serve-static-core").Router;
declare const inventoryService: InventoryService;
export default router;
export { inventoryService };
//# sourceMappingURL=inventory.d.ts.map