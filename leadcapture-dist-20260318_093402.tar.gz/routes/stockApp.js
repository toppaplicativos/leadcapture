"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const commerce_1 = require("../services/commerce");
const database_1 = require("../config/database");
const router = (0, express_1.Router)();
const commerceService = new commerce_1.CommerceService();
function requireStockCredential(req, res) {
    const credentialType = String(req.user?.credential_type || "").trim().toLowerCase();
    const ownerUserId = String(req.user?.owner_user_id || "").trim();
    const brandId = String(req.user?.brand_id || "").trim();
    const managerUserId = String(req.user?.userId || "").trim();
    if (credentialType !== "estoque") {
        res.status(403).json({ error: "Credencial inválida para app de estoque" });
        return null;
    }
    if (!ownerUserId || !brandId || !managerUserId) {
        res.status(403).json({ error: "Token de estoque incompleto" });
        return null;
    }
    return { ownerUserId, brandId, managerUserId };
}
router.get("/me", async (req, res) => {
    const context = requireStockCredential(req, res);
    if (!context)
        return;
    const brand = await (0, database_1.queryOne)(`SELECT id, slug, name, logo_url
     FROM brand_units
     WHERE id = ?
     LIMIT 1`, [context.brandId]);
    if (!brand) {
        return res.status(403).json({ error: "Brand vinculada ao token de estoque não existe" });
    }
    res.json({
        success: true,
        user: {
            id: context.managerUserId,
            email: String(req.user?.email || "").trim() || null,
            role: "manager",
            credential_type: "estoque",
            owner_user_id: context.ownerUserId,
            brand_id: context.brandId,
        },
        brand: {
            id: String(brand.id || "").trim(),
            slug: String(brand.slug || "").trim() || null,
            name: String(brand.name || "").trim() || null,
            logo_url: String(brand.logo_url || "").trim() || null,
        },
    });
});
router.get("/products", async (req, res) => {
    try {
        const context = requireStockCredential(req, res);
        if (!context)
            return;
        const products = await commerceService.listProducts(context.ownerUserId, context.brandId);
        res.json({ success: true, products, brand_id: context.brandId });
    }
    catch (error) {
        res.status(500).json({ error: error.message || "Falha ao listar produtos" });
    }
});
router.put("/products/:id", async (req, res) => {
    try {
        const context = requireStockCredential(req, res);
        if (!context)
            return;
        const payload = {
            estoque: req.body?.estoque,
            preco: req.body?.preco,
            preco_promocional: req.body?.preco_promocional,
            ativo: req.body?.ativo,
        };
        const product = await commerceService.updateProduct(context.ownerUserId, context.brandId, String(req.params.id || ""), payload);
        if (!product)
            return res.status(404).json({ error: "Produto não encontrado" });
        res.json({ success: true, product, brand_id: context.brandId });
    }
    catch (error) {
        res.status(500).json({ error: error.message || "Falha ao atualizar produto" });
    }
});
exports.default = router;
//# sourceMappingURL=stockApp.js.map