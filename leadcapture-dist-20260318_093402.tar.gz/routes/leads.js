"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const brandUnits_1 = require("../services/brandUnits");
const memoryEngine_1 = require("../services/memoryEngine");
const database_1 = require("../config/database");
const router = (0, express_1.Router)();
const brandUnitsService = new brandUnits_1.BrandUnitsService();
function getAuthenticatedUserId(req) {
    const userId = String(req.user?.userId || req.userId || req.user?.id || "").trim();
    return userId || null;
}
function getRequestedBrandId(req) {
    const fromHeader = String(req.headers?.["x-brand-id"] || "").trim();
    if (fromHeader)
        return fromHeader;
    const fromQuery = String(req.query?.brand_id || "").trim();
    if (fromQuery)
        return fromQuery;
    const body = (req.body || {});
    const fromBody = String(body.brand_id || body.brandId || "").trim();
    return fromBody || null;
}
async function resolveBrandId(req, userId) {
    return brandUnitsService.resolveActiveBrandId(userId, getRequestedBrandId(req));
}
async function verifyClientOwnership(pool, clientId, userId, brandId) {
    const [rows] = await pool.query(`SELECT id
     FROM clients
     WHERE id = ?
       AND user_id = ?
       AND is_active = TRUE
       ${brandId ? "AND brand_id = ?" : ""}
     LIMIT 1`, brandId ? [clientId, userId, brandId] : [clientId, userId]);
    return rows[0] || null;
}
// ─── GET /api/leads/memory/by-phone/:phone ────────────────────────────────────
// Get contextual memory for a lead by phone number
router.get("/memory/by-phone/:phone", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const phone = String(req.params.phone || "");
        if (!phone)
            return res.status(400).json({ error: "Phone is required" });
        const result = await memoryEngine_1.memoryEngine.getMemoryByPhone(userId, phone, brandId);
        if (!result)
            return res.status(404).json({ error: "Lead not found for this phone" });
        return res.json({ clientId: result.clientId, memory: result.memory });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// ─── GET /api/leads/memory/:clientId ─────────────────────────────────────────
// Get contextual memory for a specific client
router.get("/memory/:clientId", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const clientId = String(req.params.clientId || "");
        // Verify ownership
        const pool = (0, database_1.getPool)();
        const row = await verifyClientOwnership(pool, clientId, userId, brandId);
        if (!row)
            return res.status(404).json({ error: "Client not found" });
        const memory = await memoryEngine_1.memoryEngine.getMemory(clientId);
        return res.json({ clientId, memory });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// ─── PUT /api/leads/memory/:clientId ─────────────────────────────────────────
// Manually update / patch memory fields
router.put("/memory/:clientId", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const clientId = String(req.params.clientId || "");
        const patch = req.body;
        if (!patch || typeof patch !== "object") {
            return res.status(400).json({ error: "Body must be a JSON object with memory fields" });
        }
        // Verify ownership
        const pool = (0, database_1.getPool)();
        const row = await verifyClientOwnership(pool, clientId, userId, brandId);
        if (!row)
            return res.status(404).json({ error: "Client not found" });
        await memoryEngine_1.memoryEngine.saveMemory(clientId, patch);
        const updated = await memoryEngine_1.memoryEngine.getMemory(clientId);
        return res.json({ clientId, memory: updated });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// ─── DELETE /api/leads/memory/:clientId ──────────────────────────────────────
// Reset (clear) memory for a lead
router.delete("/memory/:clientId", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const clientId = String(req.params.clientId || "");
        const pool = (0, database_1.getPool)();
        const row = await verifyClientOwnership(pool, clientId, userId, brandId);
        if (!row)
            return res.status(404).json({ error: "Client not found" });
        await memoryEngine_1.memoryEngine.resetMemory(clientId);
        return res.json({ ok: true, message: "Memory reset successfully" });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// ─── POST /api/leads/memory/:clientId/refresh ────────────────────────────────
// Trigger AI re-analysis with a provided message snippet
router.post("/memory/:clientId/refresh", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const clientId = String(req.params.clientId || "");
        const { message, direction = "inbound" } = req.body;
        if (!message)
            return res.status(400).json({ error: "message is required" });
        const pool = (0, database_1.getPool)();
        const [rows] = await pool.query(`SELECT phone
       FROM clients
       WHERE id = ?
         AND user_id = ?
         AND is_active = TRUE
         ${brandId ? "AND brand_id = ?" : ""}
       LIMIT 1`, brandId ? [clientId, userId, brandId] : [clientId, userId]);
        if (!rows[0])
            return res.status(404).json({ error: "Client not found" });
        await memoryEngine_1.memoryEngine.updateMemoryFromMessage(userId, rows[0].phone, message, direction, brandId);
        const updated = await memoryEngine_1.memoryEngine.getMemory(clientId);
        return res.json({ clientId, memory: updated });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
// ─── GET /api/leads/memory/:clientId/context ─────────────────────────────────
// Get memory formatted as a prompt context string (for AI injection preview)
router.get("/memory/:clientId/context", async (req, res) => {
    try {
        const userId = getAuthenticatedUserId(req);
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const brandId = await resolveBrandId(req, userId);
        const clientId = String(req.params.clientId || "");
        const pool = (0, database_1.getPool)();
        const row = await verifyClientOwnership(pool, clientId, userId, brandId);
        if (!row)
            return res.status(404).json({ error: "Client not found" });
        const memory = await memoryEngine_1.memoryEngine.getMemory(clientId);
        if (!memory)
            return res.status(404).json({ error: "No memory found" });
        const context = memoryEngine_1.memoryEngine.buildPromptContext(memory);
        return res.json({ clientId, context });
    }
    catch (err) {
        return res.status(500).json({ error: err.message });
    }
});
exports.default = router;
//# sourceMappingURL=leads.js.map