import { Lead } from "../types";
export declare class GeminiService {
    private genAI;
    private model;
    private modelName;
    constructor();
    generateMessage(lead: Lead, templatePrompt: string): Promise<string>;
    generateFollowUp(lead: Lead, previousMessages: string[]): Promise<string>;
    analyzeImages(images: Array<{
        base64: string;
        mimeType: string;
        name?: string;
    }>, prompt: string, context?: string, detailedAnalysis?: boolean): Promise<string>;
    generatePlainText(prompt: string): Promise<string>;
}
//# sourceMappingURL=gemini.d.ts.map