"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const knowledgeBase_1 = require("../services/knowledgeBase");
const auth_1 = require("../middleware/auth");
const logger_1 = require("../utils/logger");
const router = (0, express_1.Router)();
const kbService = new knowledgeBase_1.KnowledgeBaseService();
// GET /api/knowledge-base - List all entries
router.get("/", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { category, search, active, company_id } = req.query;
        const filters = {};
        filters.user_id = userId;
        if (category)
            filters.category = category;
        if (search)
            filters.search = search;
        if (active !== undefined)
            filters.active = active === "true";
        if (company_id)
            filters.company_id = String(company_id);
        const entries = await kbService.getAll(filters);
        res.json({ success: true, entries });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// GET /api/knowledge-base/:id - Get entry by ID
router.get("/:id", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const entry = await kbService.getById(parseInt(req.params.id), userId);
        if (!entry)
            return res.status(404).json({ error: "Entry not found" });
        res.json({ success: true, entry });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// POST /api/knowledge-base - Create entry
router.post("/", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { title, content } = req.body;
        if (!title || !content) {
            return res.status(400).json({ error: "Title and content are required" });
        }
        const entry = await kbService.create(userId, req.body);
        res.status(201).json({ success: true, entry });
    }
    catch (error) {
        logger_1.logger.error(`Create KB entry error: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
});
// PUT /api/knowledge-base/:id - Update entry
router.put("/:id", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const entry = await kbService.update(parseInt(req.params.id), userId, req.body);
        if (!entry)
            return res.status(404).json({ error: "Entry not found" });
        res.json({ success: true, entry });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// DELETE /api/knowledge-base/:id - Delete entry
router.delete("/:id", auth_1.authMiddleware, (0, auth_1.requireRole)(["admin", "manager"]), async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const success = await kbService.delete(parseInt(req.params.id), userId);
        if (!success)
            return res.status(404).json({ error: "Entry not found" });
        res.json({ success: true, message: "Entry deleted" });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// POST /api/knowledge-base/search - Search for AI context
router.post("/search", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { query: searchQuery, company_id } = req.body;
        if (!searchQuery)
            return res.status(400).json({ error: "Query is required" });
        const context = await kbService.searchForContext(String(searchQuery), userId, company_id ? String(company_id) : undefined);
        res.json({ success: true, context });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=knowledgeBase.js.map