"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const companies_1 = require("../services/companies");
const auth_1 = require("../middleware/auth");
const brandContext_1 = require("../middleware/brandContext");
const logger_1 = require("../utils/logger");
const router = (0, express_1.Router)();
const companiesService = new companies_1.CompaniesService();
router.use(auth_1.authMiddleware, brandContext_1.attachBrandContext);
router.post("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const company = await companiesService.create(userId, req.body, req.brandId);
        res.status(201).json({ success: true, company });
    }
    catch (error) {
        logger_1.logger.error(error, "Erro ao criar empresa");
        res.status(500).json({ error: error.message });
    }
});
router.get("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const companies = await companiesService.getAll(userId, req.brandId);
        res.json({ success: true, companies });
    }
    catch (error) {
        logger_1.logger.error(error, "Erro ao listar empresas");
        res.status(500).json({ error: error.message });
    }
});
router.get("/:id", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const company = await companiesService.getById(req.params.id, userId, req.brandId);
        if (!company)
            return res.status(404).json({ error: "Empresa nao encontrada" });
        res.json({ success: true, company });
    }
    catch (error) {
        logger_1.logger.error(error, "Erro ao buscar empresa");
        res.status(500).json({ error: error.message });
    }
});
router.put("/:id", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const company = await companiesService.update(req.params.id, userId, req.body, req.brandId);
        if (!company)
            return res.status(404).json({ error: "Empresa nao encontrada" });
        res.json({ success: true, company });
    }
    catch (error) {
        logger_1.logger.error(error, "Erro ao atualizar empresa");
        res.status(500).json({ error: error.message });
    }
});
router.delete("/:id", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const deleted = await companiesService.delete(req.params.id, userId, req.brandId);
        if (!deleted)
            return res.status(404).json({ error: "Empresa nao encontrada" });
        res.json({ success: true, message: "Empresa removida" });
    }
    catch (error) {
        logger_1.logger.error(error, "Erro ao deletar empresa");
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=companies.js.map