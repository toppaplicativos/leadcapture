"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const brandContext_1 = require("../middleware/brandContext");
const automations_1 = require("../services/automations");
const router = (0, express_1.Router)();
const automationsService = new automations_1.AutomationsService();
router.use(auth_1.authMiddleware, brandContext_1.attachBrandContext);
function getAutomationRuntime(req) {
    const runtime = req.app.get("automationRuntime");
    if (!runtime) {
        throw new Error("Automation runtime not available");
    }
    return runtime;
}
function getInstanceRotation(req) {
    const rotation = req.app.get("instanceRotation");
    if (!rotation) {
        throw new Error("Instance rotation not available");
    }
    return rotation;
}
router.get("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const data = await automationsService.listRules(userId, req.brandId);
        res.json({ success: true, ...data });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const rule = await automationsService.createRule(userId, req.brandId, req.body || {});
        res.status(201).json({ success: true, rule });
    }
    catch (error) {
        const message = String(error?.message || "");
        if (message.includes("name is required")) {
            return res.status(400).json({ error: error.message });
        }
        res.status(500).json({ error: error.message });
    }
});
router.get("/outbound-metrics", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const metrics = await automationsService.getOutboundMetrics(userId, req.brandId);
        res.json({ success: true, metrics });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get("/runtime/status", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const runtime = getAutomationRuntime(req);
        const runtimeStatus = await runtime.getRuntimeStatus(userId);
        res.json({ success: true, runtime: runtimeStatus });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get("/runtime/settings", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const runtime = getAutomationRuntime(req);
        const settings = await runtime.getRuntimeSettings(userId);
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put("/runtime/settings", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const runtime = getAutomationRuntime(req);
        const settings = await runtime.updateRuntimeSettings(userId, req.body || {});
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get("/runtime/rotation/settings", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const rotation = getInstanceRotation(req);
        const settings = await rotation.getSettings(userId);
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put("/runtime/rotation/settings", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const rotation = getInstanceRotation(req);
        const settings = await rotation.updateSettings(userId, req.body || {});
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get("/runtime/rotation/pool", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const leadId = String(req.query?.leadId || "").trim() || undefined;
        const rotation = getInstanceRotation(req);
        const snapshot = await rotation.getPoolSnapshot(userId, leadId);
        res.json({ success: true, snapshot });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.get("/runtime/dead-letters", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const runtime = getAutomationRuntime(req);
        const limit = Math.max(1, Math.min(200, Math.floor(Number(req.query?.limit) || 50)));
        const deadLetters = await runtime.listDeadLetters(userId, limit);
        res.json({ success: true, dead_letters: deadLetters });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post("/runtime/dead-letters/:id/retry", auth_1.authMiddleware, async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const runtime = getAutomationRuntime(req);
        const id = String(req.params.id || "").trim();
        if (!id)
            return res.status(400).json({ error: "Dead letter id is required" });
        const retried = await runtime.retryDeadLetter(userId, id);
        if (!retried)
            return res.status(404).json({ error: "Dead letter not found or not retryable" });
        res.json({ success: true, retried: true });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post("/outbound-event", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const result = await automationsService.recordOutboundEvent(userId, req.body || {}, req.brandId);
        res.json({ success: true, ...result });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put("/scoring", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const scoring = await automationsService.updateScoring(userId, req.brandId, req.body || {});
        res.json({ success: true, scoring });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.put("/:code", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const code = String(req.params.code || "").trim();
        if (!code)
            return res.status(400).json({ error: "Automation code is required" });
        const rule = await automationsService.updateRule(userId, req.brandId, code, req.body || {});
        if (!rule)
            return res.status(404).json({ error: "Automation not found" });
        res.json({ success: true, rule });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
router.post("/:code/reset", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const code = String(req.params.code || "").trim();
        if (!code)
            return res.status(400).json({ error: "Automation code is required" });
        const rule = await automationsService.resetRule(userId, req.brandId, code);
        if (!rule)
            return res.status(404).json({ error: "Automation not found" });
        res.json({ success: true, rule });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=automations.js.map