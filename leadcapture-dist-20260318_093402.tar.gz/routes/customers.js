"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const customers_1 = require("../services/customers");
const auth_1 = require("../middleware/auth");
const brandContext_1 = require("../middleware/brandContext");
const logger_1 = require("../utils/logger");
const router = (0, express_1.Router)();
const customersService = new customers_1.CustomersService();
router.use(auth_1.authMiddleware, brandContext_1.attachBrandContext);
function getAutomationRuntime(req) {
    return req.app.get("automationRuntime") || null;
}
// GET /api/customers - List all customers with filters
router.get("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { status, source, category, city, search, page, limit } = req.query;
        const pageNum = parseInt(page) || 1;
        const limitNum = parseInt(limit) || 50;
        const offset = (pageNum - 1) * limitNum;
        const result = await customersService.getAll({
            status: status,
            source: source,
            category: category,
            city: city,
            search: search,
            limit: limitNum,
            offset,
            ownerUserId: userId,
            brandId: req.brandId,
        });
        res.json({
            success: true,
            customers: result.customers,
            total: result.total,
            page: pageNum,
            limit: limitNum,
            totalPages: Math.ceil(result.total / limitNum),
        });
    }
    catch (error) {
        logger_1.logger.error(`Get customers error: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
});
// GET /api/customers/stats - Get customer stats
router.get("/stats", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const stats = await customersService.getStats(userId, req.brandId);
        res.json({ success: true, stats });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// GET /api/customers/:id - Get customer by ID
router.get("/:id", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const customer = await customersService.getById(req.params.id, userId, req.brandId);
        if (!customer)
            return res.status(404).json({ error: "Customer not found" });
        res.json({ success: true, customer });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// POST /api/customers - Create customer manually
router.post("/", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        if (!req.body.name)
            return res.status(400).json({ error: "Name is required" });
        const customer = await customersService.create(req.body, userId, req.brandId);
        const runtime = getAutomationRuntime(req);
        if (runtime && customer?.id) {
            await runtime.triggerLeadCreated(userId, customer.id, {
                segmento: String(req.body?.category || "").trim() || undefined,
                cidade: String(req.body?.city || "").trim() || undefined,
                produto: String(req.body?.product || "").trim() || undefined,
                oferta: String(req.body?.offer || "").trim() || undefined,
            });
        }
        res.status(201).json({ success: true, customer });
    }
    catch (error) {
        logger_1.logger.error(`Create customer error: ${error.message}`);
        res.status(500).json({ error: error.message });
    }
});
// PUT /api/customers/:id - Update customer
router.put("/:id", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const customer = await customersService.updateCustomer(req.params.id, req.body, userId, req.brandId);
        if (!customer)
            return res.status(404).json({ error: "Customer not found" });
        res.json({ success: true, customer });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// PUT /api/customers/:id/status - Update customer status
router.put("/:id/status", async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const { status } = req.body;
        if (!status)
            return res.status(400).json({ error: "Status is required" });
        const customerBefore = await customersService.getById(req.params.id, userId, req.brandId);
        if (!customerBefore)
            return res.status(404).json({ error: "Customer not found" });
        const success = await customersService.updateStatus(req.params.id, status, userId, req.brandId);
        if (!success)
            return res.status(404).json({ error: "Customer not found" });
        const runtime = getAutomationRuntime(req);
        if (runtime) {
            await runtime.triggerLeadStatusChanged(userId, req.params.id, String(customerBefore?.status || "new"), String(status));
        }
        res.json({ success: true, message: "Status updated" });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
// DELETE /api/customers/:id - Delete customer
router.delete("/:id", (0, auth_1.requireRole)(["admin", "manager"]), async (req, res) => {
    try {
        const userId = req.user?.userId;
        if (!userId)
            return res.status(401).json({ error: "Unauthorized" });
        const success = await customersService.delete(req.params.id, userId, req.brandId);
        if (!success)
            return res.status(404).json({ error: "Customer not found" });
        res.json({ success: true, message: "Customer deleted" });
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=customers.js.map